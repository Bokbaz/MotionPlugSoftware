/* Motion Plug runtime version and public update-feed configuration.
 * build-release.sh keeps MP_VERSION synchronized with package.json and the
 * CEP manifest. The update feed is public; no account or license is involved. */
(function (global) {
  'use strict';

  global.MP_VERSION = '0.3.0';
  global.MP_UPDATE_MANIFEST_URL = 'https://motionplug.com/api/motion-plug/latest';

  /* Local testing override:
   * localStorage.setItem('motionplug.updateManifestUrl',
   *   'http://localhost:4173/latest.json'); */
  try {
    var override = localStorage.getItem('motionplug.updateManifestUrl');
    if (override) global.MP_UPDATE_MANIFEST_URL = override;
  } catch (error) { /* storage unavailable */ }
})(window);
