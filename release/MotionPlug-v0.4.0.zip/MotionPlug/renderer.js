"use strict";
(() => {
  // src/fonts/custom-fonts.ts
  var loaded = /* @__PURE__ */ new Map();
  async function loadCustomFont(values) {
    var _a, _b;
    const family = String((_a = values.fontFamily) != null ? _a : "");
    if (!family.startsWith("MotionPlugCustom-")) return;
    const data = String((_b = values.fontData) != null ? _b : "");
    if (!/^data:font\/(ttf|otf);base64,[A-Za-z0-9+/=]+$/.test(data)) {
      throw new Error("This custom font is missing. Import its OTF or TTF file again in Typography & color.");
    }
    if (!loaded.has(family)) {
      loaded.set(family, (async () => {
        try {
          const face = new FontFace(family, "url(".concat(data, ")"));
          await face.load();
          document.fonts.add(face);
        } catch (e) {
          loaded.delete(family);
          throw new Error("This font could not be loaded. Choose a valid OTF or TTF file.");
        }
      })());
    }
    await loaded.get(family);
  }

  // src/audio/sample-catalog.ts
  var soundSamples = {
    airy: { label: "Airy whoosh", file: "airy.wav" },
    deep: { label: "Dry low impact", file: "deep.wav" },
    wind: { label: "Soft wind", file: "wind.wav" },
    tap: { label: "Phone tap", file: "tap.wav" },
    select: { label: "Soft selection", file: "select.wav" },
    complete: { label: "Subtle completion", file: "complete.wav" },
    menu: { label: "Interface movement", file: "menu.wav" },
    pop: { label: "Interface pop", file: "pop.wav" }
  };
  function soundForPreset(family, variant) {
    switch (family) {
      case "hero-headline":
        return variant === "centered" ? "deep" : "airy";
      case "specification-reveal":
        return variant === "count" ? "select" : "deep";
      case "word-by-word":
        return variant === "track" ? "tap" : "select";
      case "rapid-replacement":
        return variant === "swaps" ? "menu" : "tap";
      case "masked-line-reveal":
        return "airy";
      case "keyword-emphasis":
        return variant === "scale" ? "pop" : "complete";
      case "headline-layout-transition":
        return "airy";
      case "feature-stack":
        return variant === "active" ? "select" : "tap";
      case "bento-summary":
        return "pop";
      case "product-callout":
        return "select";
      case "performance-comparison":
        return "menu";
      case "presenter-title":
        return "airy";
      case "price-availability":
        return "complete";
      case "light-sweep":
        return "wind";
      case "soft-focus":
        return variant === "words" ? "menu" : "wind";
    }
  }

  // src/renderer/highlights.ts
  function highlightedRuns(text) {
    const runs = [];
    const pattern = /\[([^\[\]]+)\]/g;
    let cursor = 0;
    let match;
    while (match = pattern.exec(text)) {
      if (match.index > cursor) runs.push({ text: text.slice(cursor, match.index), highlighted: false });
      runs.push({ text: match[1], highlighted: true });
      cursor = match.index + match[0].length;
    }
    if (cursor < text.length) runs.push({ text: text.slice(cursor), highlighted: false });
    return runs;
  }
  function plainText(text) {
    return highlightedRuns(text).map((run) => run.text).join("");
  }
  function splitHighlightedText(text, separator) {
    const marked = highlightedRuns(text).map((run) => run.highlighted ? run.text.split(separator).map((part) => part && "[".concat(part, "]")).join("\0") : run.text.replace(separator, "\0")).join("");
    return marked.split("\0");
  }
  function migrateKeyword(values) {
    if (typeof values.title === "string" && typeof values.keyword === "string" && values.keyword && !values.title.includes("[")) {
      const keyword = values.keyword.toLocaleLowerCase();
      values.title = values.title.split(/(\s+)/).map((word) => {
        const clean = word.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "");
        return clean.toLocaleLowerCase() === keyword ? word.replace(clean, "[".concat(clean, "]")) : word;
      }).join("");
    }
    delete values.keyword;
  }

  // src/catalog/presets.ts
  var baseDefaults = {
    fontFamily: "Inter Variable",
    fontWeight: 720,
    fontSize: 112,
    lineHeight: 0.92,
    tracking: -2,
    alignment: "center",
    positionX: 50,
    positionY: 50,
    safeMargin: 8,
    cornerRadius: 26,
    textColor: "#F7F7F2",
    accentColor: "#8CA8FF",
    accentColor2: "#C59CFF",
    transparentBackground: true,
    entrance: 0.55,
    hold: 2.3,
    exit: 0.5,
    intensity: 54,
    stagger: 0.14,
    direction: "up",
    sfxEnabled: true,
    sfxVolume: 68
  };
  var typographyControls = ["fontFamily", "fontWeight", "fontSize", "lineHeight", "tracking", "textColor"];
  var placementControls = ["positionX", "positionY", "safeMargin"];
  var motionControls = ["entrance", "hold", "exit", "intensity"];
  var outputControls = ["sfxEnabled", "sfxVolume"];
  function preset(input) {
    const defaults = { ...baseDefaults, ...input.defaults };
    if (input.defaults.hold === void 0) {
      defaults.hold = Math.max(
        0.4,
        input.duration - Number(defaults.entrance) - Number(defaults.exit)
      );
    }
    migrateKeyword(defaults);
    return {
      ...input,
      version: 2,
      sfx: { sample: soundForPreset(input.family, input.variant), label: soundSamples[soundForPreset(input.family, input.variant)].label },
      defaults
    };
  }
  var presets = [
    preset({
      id: "motionplug.hero.centered.v1",
      family: "hero-headline",
      familyName: "Hero Headline",
      name: "Quiet Monument",
      variant: "centered",
      category: "Typography",
      description: "A centered announcement that arrives with scale, air, and a measured hold.",
      tags: ["hero", "headline", "centered", "announcement", "minimal"],
      duration: 4,
      controls: ["title", "subtitle", ...typographyControls, "accentColor", ...placementControls, ...motionControls, ...outputControls],
      defaults: { title: "DESIGNED\nTO MOVE", subtitle: "A considered introduction", fontSize: 148, positionY: 48, intensity: 42 }
    }),
    preset({
      id: "motionplug.hero.editorial.v1",
      family: "hero-headline",
      familyName: "Hero Headline",
      name: "Editorial Horizon",
      variant: "editorial",
      category: "Typography",
      description: "A left-set editorial headline with a fine rule and offset supporting copy.",
      tags: ["hero", "editorial", "left", "rule", "magazine"],
      duration: 4.4,
      controls: ["title", "subtitle", ...typographyControls, "accentColor", "positionX", "positionY", "safeMargin", ...motionControls, ...outputControls],
      defaults: { title: "A NEW\nPOINT OF VIEW", subtitle: "Edition 01  /  Motion Study", alignment: "left", fontSize: 132, positionX: 10, positionY: 56, intensity: 62 }
    }),
    preset({
      id: "motionplug.spec.lockup.v1",
      family: "specification-reveal",
      familyName: "Big Number / Specification Reveal",
      name: "Metric Lockup",
      variant: "lockup",
      category: "Data",
      description: "An oversized metric locks into place before its unit and caption arrive.",
      tags: ["number", "spec", "metric", "stat", "product"],
      duration: 3.8,
      controls: ["value", "unit", "subtitle", "countEnabled", ...typographyControls, "accentColor", ...placementControls, ...motionControls, ...outputControls],
      defaults: { value: 48, unit: "MP", subtitle: "Main camera system", countEnabled: false, fontSize: 204, tracking: -5, positionY: 51, intensity: 48 }
    }),
    preset({
      id: "motionplug.spec.count.v1",
      family: "specification-reveal",
      familyName: "Big Number / Specification Reveal",
      name: "Precision Count",
      variant: "count",
      category: "Data",
      description: "A compact counter rises into a precise two-column specification layout.",
      tags: ["number", "count", "specification", "technical", "split"],
      duration: 4.2,
      controls: ["value", "unit", "subtitle", "countEnabled", ...typographyControls, "accentColor", "positionX", "positionY", "safeMargin", ...motionControls, ...outputControls],
      defaults: { value: 120, unit: "Hz", subtitle: "Adaptive refresh rate", countEnabled: true, alignment: "left", fontSize: 188, positionX: 12, positionY: 53, intensity: 64 }
    }),
    preset({
      id: "motionplug.words.rise.v1",
      family: "word-by-word",
      familyName: "Word-by-Word Build",
      name: "Measured Rise",
      variant: "rise",
      category: "Typography",
      description: "Words rise one at a time with speech-friendly timing and a stable final lockup.",
      tags: ["words", "speech", "sequential", "rise", "caption"],
      duration: 4.6,
      controls: ["title", ...typographyControls, "accentColor", ...placementControls, "entrance", "hold", "exit", "intensity", "stagger", ...outputControls],
      defaults: { title: "Every detail [earns] its place", fontSize: 108, positionY: 51, stagger: 0.18, intensity: 55 }
    }),
    preset({
      id: "motionplug.words.track.v1",
      family: "word-by-word",
      familyName: "Word-by-Word Build",
      name: "Kinetic Track",
      variant: "track",
      category: "Typography",
      description: "A sentence assembles along a horizontal track with a moving emphasis marker.",
      tags: ["words", "track", "kinetic", "speech", "horizontal"],
      duration: 4.8,
      controls: ["title", ...typographyControls, "accentColor", "positionY", "safeMargin", "entrance", "hold", "exit", "intensity", "stagger", ...outputControls],
      defaults: { title: "Small moves [change] everything", alignment: "left", fontSize: 92, positionX: 9, positionY: 53, stagger: 0.2, intensity: 72 }
    }),
    preset({
      id: "motionplug.replace.cuts.v1",
      family: "rapid-replacement",
      familyName: "Rapid Word Replacement",
      name: "Rhythmic Cuts",
      variant: "cuts",
      category: "Typography",
      description: "Short phrases cut cleanly at one anchor with individually readable holds.",
      tags: ["replace", "rhythmic", "cut", "words", "fast"],
      duration: 4.2,
      controls: ["sequenceText", ...typographyControls, "accentColor", ...placementControls, "hold", "exit", "intensity", ...outputControls],
      defaults: { sequenceText: "FOCUSED\nFLUID\nFAMILIAR\nYOURS", fontSize: 156, hold: 0.72, intensity: 20 }
    }),
    preset({
      id: "motionplug.replace.swaps.v1",
      family: "rapid-replacement",
      familyName: "Rapid Word Replacement",
      name: "Soft Swaps",
      variant: "swaps",
      category: "Typography",
      description: "Phrases trade places through a clipped vertical swap with subtle depth.",
      tags: ["replace", "swap", "mask", "phrases", "vertical"],
      duration: 4.5,
      controls: ["sequenceText", ...typographyControls, "accentColor", ...placementControls, "hold", "exit", "intensity", ...outputControls],
      defaults: { sequenceText: "LESS NOISE\nMORE SIGNAL\nPURE FOCUS", fontSize: 132, hold: 0.95, intensity: 66 }
    }),
    preset({
      id: "motionplug.masked.lift.v1",
      family: "masked-line-reveal",
      familyName: "Masked Line Reveal",
      name: "Line Lift",
      variant: "up",
      category: "Typography",
      description: "Lines emerge upward from crisp invisible boundaries with exact staggering.",
      tags: ["mask", "lines", "up", "stagger", "reveal"],
      duration: 4.4,
      controls: ["title", ...typographyControls, "accentColor", ...placementControls, "entrance", "hold", "exit", "intensity", "stagger", ...outputControls],
      defaults: { title: "BUILT AROUND\nWHAT MATTERS\nMOST", alignment: "left", fontSize: 124, positionX: 10, positionY: 52, stagger: 0.16, intensity: 64 }
    }),
    preset({
      id: "motionplug.masked.side.v1",
      family: "masked-line-reveal",
      familyName: "Masked Line Reveal",
      name: "Side Passage",
      variant: "side",
      category: "Typography",
      description: "A sideways line reveal creates pace without disturbing the final layout.",
      tags: ["mask", "lines", "side", "editorial", "reveal"],
      duration: 4.2,
      controls: ["title", "subtitle", ...typographyControls, "accentColor", ...placementControls, "entrance", "hold", "exit", "intensity", "stagger", ...outputControls],
      defaults: { title: "FORM\nFOLLOWS\nFEELING", subtitle: "A study in considered motion", alignment: "right", fontSize: 122, positionX: 89, positionY: 50, stagger: 0.14, intensity: 76 }
    }),
    preset({
      id: "motionplug.keyword.color.v1",
      family: "keyword-emphasis",
      familyName: "Keyword Emphasis",
      name: "Chromatic Word",
      variant: "color",
      category: "Typography",
      description: "One chosen word takes color while the surrounding sentence remains perfectly still.",
      tags: ["color", "emphasis", "sentence", "stable"],
      duration: 4.2,
      controls: ["title", ...typographyControls, "accentColor", ...placementControls, ...motionControls, ...outputControls],
      defaults: { title: "Clarity makes ideas [memorable]", fontSize: 104, positionY: 51, intensity: 28 }
    }),
    preset({
      id: "motionplug.keyword.scale.v1",
      family: "keyword-emphasis",
      familyName: "Keyword Emphasis",
      name: "Weight of One",
      variant: "scale",
      category: "Typography",
      description: "The selected word grows with controlled scale while the sentence holds its baseline.",
      tags: ["scale", "emphasis", "baseline", "bold"],
      duration: 4.4,
      controls: ["title", ...typographyControls, "accentColor", ...placementControls, ...motionControls, ...outputControls],
      defaults: { title: "Make the [essential] unmistakable", alignment: "left", fontSize: 96, positionX: 9, positionY: 54, intensity: 56 }
    }),
    preset({
      id: "motionplug.transition.corner.v1",
      family: "headline-layout-transition",
      familyName: "Headline-to-Layout Transition",
      name: "Corner Settle",
      variant: "corner",
      category: "Layout",
      description: "A monumental title resolves into a corner heading as supporting content appears.",
      tags: ["transition", "layout", "corner", "headline", "support"],
      duration: 5.2,
      controls: ["title", "subtitle", ...typographyControls, "accentColor", "safeMargin", ...motionControls, ...outputControls],
      defaults: { title: "THE NEXT\nCHAPTER", subtitle: "Designed from the inside out.\nMade to feel immediate.", fontSize: 154, intensity: 62 }
    }),
    preset({
      id: "motionplug.transition.rail.v1",
      family: "headline-layout-transition",
      familyName: "Headline-to-Layout Transition",
      name: "Rail Shift",
      variant: "rail",
      category: "Layout",
      description: "The title travels onto a vertical rail and opens space for a concise statement.",
      tags: ["transition", "layout", "rail", "shift", "editorial"],
      duration: 5,
      controls: ["title", "subtitle", ...typographyControls, "accentColor", "safeMargin", ...motionControls, ...outputControls],
      defaults: { title: "SPACE\nTO THINK", subtitle: "An interface should leave room for the work.", alignment: "left", fontSize: 146, intensity: 75 }
    }),
    preset({
      id: "motionplug.stack.accumulate.v1",
      family: "feature-stack",
      familyName: "Feature Stack",
      name: "Progressive Stack",
      variant: "accumulate",
      category: "Layout",
      description: "Benefits accumulate vertically and remain visible as the list completes.",
      tags: ["features", "stack", "benefits", "list", "progressive"],
      duration: 5,
      controls: ["title", "itemsText", ...typographyControls, "accentColor", "positionX", "positionY", "safeMargin", "entrance", "hold", "exit", "stagger", ...outputControls],
      defaults: { title: "WHAT CHANGES", itemsText: "Faster decisions\nCleaner handoffs\nMore room to create\nNothing in the way", alignment: "left", fontSize: 72, positionX: 11, positionY: 52, stagger: 0.28 }
    }),
    preset({
      id: "motionplug.stack.active.v1",
      family: "feature-stack",
      familyName: "Feature Stack",
      name: "Active Line",
      variant: "active",
      category: "Layout",
      description: "A quiet list holds while one active benefit advances down a luminous rail.",
      tags: ["features", "active", "rail", "list", "highlight"],
      duration: 5.4,
      controls: ["title", "itemsText", ...typographyControls, "accentColor", "positionX", "positionY", "safeMargin", "entrance", "hold", "exit", "stagger", ...outputControls],
      defaults: { title: "BUILT IN", itemsText: "Instant preview\nPrecise timing\nEditable sound\nReliable delivery", alignment: "left", fontSize: 70, positionX: 13, positionY: 51, stagger: 0.72 }
    }),
    preset({
      id: "motionplug.bento.mosaic.v1",
      family: "bento-summary",
      familyName: "Bento Feature Summary",
      name: "Balanced Mosaic",
      variant: "mosaic",
      category: "Layout",
      description: "Four rounded tiles assemble into an asymmetric product summary.",
      tags: ["bento", "tiles", "grid", "features", "cards"],
      duration: 5,
      controls: ["title", "tile1", "tile2", "tile3", "tile4", ...typographyControls, "accentColor", "accentColor2", "cornerRadius", "safeMargin", ...motionControls, "stagger", ...outputControls],
      defaults: { title: "EVERYTHING\nIN ITS PLACE", tile1: "48 MP\nDetail", tile2: "All day\nBattery", tile3: "Spatial\nAudio", tile4: "A18\nPerformance", fontSize: 92, cornerRadius: 30, stagger: 0.12, intensity: 58 }
    }),
    preset({
      id: "motionplug.bento.editorial.v1",
      family: "bento-summary",
      familyName: "Bento Feature Summary",
      name: "Editorial Grid",
      variant: "editorial",
      category: "Layout",
      description: "A restrained two-column grid builds around a typographic lead panel.",
      tags: ["bento", "editorial", "grid", "summary", "modular"],
      duration: 5.2,
      controls: ["title", "tile1", "tile2", "tile3", "tile4", ...typographyControls, "accentColor", "accentColor2", "cornerRadius", "safeMargin", ...motionControls, "stagger", ...outputControls],
      defaults: { title: "LESS,\nBETTER", tile1: "2\xD7\nFaster", tile2: "24 hr\nPlayback", tile3: "4 colors", tile4: "100%\nRecycled", alignment: "left", fontSize: 104, cornerRadius: 18, stagger: 0.16, intensity: 68 }
    }),
    preset({
      id: "motionplug.callout.pin.v1",
      family: "product-callout",
      familyName: "Product Callout",
      name: "Precision Pin",
      variant: "pin",
      category: "Layout",
      description: "A fixed anchor draws a precise connector to an editable product label.",
      tags: ["callout", "pin", "connector", "label", "product"],
      duration: 4.2,
      controls: ["label", "subtitle", ...typographyControls, "accentColor", "anchorX", "anchorY", "labelX", "labelY", "safeMargin", ...motionControls, ...outputControls],
      defaults: { label: "TITANIUM FRAME", subtitle: "Grade 5. Brushed finish.", alignment: "left", fontSize: 64, anchorX: 62, anchorY: 43, labelX: 73, labelY: 29, intensity: 54 }
    }),
    preset({
      id: "motionplug.callout.orbit.v1",
      family: "product-callout",
      familyName: "Product Callout",
      name: "Offset Orbit",
      variant: "orbit",
      category: "Layout",
      description: "A ringed anchor and bent connector create a softer technical annotation.",
      tags: ["callout", "orbit", "connector", "annotation", "fixed"],
      duration: 4.4,
      controls: ["label", "subtitle", ...typographyControls, "accentColor", "anchorX", "anchorY", "labelX", "labelY", "safeMargin", ...motionControls, ...outputControls],
      defaults: { label: "ACTION BUTTON", subtitle: "Your shortcut to anything.", alignment: "left", fontSize: 62, anchorX: 32, anchorY: 56, labelX: 47, labelY: 32, intensity: 67 }
    }),
    preset({
      id: "motionplug.compare.bars.v1",
      family: "performance-comparison",
      familyName: "Performance Comparison",
      name: "Measured Bars",
      variant: "bars",
      category: "Data",
      description: "Two values resolve into proportional bars with labels and a quiet source line.",
      tags: ["comparison", "bars", "performance", "data", "values"],
      duration: 4.8,
      controls: ["title", "labelA", "labelB", "valueA", "valueB", "footnote", ...typographyControls, "accentColor", "accentColor2", "safeMargin", ...motionControls, ...outputControls],
      defaults: { title: "A GENERATIONAL LEAP", labelA: "Previous", labelB: "New", valueA: 64, valueB: 100, footnote: "Relative graphics performance", alignment: "left", fontSize: 82, intensity: 58 }
    }),
    preset({
      id: "motionplug.compare.split.v1",
      family: "performance-comparison",
      familyName: "Performance Comparison",
      name: "Split Measure",
      variant: "split",
      category: "Data",
      description: "A central measure divides two typographic values for an editorial comparison.",
      tags: ["comparison", "split", "measure", "data", "editorial"],
      duration: 4.6,
      controls: ["title", "labelA", "labelB", "valueA", "valueB", "footnote", ...typographyControls, "accentColor", "accentColor2", "safeMargin", ...motionControls, ...outputControls],
      defaults: { title: "MORE FROM EVERY CORE", labelA: "Efficiency", labelB: "Performance", valueA: 35, valueB: 70, footnote: "Improvement over previous generation", fontSize: 76, intensity: 48 }
    }),
    preset({
      id: "motionplug.presenter.left.v1",
      family: "presenter-title",
      familyName: "Minimal Presenter Title",
      name: "Quiet Introduction",
      variant: "left",
      category: "Identity",
      description: "An understated left-aligned name and role with a restrained leading mark.",
      tags: ["presenter", "lower third", "name", "role", "left"],
      duration: 4.6,
      controls: ["name", "role", ...typographyControls, "accentColor", "positionX", "positionY", "safeMargin", ...motionControls, ...outputControls],
      defaults: { name: "MAYA CHEN", role: "Industrial Designer", alignment: "left", fontSize: 58, positionX: 8, positionY: 82, intensity: 38 }
    }),
    preset({
      id: "motionplug.presenter.right.v1",
      family: "presenter-title",
      familyName: "Minimal Presenter Title",
      name: "Quiet Introduction Right",
      variant: "right",
      category: "Identity",
      description: "A right-aligned presenter title that unfolds from a compact endpoint.",
      tags: ["presenter", "lower third", "name", "role", "right"],
      duration: 4.6,
      controls: ["name", "role", ...typographyControls, "accentColor", "positionX", "positionY", "safeMargin", ...motionControls, ...outputControls],
      defaults: { name: "ALEX RIVERA", role: "Director of Photography", alignment: "right", fontSize: 58, positionX: 92, positionY: 82, intensity: 46 }
    }),
    preset({
      id: "motionplug.price.center.v1",
      family: "price-availability",
      familyName: "Price and Availability Reveal",
      name: "Launch Price",
      variant: "center",
      category: "Commerce",
      description: "Product, price, and availability arrive in a deliberate centered sequence.",
      tags: ["price", "availability", "launch", "currency", "center"],
      duration: 4.6,
      controls: ["product", "price", "availability", "subtitle", ...typographyControls, "accentColor", ...placementControls, ...motionControls, "stagger", ...outputControls],
      defaults: { product: "AURA ONE", price: "From $799", availability: "Available 09.20", subtitle: "Pre-order Friday", fontSize: 92, positionY: 49, stagger: 0.22, intensity: 42 }
    }),
    preset({
      id: "motionplug.price.side.v1",
      family: "price-availability",
      familyName: "Price and Availability Reveal",
      name: "Price Ledger",
      variant: "side",
      category: "Commerce",
      description: "A side-set product lockup balances a large price against compact availability.",
      tags: ["price", "availability", "ledger", "split", "currency"],
      duration: 4.8,
      controls: ["product", "price", "availability", "subtitle", ...typographyControls, "accentColor", "positionX", "positionY", "safeMargin", ...motionControls, "stagger", ...outputControls],
      defaults: { product: "STUDIO DISPLAY", price: "\u20AC1,749", availability: "Ships today", subtitle: "27-inch 5K Retina display", alignment: "left", fontSize: 88, positionX: 9, positionY: 52, stagger: 0.2, intensity: 55 }
    }),
    preset({
      id: "motionplug.sweep.single.v1",
      family: "light-sweep",
      familyName: "Gradient / Light Sweep Text",
      name: "Single Light",
      variant: "single",
      category: "Effects",
      description: "One narrow light sweep travels through stable typography, then disappears.",
      tags: ["light", "sweep", "gradient", "text", "single"],
      duration: 4.4,
      controls: ["title", ...typographyControls, "accentColor", "accentColor2", ...placementControls, ...motionControls, ...outputControls],
      defaults: { title: "LIGHT, PRECISELY", fontSize: 126, intensity: 48, loop: false }
    }),
    preset({
      id: "motionplug.sweep.loop.v1",
      family: "light-sweep",
      familyName: "Gradient / Light Sweep Text",
      name: "Quiet Current",
      variant: "loop",
      category: "Effects",
      description: "A restrained tonal current crosses the title twice without moving the type.",
      tags: ["light", "sweep", "loop", "gradient", "ambient"],
      duration: 5.2,
      controls: ["title", ...typographyControls, "accentColor", "accentColor2", ...placementControls, ...motionControls, "loop", ...outputControls],
      defaults: { title: "ALWAYS IN MOTION", fontSize: 118, intensity: 38, loop: true }
    }),
    preset({
      id: "motionplug.focus.whole.v1",
      family: "soft-focus",
      familyName: "Soft Focus Reveal",
      name: "Whole Resolve",
      variant: "whole",
      category: "Effects",
      description: "The complete title resolves from soft focus with barely perceptible movement.",
      tags: ["focus", "blur", "resolve", "soft", "whole"],
      duration: 4.6,
      controls: ["title", "subtitle", ...typographyControls, "accentColor", ...placementControls, ...motionControls, ...outputControls],
      defaults: { title: "COME INTO FOCUS", subtitle: "Nothing more than what matters", fontSize: 120, intensity: 46 }
    }),
    preset({
      id: "motionplug.focus.words.v1",
      family: "soft-focus",
      familyName: "Soft Focus Reveal",
      name: "Word Resolve",
      variant: "words",
      category: "Effects",
      description: "Words sharpen in sequence and settle into a clean final sentence.",
      tags: ["focus", "blur", "words", "stagger", "resolve"],
      duration: 5,
      controls: ["title", ...typographyControls, "accentColor", ...placementControls, "entrance", "hold", "exit", "intensity", "stagger", ...outputControls],
      defaults: { title: "SEE THE [WHOLE] IDEA", fontSize: 114, stagger: 0.2, intensity: 62 }
    })
  ];
  var presetById = new Map(presets.map((item) => [item.id, item]));
  var familyNames = [...new Set(presets.map((item) => item.familyName))];
  var categories = [...new Set(presets.map((item) => item.category))];
  function valuesForPreset(id, overrides = {}) {
    const item = presetById.get(id);
    if (!item) throw new Error("Unknown preset: ".concat(id));
    const values = { ...item.defaults, ...overrides };
    migrateKeyword(values);
    values.transparentBackground = true;
    delete values.backgroundColor;
    delete values.aspectRatio;
    return values;
  }

  // src/renderer/core.ts
  var TAU = Math.PI * 2;
  var clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));
  var mix = (from, to, amount) => from + (to - from) * amount;
  var easeOutQuint = (value) => 1 - (1 - clamp(value)) ** 5;
  var easeOutQuart = (value) => 1 - (1 - clamp(value)) ** 4;
  var easeInQuart = (value) => clamp(value) ** 4;
  var easeInOutCubic = (value) => {
    const x = clamp(value);
    return x < 0.5 ? 4 * x ** 3 : 1 - (-2 * x + 2) ** 3 / 2;
  };
  var easeOutBack = (value, amount = 0.28) => {
    const x = clamp(value) - 1;
    return 1 + (amount + 1) * x ** 3 + amount * x ** 2;
  };
  var settledScale = (value, from = 0.94, overshoot = 0.01) => {
    const x = clamp(value);
    const arrival = 0.72;
    if (x <= arrival) return mix(from, 1 + overshoot, easeOutQuint(x / arrival));
    return mix(1 + overshoot, 1, easeInOutCubic((x - arrival) / (1 - arrival)));
  };
  function num(values, key, fallback = 0) {
    const value = Number(values[key]);
    return Number.isFinite(value) ? value : fallback;
  }
  function str(values, key, fallback = "") {
    const value = values[key];
    return typeof value === "string" ? value : String(value != null ? value : fallback);
  }
  function bool(values, key, fallback = false) {
    const value = values[key];
    return typeof value === "boolean" ? value : fallback;
  }
  function color(values, key, fallback) {
    const value = str(values, key, fallback);
    return /^#[\da-f]{6}$/i.test(value) ? value : fallback;
  }
  function phase(scene, delay = 0, duration) {
    const length = duration != null ? duration : num(scene.values, "entrance", 0.55);
    return clamp((scene.time - delay) / Math.max(1e-3, length));
  }
  function exitPhase(scene) {
    const length = Math.max(0.08, num(scene.values, "exit", 0.5));
    return easeInQuart((scene.time - (scene.duration - length)) / length);
  }
  function overallAlpha(scene) {
    const entrance = num(scene.values, "entrance", 0.55);
    const entering = easeOutQuint(scene.time / Math.max(entrance * 0.68, 0.08));
    return entering * (1 - exitPhase(scene));
  }
  function motionBlur(scene, progress, maximum = 7) {
    const x = clamp(progress);
    const velocityWindow = Math.sin(Math.PI * x) * (1 - x * 0.28);
    return "blur(".concat(px(scene, maximum) * Math.max(0, velocityWindow), "px)");
  }
  function px(scene, value) {
    return value * scene.scale;
  }
  function applyExitMotion(scene) {
    const progress = exitPhase(scene);
    if (progress <= 0) return;
    const intensity = num(scene.values, "intensity", 50) / 100;
    let x = 0;
    let y = -mix(12, 28, intensity);
    let scale = 1 + mix(4e-3, 0.012, intensity) * progress;
    switch (scene.preset.family) {
      case "word-by-word":
        if (scene.preset.variant === "track") {
          x = 34;
          y = 0;
        }
        break;
      case "rapid-replacement":
        y = scene.preset.variant === "swaps" ? -42 : 0;
        scale = scene.preset.variant === "cuts" ? 1 + 0.018 * progress : scale;
        break;
      case "masked-line-reveal":
        if (scene.preset.variant === "side") {
          x = 30;
          y = 0;
        }
        break;
      case "headline-layout-transition":
        x = -22;
        y = -8;
        break;
      case "product-callout":
        x = scene.preset.variant === "orbit" ? 18 : -14;
        y = 0;
        break;
      case "presenter-title":
        x = scene.preset.variant === "right" ? -30 : 30;
        y = 0;
        break;
      case "light-sweep":
        x = 0;
        y = 0;
        scale = 1;
        break;
      case "soft-focus":
        y = 0;
        scale = 1 + 0.014 * progress;
        break;
    }
    if (scale !== 1) {
      scene.ctx.translate(scene.width / 2, scene.height / 2);
      scene.ctx.scale(scale, scale);
      scene.ctx.translate(-scene.width / 2, -scene.height / 2);
    }
    scene.ctx.translate(px(scene, x) * progress, px(scene, y) * progress);
  }
  function anchor(scene) {
    return {
      x: num(scene.values, "positionX", 50) / 100 * scene.width,
      y: num(scene.values, "positionY", 50) / 100 * scene.height
    };
  }
  function alignment(values) {
    const value = str(values, "alignment", "center");
    return value === "left" || value === "right" ? value : "center";
  }
  function setType(scene, size = num(scene.values, "fontSize", 112), weight = num(scene.values, "fontWeight", 720)) {
    const family = str(scene.values, "fontFamily", "Inter Variable");
    scene.ctx.font = "".concat(Math.round(weight), " ").concat(Math.max(8, px(scene, size)), 'px "').concat(family, '", Inter, Arial, sans-serif');
    scene.ctx.textBaseline = "alphabetic";
    scene.ctx.textAlign = alignment(scene.values);
  }
  function measuredWidth(ctx, text, tracking) {
    text = plainText(text);
    if (!text) return 0;
    return ctx.measureText(text).width + Math.max(0, text.length - 1) * tracking;
  }
  function drawTrackedText(ctx, text, x, y, tracking) {
    if (Math.abs(tracking) < 0.01 || text.length < 2) {
      ctx.fillText(text, x, y);
      return;
    }
    const align = ctx.textAlign;
    const width = measuredWidth(ctx, text, tracking);
    let cursor = align === "center" ? x - width / 2 : align === "right" ? x - width : x;
    const previous = ctx.textAlign;
    ctx.textAlign = "left";
    for (const glyph of [...text]) {
      ctx.fillText(glyph, cursor, y);
      cursor += ctx.measureText(glyph).width + tracking;
    }
    ctx.textAlign = previous;
  }
  function drawText(scene, text, x, y, options = {}) {
    var _a, _b;
    setType(scene, options.size, options.weight);
    scene.ctx.fillStyle = (_a = options.fill) != null ? _a : color(scene.values, "textColor", "#F7F7F2");
    const tracking = px(scene, (_b = options.tracking) != null ? _b : num(scene.values, "tracking", -2));
    const runs = highlightedRuns(text);
    if (!runs.some((run) => run.highlighted)) {
      drawTrackedText(scene.ctx, text, x, y, tracking);
      return;
    }
    const ctx = scene.ctx;
    const baseFill = ctx.fillStyle;
    const align = ctx.textAlign;
    const width = measuredWidth(ctx, text, tracking);
    let cursor = align === "center" ? x - width / 2 : align === "right" ? x - width : x;
    ctx.textAlign = "left";
    for (const run of runs) {
      ctx.fillStyle = run.highlighted ? color(scene.values, "accentColor", "#8CA8FF") : baseFill;
      drawTrackedText(ctx, run.text, cursor, y, tracking);
      cursor += measuredWidth(ctx, run.text, tracking) + tracking;
    }
    ctx.fillStyle = baseFill;
    ctx.textAlign = align;
  }
  function maxLineWidth(scene, lines, size) {
    setType(scene, size);
    return Math.max(
      0,
      ...lines.map(
        (line) => measuredWidth(scene.ctx, line, px(scene, num(scene.values, "tracking", -2)))
      )
    );
  }
  function fitSize(scene, lines, requested, width, min = 28) {
    let result = requested;
    while (result > min && maxLineWidth(scene, lines, result) > width) result -= 2;
    if (result <= min && maxLineWidth(scene, lines, result) > width) {
      scene.diagnostics.overflow = true;
      if (!scene.diagnostics.warnings.includes("Text exceeds the safe frame.")) {
        scene.diagnostics.warnings.push("Text exceeds the safe frame.");
      }
    }
    return result;
  }
  function drawLines(scene, text, x, y, options = {}) {
    var _a, _b, _c;
    const ctx = scene.ctx;
    const lines = splitHighlightedText(text, /\n/g).slice(0, 8);
    const requested = (_a = options.size) != null ? _a : num(scene.values, "fontSize", 112);
    const safe = num(scene.values, "safeMargin", 8) / 100 * scene.width;
    const size = fitSize(scene, lines, requested, scene.width - safe * 2);
    const lineHeight = px(scene, size * num(scene.values, "lineHeight", 0.92));
    const top = y - (lines.length - 1) * lineHeight / 2;
    const progress = (_b = options.progress) != null ? _b : 1;
    const stagger = (_c = options.lineDelay) != null ? _c : num(scene.values, "stagger", 0.14);
    lines.forEach((line, index) => {
      const local = easeOutQuint(clamp((progress - index * stagger) / Math.max(0.1, 1 - index * stagger)));
      const distance = px(scene, 28 + num(scene.values, "intensity", 54) * 0.5);
      ctx.save();
      ctx.globalAlpha *= local;
      if (options.reveal === "up") {
        ctx.beginPath();
        ctx.rect(0, top + index * lineHeight - lineHeight, scene.width, lineHeight * 1.3);
        ctx.clip();
        ctx.translate(0, (1 - local) * distance);
      } else if (options.reveal === "side") {
        const lineWidth = maxLineWidth(scene, [line], size);
        const left = alignment(scene.values) === "right" ? x - lineWidth : alignment(scene.values) === "center" ? x - lineWidth / 2 : x;
        ctx.beginPath();
        ctx.rect(left, top + index * lineHeight - lineHeight, lineWidth * local, lineHeight * 1.4);
        ctx.clip();
        ctx.translate((1 - local) * distance * (alignment(scene.values) === "right" ? -1 : 1), 0);
      } else {
        ctx.translate(0, (1 - local) * distance * 0.35);
      }
      drawText(scene, line, x, top + index * lineHeight, {
        size,
        weight: options.weight,
        fill: options.fill
      });
      ctx.restore();
    });
  }
  function roundRect(ctx, x, y, width, height, radius) {
    const r = Math.max(0, Math.min(radius, width / 2, height / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + width, y, x + width, y + height, r);
    ctx.arcTo(x + width, y + height, x, y + height, r);
    ctx.arcTo(x, y + height, x, y, r);
    ctx.arcTo(x, y, x + width, y, r);
    ctx.closePath();
  }
  function rgba(hex, alpha) {
    const safe = /^#[\da-f]{6}$/i.test(hex) ? hex : "#F7F7F2";
    const r = parseInt(safe.slice(1, 3), 16);
    const g = parseInt(safe.slice(3, 5), 16);
    const b = parseInt(safe.slice(5, 7), 16);
    return "rgba(".concat(r, ", ").concat(g, ", ").concat(b, ", ").concat(clamp(alpha), ")");
  }
  function paintBackground(scene, config2) {
    const ctx = scene.ctx;
    ctx.clearRect(0, 0, scene.width, scene.height);
    if (config2.renderMode === "export" || config2.background === "transparent") return;
    if (config2.background === "checker") {
      const cell = Math.max(8, scene.width / 24);
      for (let y = 0; y < scene.height; y += cell) {
        for (let x = 0; x < scene.width; x += cell) {
          ctx.fillStyle = (Math.floor(x / cell) + Math.floor(y / cell)) % 2 ? "#25262b" : "#34353b";
          ctx.fillRect(x, y, cell, cell);
        }
      }
    } else {
      ctx.fillStyle = config2.background === "light" ? "#e8e8e5" : "#111218";
      ctx.fillRect(0, 0, scene.width, scene.height);
    }
  }
  function hero(scene) {
    const { ctx, values, preset: preset2 } = scene;
    const point = anchor(scene);
    const raw = phase(scene);
    const p = easeOutQuint(raw);
    const alpha = overallAlpha(scene);
    const intensity = num(values, "intensity", 50) / 100;
    ctx.globalAlpha = alpha;
    if (preset2.variant === "centered") {
      ctx.save();
      ctx.translate(point.x, point.y);
      const titleScale = settledScale(raw, 0.95 - intensity * 0.035, 6e-3 + intensity * 6e-3);
      ctx.translate(0, (1 - p) * px(scene, 24 + intensity * 24));
      ctx.rotate((1 - p) * -8e-3 * intensity);
      ctx.scale(titleScale, titleScale);
      ctx.translate(-point.x, -point.y);
      ctx.filter = motionBlur(scene, raw, 8);
      drawLines(scene, str(values, "title", "DESIGNED\nTO MOVE"), point.x, point.y, {
        progress: raw,
        lineDelay: 0.1,
        reveal: "fade"
      });
      ctx.restore();
      const accentP = easeOutQuart(phase(scene, 0.2, 0.42));
      ctx.save();
      ctx.globalAlpha *= accentP;
      ctx.fillStyle = color(values, "accentColor", "#8CA8FF");
      roundRect(ctx, point.x - px(scene, 25) * accentP, point.y + px(scene, 116), px(scene, 50) * accentP, px(scene, 3), px(scene, 2));
      ctx.fill();
      ctx.restore();
      const subtitleP = easeOutQuint(phase(scene, 0.32, 0.5));
      ctx.save();
      ctx.globalAlpha *= subtitleP;
      ctx.translate(0, (1 - subtitleP) * px(scene, 16));
      ctx.filter = motionBlur(scene, phase(scene, 0.32, 0.5), 4);
      drawText(scene, str(values, "subtitle"), point.x, point.y + px(scene, 172), {
        size: 30,
        weight: 480,
        fill: rgba(color(values, "textColor", "#F7F7F2"), 0.66),
        tracking: 2.5
      });
      ctx.restore();
    } else {
      const safeX = point.x;
      ctx.save();
      const startX = safeX - px(scene, 46 + 42 * intensity) * (1 - p);
      ctx.translate(safeX, point.y);
      ctx.rotate((1 - p) * -0.012 * intensity);
      ctx.translate(-safeX, -point.y);
      ctx.filter = motionBlur(scene, raw, 8);
      drawLines(scene, str(values, "title"), startX, point.y, { progress: raw, lineDelay: 0.09, reveal: "side" });
      ctx.restore();
      const lineP = easeOutQuart(phase(scene, 0.24, 0.62));
      ctx.strokeStyle = color(values, "accentColor", "#8CA8FF");
      ctx.lineWidth = px(scene, 3);
      ctx.beginPath();
      ctx.moveTo(safeX, point.y + px(scene, 177));
      ctx.lineTo(safeX + px(scene, 440) * lineP, point.y + px(scene, 177));
      ctx.stroke();
      const subtitleP = easeOutQuint(phase(scene, 0.38, 0.48));
      ctx.save();
      ctx.globalAlpha *= subtitleP;
      ctx.translate((1 - subtitleP) * px(scene, 18), 0);
      drawText(scene, str(values, "subtitle"), safeX, point.y + px(scene, 224), {
        size: 27,
        weight: 480,
        fill: rgba(color(values, "textColor", "#F7F7F2"), 0.68),
        tracking: 1.8
      });
      ctx.restore();
    }
  }
  function specification(scene) {
    const { ctx, values, preset: preset2 } = scene;
    const point = anchor(scene);
    const raw = phase(scene);
    const p = easeOutQuint(raw);
    const intensity = num(values, "intensity", 50) / 100;
    const countP = easeOutQuart(phase(scene, 0.05, 0.9));
    const shownValue = num(values, "countEnabled", 0) || preset2.variant === "count" ? Math.round(num(values, "value", 48) * countP) : num(values, "value", 48);
    const unit = str(values, "unit", "MP");
    ctx.globalAlpha = overallAlpha(scene);
    if (preset2.variant === "lockup") {
      ctx.save();
      ctx.translate(point.x, point.y);
      ctx.translate(0, (1 - p) * px(scene, 34 + 28 * intensity));
      ctx.rotate((1 - p) * -0.012 * intensity);
      const scale = settledScale(raw, 0.88, 0.012);
      ctx.scale(scale, scale);
      ctx.translate(-point.x, -point.y);
      ctx.filter = motionBlur(scene, raw, 9);
      drawText(scene, String(shownValue), point.x - px(scene, 34), point.y + px(scene, 62), { size: num(values, "fontSize", 204), weight: 790 });
      ctx.restore();
      const q = easeOutQuint(phase(scene, 0.2, 0.44));
      ctx.save();
      ctx.globalAlpha *= q;
      ctx.translate((1 - q) * px(scene, 20), 0);
      drawText(scene, unit, point.x + px(scene, 265), point.y + px(scene, 52), {
        size: 53,
        weight: 700,
        fill: color(values, "accentColor", "#8CA8FF"),
        tracking: 0
      });
      ctx.restore();
      const captionP = easeOutQuint(phase(scene, 0.34, 0.46));
      ctx.save();
      ctx.globalAlpha *= captionP;
      ctx.translate(0, (1 - captionP) * px(scene, 14));
      drawText(scene, str(values, "subtitle"), point.x, point.y + px(scene, 152), { size: 28, weight: 480, fill: rgba(color(values, "textColor", "#F7F7F2"), 0.62), tracking: 1.2 });
      ctx.restore();
    } else {
      const left = point.x;
      ctx.save();
      ctx.translate((1 - p) * px(scene, -54 - 34 * intensity), 0);
      ctx.translate(left, point.y);
      ctx.scale(mix(0.97, 1, easeOutBack(raw, 0.34)), 1);
      ctx.translate(-left, -point.y);
      ctx.filter = motionBlur(scene, raw, 8);
      drawText(scene, String(shownValue), left, point.y + px(scene, 56), { size: num(values, "fontSize", 188), weight: 800 });
      ctx.restore();
      const q = easeOutQuart(phase(scene, 0.24, 0.5));
      ctx.save();
      ctx.globalAlpha *= q;
      ctx.fillStyle = color(values, "accentColor", "#8CA8FF");
      ctx.fillRect(left + px(scene, 420), point.y - px(scene, 9) - px(scene, 105) * q, px(scene, 3), px(scene, 210) * q);
      ctx.restore();
      const unitP = easeOutQuint(phase(scene, 0.36, 0.42));
      ctx.save();
      ctx.globalAlpha *= unitP;
      ctx.translate((1 - unitP) * px(scene, 24), 0);
      drawText(scene, unit, left + px(scene, 470), point.y - px(scene, 14), { size: 58, weight: 720, fill: color(values, "accentColor", "#8CA8FF"), tracking: 0 });
      ctx.restore();
      const captionP = easeOutQuint(phase(scene, 0.48, 0.42));
      ctx.save();
      ctx.globalAlpha *= captionP;
      ctx.translate((1 - captionP) * px(scene, 18), 0);
      drawText(scene, str(values, "subtitle"), left + px(scene, 470), point.y + px(scene, 52), { size: 29, weight: 480, fill: rgba(color(values, "textColor", "#F7F7F2"), 0.65), tracking: 0 });
      ctx.restore();
    }
  }
  function wordByWord(scene) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    const { ctx, values, preset: preset2 } = scene;
    const words = splitHighlightedText(str(values, "title", "Every detail earns its place").trim(), /\s+/gu).slice(0, 14);
    const point = anchor(scene);
    const size = fitSize(scene, [words.join(" ")], num(values, "fontSize", 108), scene.width * 0.84, 34);
    setType(scene, size);
    const gap = px(scene, size * 0.26);
    const widths = words.map((word) => measuredWidth(ctx, word, px(scene, num(values, "tracking", -2))));
    const total = widths.reduce((sum, width) => sum + width, 0) + gap * (words.length - 1);
    const stagger = num(values, "stagger", 0.18);
    let x = preset2.variant === "track" ? num(values, "safeMargin", 8) / 100 * scene.width : point.x - total / 2;
    const starts = [];
    ctx.globalAlpha = overallAlpha(scene);
    const previousAlignment = values.alignment;
    values.alignment = "left";
    words.forEach((word, index) => {
      var _a2, _b2;
      starts.push(x);
      const raw = phase(scene, 0.08 + index * stagger, 0.48);
      const p = easeOutQuint(raw);
      const settle = easeOutBack(raw, 0.34);
      const centerX = x + ((_a2 = widths[index]) != null ? _a2 : 0) / 2;
      ctx.save();
      ctx.globalAlpha *= easeOutQuart(clamp(raw * 1.4));
      ctx.translate(centerX, point.y);
      if (preset2.variant === "rise") {
        ctx.translate(0, (1 - p) * px(scene, 38 + num(values, "intensity", 50) * 0.34));
        ctx.rotate((1 - p) * (index % 2 ? 8e-3 : -8e-3));
      } else {
        ctx.translate((1 - p) * px(scene, -34 - num(values, "intensity", 50) * 0.18), (1 - p) * px(scene, 8));
      }
      ctx.scale(mix(0.985, 1, settle), mix(0.985, 1, settle));
      ctx.translate(-centerX, -point.y);
      ctx.filter = motionBlur(scene, raw, preset2.variant === "rise" ? 7 : 5);
      drawText(scene, word, x, point.y, {
        size
      });
      ctx.restore();
      x += ((_b2 = widths[index]) != null ? _b2 : 0) + gap;
    });
    values.alignment = previousAlignment != null ? previousAlignment : "center";
    if (preset2.variant === "track" && words.length > 0) {
      const markerAlpha = easeOutQuint(phase(scene, 0.12, 0.32));
      const markerTime = Math.max(0, (scene.time - 0.08) / Math.max(stagger, 0.08));
      const markerIndex = Math.min(words.length - 1, Math.floor(markerTime));
      const nextIndex = Math.min(words.length - 1, markerIndex + 1);
      const travel = easeInOutCubic(markerTime - Math.floor(markerTime));
      const markerX = mix((_b = (_a = starts[markerIndex]) != null ? _a : starts[0]) != null ? _b : 0, (_d = (_c = starts[nextIndex]) != null ? _c : starts[markerIndex]) != null ? _d : 0, travel);
      const markerWidth = mix((_e = widths[markerIndex]) != null ? _e : 0, (_g = (_f = widths[nextIndex]) != null ? _f : widths[markerIndex]) != null ? _g : 0, travel);
      const railY = point.y + px(scene, 42);
      ctx.save();
      ctx.globalAlpha *= markerAlpha;
      ctx.fillStyle = rgba(color(values, "textColor", "#F7F7F2"), 0.11);
      roundRect(ctx, (_h = starts[0]) != null ? _h : 0, railY, total, px(scene, 3), px(scene, 2));
      ctx.fill();
      ctx.fillStyle = color(values, "accentColor", "#8CA8FF");
      ctx.shadowColor = rgba(color(values, "accentColor", "#8CA8FF"), 0.28);
      ctx.shadowBlur = px(scene, 12);
      roundRect(ctx, markerX, railY - px(scene, 1), markerWidth, px(scene, 5), px(scene, 3));
      ctx.fill();
      ctx.restore();
    }
  }
  function rapidReplacement(scene) {
    var _a, _b;
    const { ctx, values, preset: preset2 } = scene;
    const items = splitHighlightedText(str(values, "sequenceText", "FOCUSED\nFLUID\nFAMILIAR\nYOURS"), /\n/g).filter(Boolean).slice(0, 8);
    if (items.length === 0) return;
    const intro = Math.min(0.14, num(values, "entrance", 0.55) * 0.22);
    const available = Math.max(0.4, scene.duration - num(values, "exit", 0.5) - intro);
    const slot = available / items.length;
    const raw = clamp((scene.time - intro) / Math.max(slot, 0.01), 0, items.length - 1e-4);
    const index = Math.min(items.length - 1, Math.floor(raw));
    const local = raw - index;
    const point = anchor(scene);
    const overlapStart = preset2.variant === "swaps" ? 0.7 : 0.76;
    const firstIn = index === 0 ? easeOutQuint(clamp(local / 0.22)) : 1;
    const nextRaw = index < items.length - 1 ? clamp((local - overlapStart) / (1 - overlapStart)) : 0;
    const transitionP = easeInOutCubic(nextRaw);
    const outP = index < items.length - 1 ? preset2.variant === "swaps" ? transitionP : easeInQuart(nextRaw) : 0;
    const nextP = preset2.variant === "swaps" ? transitionP : easeOutQuint(nextRaw);
    const baseAlpha = overallAlpha(scene);
    const drawItem = (text, entrance, exit, incoming, transition) => {
      ctx.save();
      ctx.globalAlpha = baseAlpha * entrance * (1 - exit);
      if (preset2.variant === "swaps") {
        ctx.beginPath();
        ctx.rect(0, point.y - px(scene, 170), scene.width, px(scene, 340));
        ctx.clip();
        const travel = px(scene, 164);
        const y = (1 - entrance) * px(scene, 112) + (incoming ? (1 - transition) * travel : -transition * travel);
        ctx.translate(point.x, point.y);
        ctx.translate(0, y);
        ctx.rotate((incoming ? -1 : 1) * Math.sin(Math.PI * transition) * 8e-3);
        ctx.scale(mix(0.985, 1, entrance), mix(0.985, 1, entrance));
        ctx.translate(-point.x, -point.y);
        ctx.filter = "blur(".concat(Math.max(0, 1 - entrance) * px(scene, 5) + Math.sin(Math.PI * transition) * px(scene, 4), "px)");
      } else {
        ctx.translate(point.x, point.y);
        ctx.translate((1 - entrance) * px(scene, 34) - exit * px(scene, 28), 0);
        const scale = mix(0.965, 1, easeOutBack(entrance, 0.22)) + exit * 0.018;
        ctx.scale(scale, scale);
        ctx.translate(-point.x, -point.y);
        ctx.filter = "blur(".concat(px(scene, 4) * Math.max(1 - entrance, exit), "px)");
      }
      drawLines(scene, text, point.x, point.y, { progress: 1 });
      ctx.restore();
    };
    drawItem((_a = items[index]) != null ? _a : "", firstIn, outP, false, transitionP);
    if (index < items.length - 1 && nextRaw > 0) {
      drawItem((_b = items[index + 1]) != null ? _b : "", nextP, 0, true, transitionP);
    }
    if (preset2.variant === "cuts") {
      const pulse = easeOutQuart(clamp(local / 0.12)) * (1 - easeInQuart(clamp((local - 0.16) / 0.2)));
      ctx.save();
      ctx.globalAlpha = baseAlpha * pulse * 0.8;
      ctx.fillStyle = color(values, "accentColor", "#8CA8FF");
      const width = px(scene, 92) * easeOutQuart(clamp(local / 0.12));
      roundRect(ctx, point.x - width / 2, point.y + px(scene, 76), width, px(scene, 4), px(scene, 2));
      ctx.fill();
      ctx.restore();
    }
  }
  function maskedReveal(scene) {
    const { ctx, values, preset: preset2 } = scene;
    const point = anchor(scene);
    const entranceRaw = phase(scene, 0, num(values, "entrance", 0.55) + 0.5);
    ctx.globalAlpha = overallAlpha(scene);
    ctx.save();
    ctx.filter = motionBlur(scene, entranceRaw, preset2.variant === "side" ? 7 : 5);
    drawLines(scene, str(values, "title"), point.x, point.y, {
      progress: entranceRaw,
      reveal: preset2.variant === "side" ? "side" : "up",
      lineDelay: num(values, "stagger", 0.14)
    });
    ctx.restore();
    if (preset2.variant === "side") {
      const p = easeOutQuint(phase(scene, 0.42, 0.5));
      ctx.save();
      ctx.globalAlpha *= p;
      ctx.translate((1 - p) * px(scene, alignment(values) === "right" ? -18 : 18), 0);
      drawText(scene, str(values, "subtitle"), point.x, point.y + px(scene, 206), { size: 27, weight: 460, fill: rgba(color(values, "textColor", "#F7F7F2"), 0.6), tracking: 1 });
      ctx.restore();
    }
  }
  function keywordEmphasis(scene) {
    const { ctx, values, preset: preset2 } = scene;
    const text = str(values, "title", "Clarity makes ideas memorable");
    const words = splitHighlightedText(text.trim(), /\s+/gu).slice(0, 14);
    const point = anchor(scene);
    const size = fitSize(scene, [text], num(values, "fontSize", 104), scene.width * 0.84, 32);
    setType(scene, size);
    const gap = px(scene, size * 0.34);
    const widths = words.map((word) => measuredWidth(ctx, word, px(scene, num(values, "tracking", -2))));
    const total = widths.reduce((sum, value) => sum + value, 0) + gap * Math.max(0, words.length - 1);
    let x = alignment(values) === "left" ? point.x : alignment(values) === "right" ? point.x - total : point.x - total / 2;
    const baseRaw = phase(scene);
    const base = easeOutQuint(baseRaw);
    const accentRaw = phase(scene, num(values, "entrance", 0.55) * 0.62, 0.58);
    const accent = easeOutBack(accentRaw, 0.26);
    ctx.globalAlpha = overallAlpha(scene);
    ctx.save();
    ctx.globalAlpha *= base;
    ctx.translate(0, (1 - base) * px(scene, 20));
    ctx.filter = motionBlur(scene, baseRaw, 5);
    const previous = values.alignment;
    values.alignment = "left";
    words.forEach((word, index) => {
      var _a, _b;
      const selected = highlightedRuns(word).some((run) => run.highlighted);
      word = plainText(word);
      ctx.save();
      if (selected && preset2.variant === "scale") {
        const center = x + ((_a = widths[index]) != null ? _a : 0) / 2;
        ctx.translate(center, point.y);
        const scale = 1 + accent * (num(values, "intensity", 56) / 100) * 0.105;
        ctx.scale(scale, scale);
        ctx.translate(-center, -point.y);
      }
      if (selected && preset2.variant === "color") {
        drawText(scene, word, x, point.y, { size });
        ctx.globalAlpha *= clamp(accentRaw);
        drawText(scene, word, x, point.y, { size, fill: color(values, "accentColor", "#8CA8FF") });
      } else {
        drawText(scene, word, x, point.y, {
          size,
          fill: selected ? color(values, "accentColor", "#8CA8FF") : void 0
        });
      }
      ctx.restore();
      x += ((_b = widths[index]) != null ? _b : 0) + gap;
    });
    values.alignment = previous != null ? previous : "center";
    ctx.restore();
  }
  function headlineTransition(scene) {
    const { ctx, values, preset: preset2 } = scene;
    const entranceRaw = phase(scene);
    const transitionRaw = phase(scene, num(values, "entrance", 0.55) * 0.68, 1.05);
    const t = easeOutQuart(transitionRaw);
    const intensity = num(values, "intensity", 60) / 100;
    const margin = num(values, "safeMargin", 8) / 100 * scene.width;
    const startX = scene.width / 2;
    const startY = scene.height / 2;
    const endX = preset2.variant === "corner" ? margin : margin + px(scene, 54);
    const endY = preset2.variant === "corner" ? scene.height * 0.25 : scene.height * 0.32;
    const startSize = num(values, "fontSize", 150);
    const endSize = preset2.variant === "corner" ? 64 : 72;
    const currentSize = mix(startSize, endSize, t);
    const titleLines = splitHighlightedText(str(values, "title"), /\n/g).slice(0, 8);
    const currentWidth = maxLineWidth(scene, titleLines, currentSize);
    const currentX = mix(startX - currentWidth / 2, endX, t);
    const currentY = mix(startY, endY, t) - Math.sin(Math.PI * t) * px(scene, 18) * intensity;
    ctx.globalAlpha = overallAlpha(scene);
    const priorAlign = values.alignment;
    values.alignment = "left";
    ctx.save();
    ctx.translate(currentX, currentY);
    ctx.rotate(-Math.sin(Math.PI * t) * 8e-3 * intensity);
    ctx.translate(-currentX, -currentY);
    ctx.filter = motionBlur(scene, transitionRaw, 9);
    drawLines(scene, str(values, "title"), currentX, currentY, { size: currentSize, progress: entranceRaw, lineDelay: 0.08, reveal: "fade" });
    ctx.restore();
    values.alignment = priorAlign != null ? priorAlign : "center";
    const ruleP = easeOutQuart(phase(scene, 0.72, 0.62));
    ctx.save();
    ctx.globalAlpha *= ruleP;
    if (preset2.variant === "rail") {
      ctx.fillStyle = color(values, "accentColor", "#8CA8FF");
      roundRect(ctx, margin, scene.height * 0.18, px(scene, 3), scene.height * 0.55 * ruleP, px(scene, 2));
      ctx.fill();
    } else {
      ctx.fillStyle = color(values, "accentColor", "#8CA8FF");
      roundRect(ctx, margin, scene.height * 0.43, scene.width * 0.3 * ruleP, px(scene, 3), px(scene, 2));
      ctx.fill();
    }
    ctx.restore();
    const supportP = easeOutQuint(phase(scene, 0.82, 0.62));
    const supportX = preset2.variant === "corner" ? scene.width * 0.58 : scene.width * 0.56;
    const supportY = preset2.variant === "corner" ? scene.height * 0.57 : scene.height * 0.48;
    const supportAlign = values.alignment;
    values.alignment = "left";
    ctx.save();
    ctx.globalAlpha *= supportP;
    ctx.translate((1 - supportP) * px(scene, 34), 0);
    ctx.filter = motionBlur(scene, phase(scene, 0.82, 0.62), 5);
    drawLines(scene, str(values, "subtitle"), supportX, supportY, { size: 39, weight: 480, progress: supportP, lineDelay: 0.1, reveal: "fade" });
    ctx.restore();
    values.alignment = supportAlign != null ? supportAlign : "center";
  }
  function featureStack(scene) {
    const { ctx, values, preset: preset2 } = scene;
    const items = splitHighlightedText(str(values, "itemsText"), /\n/g).filter(Boolean).slice(0, 7);
    const point = anchor(scene);
    const stagger = num(values, "stagger", preset2.variant === "active" ? 0.72 : 0.28);
    ctx.globalAlpha = overallAlpha(scene);
    const titleRaw = phase(scene, 0.04, 0.42);
    const titleP = easeOutQuint(titleRaw);
    ctx.save();
    ctx.globalAlpha *= titleP;
    ctx.translate((1 - titleP) * px(scene, 20), 0);
    drawText(scene, str(values, "title"), point.x, point.y - px(scene, 190), { size: 28, weight: 650, fill: color(values, "accentColor", "#8CA8FF"), tracking: 3 });
    ctx.restore();
    const size = num(values, "fontSize", 70);
    const firstY = point.y - px(scene, 70);
    let activePosition = 0;
    if (preset2.variant === "active" && items.length > 0) {
      const timeline = Math.max(0, scene.time - 0.48) / Math.max(stagger, 0.15);
      const step = Math.min(items.length - 1, Math.floor(timeline));
      const fraction = timeline - Math.floor(timeline);
      const travel = easeInOutCubic(clamp((fraction - 0.58) / 0.42));
      activePosition = Math.min(items.length - 1, step + travel);
      const indicatorP = easeOutBack(phase(scene, 0.28, 0.42), 0.26);
      const railX = point.x - px(scene, 27);
      ctx.save();
      ctx.globalAlpha *= clamp(indicatorP);
      ctx.strokeStyle = rgba(color(values, "accentColor", "#8CA8FF"), 0.17);
      ctx.lineWidth = px(scene, 2);
      ctx.beginPath();
      ctx.moveTo(railX + px(scene, 3.5), firstY - px(scene, 47));
      ctx.lineTo(railX + px(scene, 3.5), firstY + (items.length - 1) * px(scene, 90) + px(scene, 15));
      ctx.stroke();
      ctx.fillStyle = color(values, "accentColor", "#8CA8FF");
      roundRect(ctx, railX, firstY - px(scene, 48) + activePosition * px(scene, 90), px(scene, 7), px(scene, 62), px(scene, 4));
      ctx.shadowColor = rgba(color(values, "accentColor", "#8CA8FF"), 0.35);
      ctx.shadowBlur = px(scene, 18);
      ctx.fill();
      ctx.restore();
    }
    items.forEach((item, index) => {
      const y = firstY + index * px(scene, 90);
      const raw = phase(scene, 0.16 + index * (preset2.variant === "active" ? 0.07 : stagger), 0.46);
      const p = easeOutQuint(raw);
      const proximity = clamp(1 - Math.abs(index - activePosition));
      const activeWeight = easeInOutCubic(proximity);
      ctx.save();
      ctx.globalAlpha *= (preset2.variant === "active" ? mix(0.34, 1, activeWeight) : 1) * p;
      ctx.translate((1 - p) * px(scene, 46), (1 - p) * px(scene, 6));
      ctx.rotate((1 - p) * 6e-3);
      ctx.filter = motionBlur(scene, raw, 4);
      if (preset2.variant === "accumulate") {
        const bulletScale = easeOutBack(raw, 0.42);
        ctx.strokeStyle = rgba(color(values, "accentColor", "#8CA8FF"), 0.6);
        ctx.lineWidth = px(scene, 2);
        ctx.beginPath();
        ctx.arc(point.x - px(scene, 24), y - px(scene, 16), Math.max(0, px(scene, 6) * bulletScale), 0, TAU);
        ctx.stroke();
      }
      drawText(scene, item, point.x, y, { size, weight: preset2.variant === "active" && activeWeight > 0.55 ? 700 : 560 });
      ctx.restore();
    });
  }
  function drawTile(scene, x, y, width, height, text, index, progress, accent = false) {
    const { ctx, values } = scene;
    const raw = clamp((progress - index * num(values, "stagger", 0.12)) / Math.max(0.2, 1 - index * 0.1));
    const p = easeOutQuart(raw);
    const shapeP = easeOutBack(raw, 0.5);
    const contentRaw = clamp((raw - 0.22) / 0.78);
    const contentP = easeOutQuint(contentRaw);
    ctx.save();
    ctx.globalAlpha *= p;
    const offset = px(scene, 34 + num(values, "intensity", 58) * 0.32) * (1 - p);
    const startWidth = Math.min(width, Math.max(px(scene, 86), width * 0.34));
    const startHeight = Math.min(height, Math.max(px(scene, 38), height * 0.18));
    const currentWidth = mix(startWidth, width, shapeP);
    const currentHeight = mix(startHeight, height, shapeP);
    const currentX = x + (width - currentWidth) / 2;
    const currentY = y + (height - currentHeight) / 2;
    const targetRadius = px(scene, num(values, "cornerRadius", 28));
    const radius = mix(startHeight / 2, targetRadius, p);
    ctx.translate(x + width / 2, y + height / 2);
    ctx.translate(0, offset);
    ctx.rotate((1 - p) * (index % 2 ? 0.012 : -0.012));
    ctx.translate(-(x + width / 2), -(y + height / 2));
    roundRect(ctx, currentX, currentY, currentWidth, currentHeight, radius);
    ctx.fillStyle = accent ? rgba(color(values, "accentColor", "#8CA8FF"), 0.92) : rgba(color(values, "textColor", "#F7F7F2"), 0.075);
    ctx.shadowColor = "rgba(8, 10, 18, 0.24)";
    ctx.shadowBlur = px(scene, 34);
    ctx.shadowOffsetY = px(scene, 12) * (1 - p * 0.55);
    ctx.fill();
    ctx.shadowColor = "rgba(0, 0, 0, 0)";
    ctx.strokeStyle = accent ? rgba(color(values, "textColor", "#F7F7F2"), 0.18) : rgba(color(values, "textColor", "#F7F7F2"), 0.12);
    ctx.lineWidth = px(scene, 1.5);
    ctx.stroke();
    ctx.save();
    roundRect(ctx, currentX, currentY, currentWidth, currentHeight, radius);
    ctx.clip();
    ctx.globalAlpha *= contentP;
    ctx.translate(0, (1 - contentP) * px(scene, 18));
    ctx.filter = motionBlur(scene, contentRaw, 4);
    const old = values.alignment;
    values.alignment = "left";
    drawLines(scene, text, x + px(scene, 34), y + height / 2 + px(scene, 12), {
      size: Math.min(58, num(values, "fontSize", 92) * 0.52),
      weight: 650,
      fill: accent ? "#111218" : void 0,
      progress: 1
    });
    values.alignment = old != null ? old : "center";
    ctx.restore();
    ctx.restore();
  }
  function bento(scene) {
    const { ctx, values, preset: preset2 } = scene;
    const margin = num(values, "safeMargin", 8) / 100 * scene.width;
    const gap = px(scene, 18);
    const p = phase(scene, 0.05, 1.22);
    ctx.globalAlpha = overallAlpha(scene);
    if (preset2.variant === "mosaic") {
      const leadW = scene.width * 0.39;
      const x = margin;
      const y = scene.height * 0.19;
      const h = scene.height * 0.62;
      const old = values.alignment;
      values.alignment = "left";
      drawLines(scene, str(values, "title"), x, scene.height * 0.48, { size: num(values, "fontSize", 92), progress: easeOutQuint(p), reveal: "up" });
      values.alignment = old != null ? old : "center";
      const gx = x + leadW + gap;
      const gw = scene.width - margin - gx;
      drawTile(scene, gx, y, gw * 0.57, h * 0.52 - gap / 2, str(values, "tile1"), 0, p, true);
      drawTile(scene, gx + gw * 0.57 + gap, y, gw * 0.43 - gap, h * 0.52 - gap / 2, str(values, "tile2"), 1, p);
      drawTile(scene, gx, y + h * 0.52 + gap / 2, gw * 0.42, h * 0.48 - gap / 2, str(values, "tile3"), 2, p);
      drawTile(scene, gx + gw * 0.42 + gap, y + h * 0.52 + gap / 2, gw * 0.58 - gap, h * 0.48 - gap / 2, str(values, "tile4"), 3, p);
    } else {
      const x = margin;
      const y = scene.height * 0.17;
      const width = scene.width - margin * 2;
      const height = scene.height * 0.66;
      const leadW = width * 0.46;
      drawTile(scene, x, y, leadW, height, str(values, "title"), 0, p, true);
      const rx = x + leadW + gap;
      const rw = width - leadW - gap;
      drawTile(scene, rx, y, rw, height * 0.36 - gap / 2, str(values, "tile1"), 1, p);
      drawTile(scene, rx, y + height * 0.36 + gap / 2, rw * 0.5 - gap / 2, height * 0.64 - gap / 2, "".concat(str(values, "tile2"), "\n").concat(str(values, "tile3")), 2, p);
      drawTile(scene, rx + rw * 0.5 + gap / 2, y + height * 0.36 + gap / 2, rw * 0.5 - gap / 2, height * 0.64 - gap / 2, str(values, "tile4"), 3, p);
    }
  }
  function productCallout(scene) {
    const { ctx, values, preset: preset2 } = scene;
    const ax = num(values, "anchorX", 60) / 100 * scene.width;
    const ay = num(values, "anchorY", 45) / 100 * scene.height;
    const requestedLabelX = num(values, "labelX", 74) / 100 * scene.width;
    const ly = num(values, "labelY", 30) / 100 * scene.height;
    const labelText = str(values, "label");
    const subtitleText = str(values, "subtitle");
    const labelSize = fitSize(scene, [labelText], num(values, "fontSize", 64), scene.width * 0.74, 26);
    const labelAlign = requestedLabelX < ax ? "right" : "left";
    const oldAlignment = values.alignment;
    values.alignment = labelAlign;
    setType(scene, labelSize, 720);
    const labelWidth = measuredWidth(ctx, labelText, px(scene, num(values, "tracking", -2)));
    setType(scene, 25, 470);
    const subtitleWidth = measuredWidth(ctx, subtitleText, 0);
    const blockWidth = Math.max(labelWidth, subtitleWidth);
    const safe = num(values, "safeMargin", 8) / 100 * scene.width;
    const lx = labelAlign === "right" ? clamp(requestedLabelX, safe + blockWidth, scene.width - safe) : clamp(requestedLabelX, safe, scene.width - safe - blockWidth);
    const anchorRaw = phase(scene, 0.02, 0.34);
    const anchorP = easeOutBack(anchorRaw, 0.34);
    const pathRaw = phase(scene, 0.1, 0.72);
    const p = easeOutQuart(pathRaw);
    const qRaw = phase(scene, 0.48, 0.5);
    const q = easeOutQuint(qRaw);
    ctx.globalAlpha = overallAlpha(scene);
    ctx.strokeStyle = color(values, "accentColor", "#8CA8FF");
    ctx.fillStyle = ctx.strokeStyle;
    ctx.lineWidth = px(scene, 2.5);
    if (preset2.variant === "pin") {
      ctx.save();
      ctx.globalAlpha *= clamp(anchorP);
      ctx.beginPath();
      ctx.arc(ax, ay, Math.max(0, px(scene, 7) * anchorP), 0, TAU);
      ctx.fill();
      const pulse = Math.sin(Math.PI * anchorRaw) * (1 - pathRaw);
      ctx.globalAlpha *= pulse * 0.45;
      ctx.beginPath();
      ctx.arc(ax, ay, px(scene, mix(10, 24, anchorRaw)), 0, TAU);
      ctx.stroke();
      ctx.restore();
      ctx.beginPath();
      ctx.moveTo(ax, ay);
      ctx.lineTo(mix(ax, lx, p), mix(ay, ly, p));
      ctx.stroke();
    } else {
      const radius = px(scene, 18);
      const ringP = easeOutQuart(phase(scene, 0.02, 0.44));
      ctx.beginPath();
      ctx.arc(ax, ay, radius * mix(0.72, 1, anchorP), -Math.PI / 2, -Math.PI / 2 + TAU * ringP);
      ctx.stroke();
      const elbowX = mix(ax, lx, 0.48);
      const firstLeg = easeOutQuart(clamp(pathRaw / 0.4));
      const secondLeg = easeInOutCubic(clamp((pathRaw - 0.3) / 0.42));
      const finalLeg = easeOutQuart(clamp((pathRaw - 0.64) / 0.36));
      ctx.beginPath();
      ctx.moveTo(ax + (lx > ax ? radius : -radius), ay);
      ctx.lineTo(mix(ax, elbowX, firstLeg), ay);
      if (pathRaw > 0.3) {
        ctx.lineTo(elbowX, mix(ay, ly, secondLeg));
      }
      if (pathRaw > 0.64) {
        ctx.lineTo(mix(elbowX, lx, finalLeg), ly);
      }
      ctx.stroke();
    }
    ctx.save();
    ctx.globalAlpha *= q;
    ctx.translate((1 - q) * px(scene, labelAlign === "right" ? -22 : 22), 0);
    ctx.filter = motionBlur(scene, qRaw, 4);
    drawText(scene, labelText, lx, ly - px(scene, 16), { size: labelSize, weight: 720 });
    ctx.restore();
    const subtitleP = easeOutQuint(phase(scene, 0.6, 0.46));
    ctx.save();
    ctx.globalAlpha *= subtitleP;
    ctx.translate((1 - subtitleP) * px(scene, labelAlign === "right" ? -15 : 15), 0);
    drawText(scene, subtitleText, lx, ly + px(scene, 40), { size: 25, weight: 470, fill: rgba(color(values, "textColor", "#F7F7F2"), 0.62), tracking: 0 });
    ctx.restore();
    values.alignment = oldAlignment != null ? oldAlignment : "center";
  }
  function performanceComparison(scene) {
    const { ctx, values, preset: preset2 } = scene;
    const margin = num(values, "safeMargin", 8) / 100 * scene.width;
    const a = Math.max(0, num(values, "valueA", 64));
    const b = Math.max(0, num(values, "valueB", 100));
    const max = Math.max(1, a, b);
    const baseAlpha = overallAlpha(scene);
    const titleRaw = phase(scene, 0.02, 0.48);
    const titleP = easeOutQuint(titleRaw);
    ctx.globalAlpha = baseAlpha;
    const old = values.alignment;
    if (preset2.variant === "bars") {
      values.alignment = "left";
      ctx.save();
      ctx.globalAlpha *= titleP;
      ctx.translate((1 - titleP) * px(scene, -24), 0);
      ctx.filter = motionBlur(scene, titleRaw, 5);
      drawText(scene, str(values, "title"), margin, scene.height * 0.25, { size: num(values, "fontSize", 82), weight: 760 });
      ctx.restore();
      const barX = margin + px(scene, 260);
      const barW = scene.width - barX - margin - px(scene, 110);
      [
        { label: str(values, "labelA"), value: a, y: scene.height * 0.48, fill: color(values, "accentColor2", "#C59CFF") },
        { label: str(values, "labelB"), value: b, y: scene.height * 0.65, fill: color(values, "accentColor", "#8CA8FF") }
      ].forEach((item, index) => {
        const raw = phase(scene, 0.2 + index * 0.16, 0.86);
        const p = easeOutQuart(raw);
        const labelP = easeOutQuint(phase(scene, 0.12 + index * 0.14, 0.42));
        ctx.save();
        ctx.globalAlpha *= labelP;
        ctx.translate((1 - labelP) * px(scene, -16), 0);
        drawText(scene, item.label, margin, item.y + px(scene, 18), { size: 29, weight: 520, tracking: 0 });
        ctx.restore();
        ctx.save();
        ctx.globalAlpha *= easeOutQuint(clamp(raw * 1.7));
        ctx.fillStyle = rgba(item.fill, 0.18);
        roundRect(ctx, barX, item.y - px(scene, 25), barW, px(scene, 54), px(scene, 27));
        ctx.fill();
        const width = barW * (item.value / max) * p;
        if (width > 0.5) {
          ctx.fillStyle = item.fill;
          ctx.shadowColor = rgba(item.fill, 0.18);
          ctx.shadowBlur = px(scene, 16) * Math.sin(Math.PI * raw);
          roundRect(ctx, barX, item.y - px(scene, 25), width, px(scene, 54), px(scene, 27));
          ctx.fill();
        }
        ctx.restore();
        ctx.save();
        ctx.globalAlpha *= easeOutQuint(clamp((raw - 0.08) / 0.5));
        values.alignment = "right";
        drawText(scene, String(Math.round(item.value * p)), scene.width - margin, item.y + px(scene, 19), { size: 36, weight: 720, tracking: 0 });
        ctx.restore();
        values.alignment = "left";
      });
    } else {
      values.alignment = "center";
      ctx.save();
      ctx.globalAlpha *= titleP;
      ctx.translate(0, (1 - titleP) * px(scene, 18));
      drawText(scene, str(values, "title"), scene.width / 2, scene.height * 0.25, { size: num(values, "fontSize", 76), weight: 730 });
      ctx.restore();
      const center = scene.width / 2;
      const ruleP = easeOutQuart(phase(scene, 0.2, 0.7));
      ctx.fillStyle = color(values, "accentColor", "#8CA8FF");
      ctx.fillRect(center - px(scene, 1.5), scene.height * 0.555 - scene.height * 0.165 * ruleP, px(scene, 3), scene.height * 0.33 * ruleP);
      [
        { x: center - scene.width * 0.22, value: a, label: str(values, "labelA"), fill: color(values, "accentColor2", "#C59CFF"), delay: 0.2 },
        { x: center + scene.width * 0.22, value: b, label: str(values, "labelB"), fill: color(values, "accentColor", "#8CA8FF"), delay: 0.3 }
      ].forEach((item) => {
        const raw = phase(scene, item.delay, 0.72);
        const countP = easeOutQuart(raw);
        const settle = settledScale(raw, 0.86, 0.01);
        ctx.save();
        ctx.globalAlpha *= easeOutQuint(clamp(raw * 1.35));
        ctx.translate(item.x, scene.height * 0.58);
        ctx.translate(0, (1 - countP) * px(scene, 26));
        ctx.scale(settle, settle);
        ctx.translate(-item.x, -scene.height * 0.58);
        ctx.filter = motionBlur(scene, raw, 6);
        drawText(scene, String(Math.round(item.value * countP)), item.x, scene.height * 0.58, { size: 126, weight: 800, fill: item.fill, tracking: -3 });
        ctx.restore();
        const labelP = easeOutQuint(phase(scene, item.delay + 0.22, 0.42));
        ctx.save();
        ctx.globalAlpha *= labelP;
        ctx.translate(0, (1 - labelP) * px(scene, 12));
        drawText(scene, item.label, item.x, scene.height * 0.67, { size: 28, weight: 500, fill: rgba(color(values, "textColor", "#F7F7F2"), 0.66), tracking: 0 });
        ctx.restore();
      });
    }
    const footnoteP = easeOutQuint(phase(scene, 0.68, 0.5));
    values.alignment = "center";
    ctx.save();
    ctx.globalAlpha *= footnoteP;
    ctx.translate(0, (1 - footnoteP) * px(scene, 10));
    drawText(scene, str(values, "footnote"), scene.width / 2, scene.height - margin * 0.7, { size: 22, weight: 430, fill: rgba(color(values, "textColor", "#F7F7F2"), 0.45), tracking: 0.4 });
    ctx.restore();
    values.alignment = old != null ? old : "center";
  }
  function presenter(scene) {
    const { ctx, values, preset: preset2 } = scene;
    const point = anchor(scene);
    const raw = phase(scene, 0.04, num(values, "entrance", 0.55) + 0.08);
    const p = easeOutQuint(raw);
    const side = preset2.variant === "right" ? -1 : 1;
    ctx.globalAlpha = overallAlpha(scene);
    ctx.save();
    ctx.translate(point.x, point.y);
    ctx.translate(side * (1 - p) * px(scene, 42 + num(values, "intensity", 42) * 0.22), (1 - p) * px(scene, 12));
    ctx.rotate(side * (1 - p) * -0.018);
    const groupScale = mix(0.975, 1, easeOutBack(raw, 0.3));
    ctx.scale(groupScale, groupScale);
    ctx.translate(-point.x, -point.y);
    ctx.filter = motionBlur(scene, raw, 6);
    const barX = point.x + (preset2.variant === "right" ? px(scene, 23) : -px(scene, 29));
    const markP = easeOutBack(phase(scene, 0.02, 0.48), 0.3);
    const markHeight = px(scene, mix(10, 92, markP));
    ctx.fillStyle = color(values, "accentColor", "#8CA8FF");
    roundRect(ctx, barX, point.y - px(scene, 24) - markHeight / 2, px(scene, 6), markHeight, px(scene, 3));
    ctx.fill();
    const nameP = easeOutQuint(phase(scene, 0.11, 0.44));
    ctx.save();
    ctx.globalAlpha *= nameP;
    ctx.translate(side * (1 - nameP) * px(scene, 18), 0);
    drawText(scene, str(values, "name"), point.x, point.y - px(scene, 18), { size: num(values, "fontSize", 58), weight: 690 });
    ctx.restore();
    const roleP = easeOutQuint(phase(scene, 0.24, 0.44));
    ctx.save();
    ctx.globalAlpha *= roleP;
    ctx.translate(side * (1 - roleP) * px(scene, 14), 0);
    drawText(scene, str(values, "role"), point.x, point.y + px(scene, 37), { size: 28, weight: 470, fill: rgba(color(values, "textColor", "#F7F7F2"), 0.62), tracking: 0 });
    ctx.restore();
    ctx.restore();
  }
  function price(scene) {
    const { ctx, values, preset: preset2 } = scene;
    const point = anchor(scene);
    const stagger = num(values, "stagger", 0.2);
    const p1Raw = phase(scene, 0.05, 0.48);
    const p2Raw = phase(scene, 0.05 + stagger, 0.54);
    const p3Raw = phase(scene, 0.05 + stagger * 2, 0.5);
    const p1 = easeOutQuint(p1Raw);
    const p2 = easeOutBack(p2Raw, 0.4);
    const p3 = easeOutQuint(p3Raw);
    ctx.globalAlpha = overallAlpha(scene);
    if (preset2.variant === "center") {
      ctx.save();
      ctx.globalAlpha *= p1;
      ctx.translate(0, (1 - p1) * px(scene, 34));
      ctx.filter = motionBlur(scene, p1Raw, 4);
      drawText(scene, str(values, "product"), point.x, point.y - px(scene, 142), { size: 32, weight: 650, fill: color(values, "accentColor", "#8CA8FF"), tracking: 3 });
      ctx.restore();
      ctx.save();
      ctx.globalAlpha *= clamp(p2);
      ctx.translate(point.x, point.y + px(scene, 10));
      ctx.translate(0, (1 - easeOutQuint(p2Raw)) * px(scene, 24));
      const priceScale = settledScale(p2Raw, 0.89, 0.012);
      ctx.scale(priceScale, priceScale);
      ctx.translate(-point.x, -(point.y + px(scene, 10)));
      ctx.filter = motionBlur(scene, p2Raw, 7);
      drawText(scene, str(values, "price"), point.x, point.y + px(scene, 10), { size: num(values, "fontSize", 92), weight: 780 });
      ctx.restore();
      setType(scene, 35, 570);
      const availabilityText = str(values, "availability");
      const availabilityWidth = measuredWidth(ctx, availabilityText, 0) + px(scene, 48);
      const capsuleHeight = px(scene, 58);
      const capsuleWidth = mix(capsuleHeight, availabilityWidth, easeOutBack(p3Raw, 0.22));
      ctx.save();
      ctx.globalAlpha *= p3;
      roundRect(ctx, point.x - capsuleWidth / 2, point.y + px(scene, 55), capsuleWidth, capsuleHeight, capsuleHeight / 2);
      ctx.fillStyle = rgba(color(values, "accentColor", "#8CA8FF"), 0.11);
      ctx.fill();
      ctx.strokeStyle = rgba(color(values, "accentColor", "#8CA8FF"), 0.3);
      ctx.lineWidth = px(scene, 1.5);
      ctx.stroke();
      ctx.restore();
      const availabilityP = easeOutQuint(phase(scene, 0.11 + stagger * 2, 0.4));
      ctx.save();
      ctx.globalAlpha *= availabilityP;
      ctx.translate(0, (1 - availabilityP) * px(scene, 10));
      drawText(scene, availabilityText, point.x, point.y + px(scene, 96), { size: 35, weight: 570, tracking: 0 });
      ctx.restore();
      const subtitleP = easeOutQuint(phase(scene, 0.2 + stagger * 2, 0.4));
      ctx.save();
      ctx.globalAlpha *= subtitleP;
      drawText(scene, str(values, "subtitle"), point.x, point.y + px(scene, 160), { size: 24, weight: 450, fill: rgba(color(values, "textColor", "#F7F7F2"), 0.5), tracking: 0 });
      ctx.restore();
    } else {
      const old = values.alignment;
      values.alignment = "left";
      ctx.save();
      ctx.globalAlpha *= p1;
      ctx.translate((1 - p1) * px(scene, -18), 0);
      drawText(scene, str(values, "product"), point.x, point.y - px(scene, 118), { size: 32, weight: 650, fill: color(values, "accentColor", "#8CA8FF"), tracking: 3 });
      ctx.restore();
      const subtitleP = easeOutQuint(phase(scene, 0.14, 0.44));
      ctx.save();
      ctx.globalAlpha *= subtitleP;
      ctx.translate((1 - subtitleP) * px(scene, -14), 0);
      drawText(scene, str(values, "subtitle"), point.x, point.y - px(scene, 70), { size: 24, weight: 450, fill: rgba(color(values, "textColor", "#F7F7F2"), 0.52), tracking: 0 });
      ctx.restore();
      ctx.save();
      ctx.globalAlpha *= clamp(p2);
      ctx.translate(point.x, point.y + px(scene, 42));
      ctx.translate((1 - easeOutQuint(p2Raw)) * px(scene, 48), 0);
      ctx.scale(mix(0.96, 1, p2), mix(0.96, 1, p2));
      ctx.translate(-point.x, -(point.y + px(scene, 42)));
      ctx.filter = motionBlur(scene, p2Raw, 6);
      drawText(scene, str(values, "price"), point.x, point.y + px(scene, 42), { size: num(values, "fontSize", 88), weight: 790 });
      ctx.restore();
      ctx.save();
      ctx.globalAlpha *= p3;
      ctx.fillStyle = color(values, "accentColor", "#8CA8FF");
      ctx.fillRect(scene.width * 0.66, point.y - px(scene, 20) - px(scene, 75) * p3, px(scene, 3), px(scene, 150) * p3);
      ctx.translate((1 - p3) * px(scene, 20), 0);
      drawText(scene, str(values, "availability"), scene.width * 0.71, point.y + px(scene, 4), { size: 34, weight: 560, tracking: 0 });
      ctx.restore();
      values.alignment = old != null ? old : "center";
    }
  }
  function lightSweep(scene) {
    const { ctx, values, preset: preset2 } = scene;
    const point = anchor(scene);
    const title = str(values, "title", "LIGHT, PRECISELY");
    const size = fitSize(scene, [title], num(values, "fontSize", 126), scene.width * 0.86, 34);
    const base = overallAlpha(scene);
    const titleRaw = phase(scene, 0, 0.64);
    const titleP = easeOutQuint(titleRaw);
    ctx.save();
    ctx.globalAlpha = base * titleP;
    ctx.translate(0, (1 - titleP) * px(scene, 14));
    ctx.filter = motionBlur(scene, titleRaw, 4);
    drawText(scene, title, point.x, point.y, { size, weight: num(values, "fontWeight", 720), fill: rgba(color(values, "textColor", "#F7F7F2"), 0.48) });
    ctx.restore();
    const activeStart = num(values, "entrance", 0.55) * 0.5;
    const activeLength = Math.max(0.7, scene.duration - num(values, "exit", 0.5) - activeStart);
    let sweep = clamp((scene.time - activeStart) / activeLength);
    if (preset2.variant === "loop" || bool(values, "loop", false)) sweep = sweep * 2 % 1;
    const x = mix(-scene.width * 0.2, scene.width * 1.2, easeInOutCubic(sweep));
    const spread = scene.width * mix(0.16, 0.3, num(values, "intensity", 48) / 100);
    ctx.save();
    ctx.globalAlpha = base * titleP * 0.92;
    const gradient = ctx.createLinearGradient(x - spread, 0, x + spread, 0);
    gradient.addColorStop(0, rgba(color(values, "accentColor2", "#C59CFF"), 0));
    gradient.addColorStop(0.36, rgba(color(values, "accentColor2", "#C59CFF"), 0.5));
    gradient.addColorStop(0.5, rgba(color(values, "textColor", "#F7F7F2"), 0.96));
    gradient.addColorStop(0.64, rgba(color(values, "accentColor", "#8CA8FF"), 0.56));
    gradient.addColorStop(1, rgba(color(values, "accentColor", "#8CA8FF"), 0));
    ctx.fillStyle = gradient;
    ctx.globalCompositeOperation = "source-over";
    ctx.shadowColor = rgba(color(values, "textColor", "#F7F7F2"), 0.14);
    ctx.shadowBlur = px(scene, 18) * Math.sin(Math.PI * sweep);
    drawText(scene, title, point.x, point.y, { size, fill: gradient });
    ctx.restore();
  }
  function softFocus(scene) {
    const { ctx, values, preset: preset2 } = scene;
    const point = anchor(scene);
    ctx.globalAlpha = overallAlpha(scene);
    if (preset2.variant === "whole") {
      const raw = phase(scene, 0, 0.94);
      const p = easeOutQuint(raw);
      ctx.save();
      ctx.filter = "blur(".concat((1 - p) * px(scene, 18 + num(values, "intensity", 46) * 0.18), "px)");
      ctx.translate(point.x, point.y);
      ctx.translate(0, (1 - p) * px(scene, 24));
      const scale = mix(1.035, 1, easeOutQuart(raw));
      ctx.scale(scale, scale);
      ctx.translate(-point.x, -point.y);
      drawLines(scene, str(values, "title"), point.x, point.y, { progress: raw, reveal: "fade" });
      ctx.restore();
      const subtitleRaw = phase(scene, 0.5, 0.52);
      const subtitleP = easeOutQuint(subtitleRaw);
      ctx.save();
      ctx.globalAlpha *= subtitleP;
      ctx.translate(0, (1 - subtitleP) * px(scene, 14));
      ctx.filter = motionBlur(scene, subtitleRaw, 3);
      drawText(scene, str(values, "subtitle"), point.x, point.y + px(scene, 118), { size: 27, weight: 460, fill: rgba(color(values, "textColor", "#F7F7F2"), 0.58), tracking: 1 });
      ctx.restore();
    } else {
      const words = splitHighlightedText(str(values, "title", "SEE THE WHOLE IDEA"), /\s+/gu).slice(0, 10);
      const size = fitSize(scene, [words.join(" ")], num(values, "fontSize", 114), scene.width * 0.84, 34);
      setType(scene, size);
      const gap = px(scene, size * 0.25);
      const widths = words.map((word) => measuredWidth(ctx, word, px(scene, num(values, "tracking", -2))));
      const total = widths.reduce((sum, width) => sum + width, 0) + gap * (words.length - 1);
      let x = point.x - total / 2;
      const oldAlignment = values.alignment;
      values.alignment = "left";
      words.forEach((word, index) => {
        var _a, _b;
        const raw = phase(scene, 0.04 + index * num(values, "stagger", 0.2), 0.68);
        const p = easeOutQuint(raw);
        const settle = easeOutBack(raw, 0.28);
        ctx.save();
        ctx.globalAlpha *= p;
        ctx.filter = "blur(".concat((1 - p) * px(scene, 16), "px)");
        const centerX = x + ((_a = widths[index]) != null ? _a : 0) / 2;
        ctx.translate(centerX, point.y);
        ctx.translate(0, (1 - p) * px(scene, 20));
        const scale = mix(0.975, 1, settle);
        ctx.scale(scale, scale);
        ctx.translate(-centerX, -point.y);
        drawText(scene, word, x, point.y, { size });
        ctx.restore();
        x += ((_b = widths[index]) != null ? _b : 0) + gap;
      });
      values.alignment = oldAlignment != null ? oldAlignment : "center";
    }
  }
  var familyRenderers = {
    "hero-headline": hero,
    "specification-reveal": specification,
    "word-by-word": wordByWord,
    "rapid-replacement": rapidReplacement,
    "masked-line-reveal": maskedReveal,
    "keyword-emphasis": keywordEmphasis,
    "headline-layout-transition": headlineTransition,
    "feature-stack": featureStack,
    "bento-summary": bento,
    "product-callout": productCallout,
    "performance-comparison": performanceComparison,
    "presenter-title": presenter,
    "price-availability": price,
    "light-sweep": lightSweep,
    "soft-focus": softFocus
  };
  function renderFrame(ctx, config2, timeSeconds) {
    const preset2 = presetById.get(config2.presetId);
    if (!preset2) throw new Error("Unknown preset: ".concat(config2.presetId));
    const values = valuesForPreset(config2.presetId, config2.values);
    const width = Math.max(16, config2.width);
    const height = Math.max(16, config2.height);
    const scene = {
      ctx,
      width,
      height,
      scale: Math.max(0.1, Math.min(width / 1920, height / 1080)),
      time: clamp(timeSeconds, 0, config2.duration),
      duration: Math.max(0.1, config2.duration),
      values,
      preset: preset2,
      diagnostics: { warnings: [], overflow: false }
    };
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    ctx.filter = "none";
    paintBackground(scene, config2);
    applyExitMotion(scene);
    familyRenderers[preset2.family](scene);
    ctx.restore();
    return scene.diagnostics;
  }
  function aspectDimensions(aspect, longEdge = 1280) {
    if (aspect === "9:16") return { width: Math.round(longEdge * 9 / 16), height: longEdge };
    if (aspect === "1:1") return { width: longEdge, height: longEdge };
    return { width: longEdge, height: Math.round(longEdge * 9 / 16) };
  }

  // src/renderer/frame.ts
  var canvasElement = document.querySelector("#stage");
  if (!canvasElement) throw new Error("Renderer canvas is missing.");
  var canvas = canvasElement;
  var renderingContext = canvas.getContext("2d", { alpha: true });
  if (!renderingContext) throw new Error("2D canvas rendering is unavailable.");
  var context = renderingContext;
  var fallbackDimensions = aspectDimensions("16:9", 1280);
  var config = {
    presetId: presets[0].id,
    values: valuesForPreset(presets[0].id),
    width: fallbackDimensions.width,
    height: fallbackDimensions.height,
    duration: presets[0].duration,
    background: "dark",
    renderMode: "preview"
  };
  var currentTime = 0;
  var playing = false;
  var playStartedAt = 0;
  var playStartedTime = 0;
  var animationFrame = 0;
  var activeRenderJob;
  var showingPoster = false;
  var rendererReady = false;
  var rendererStartupError;
  var acknowledgements = /* @__PURE__ */ new Map();
  function parseMessage(value) {
    try {
      if (typeof value === "string") return JSON.parse(value);
      if (value && typeof value === "object") return value;
    } catch (e) {
      return void 0;
    }
    return void 0;
  }
  function postHost(message) {
    const serialized = JSON.stringify(message);
    if (window.parent !== window) window.parent.postMessage(serialized, "*");
  }
  function fontSet() {
    return document.fonts;
  }
  async function waitForFonts(timeoutMs = 750) {
    const fonts = fontSet();
    if (!(fonts == null ? void 0 : fonts.ready)) return;
    await Promise.race([
      fonts.ready.then(() => void 0),
      new Promise((resolve) => window.setTimeout(resolve, timeoutMs))
    ]);
  }
  function sizeCanvas() {
    if (canvas.width !== config.width) canvas.width = config.width;
    if (canvas.height !== config.height) canvas.height = config.height;
  }
  function renderAt(time) {
    var _a;
    currentTime = Math.max(0, Math.min(config.duration, time));
    sizeCanvas();
    const diagnostics = renderFrame(context, config, currentTime);
    const family = String((_a = config.values.fontFamily) != null ? _a : "Inter Variable");
    const fonts = fontSet();
    if ((fonts == null ? void 0 : fonts.check) && !fonts.check('16px "'.concat(family.replace(/["\\]/g, ""), '"'))) {
      diagnostics.warnings.push("Font \u201C".concat(family, "\u201D is unavailable; a fallback is being used."));
    }
    postHost({
      type: "render-state",
      time: currentTime,
      duration: config.duration,
      playing,
      warnings: diagnostics.warnings
    });
    return diagnostics;
  }
  function tick(now) {
    if (!playing) return;
    currentTime = playStartedTime + (now - playStartedAt) / 1e3;
    if (currentTime >= config.duration) {
      currentTime = config.duration;
      playing = false;
    }
    renderAt(currentTime);
    if (playing) animationFrame = requestAnimationFrame(tick);
    else postHost({ type: "playback-ended", time: currentTime });
  }
  function stopPlayback() {
    playing = false;
    cancelAnimationFrame(animationFrame);
  }
  function play() {
    if (playing) return;
    if (showingPoster || currentTime >= config.duration - 0.01) currentTime = 0;
    showingPoster = false;
    playing = true;
    playStartedAt = performance.now();
    playStartedTime = currentTime;
    cancelAnimationFrame(animationFrame);
    animationFrame = requestAnimationFrame(tick);
  }
  function pause() {
    stopPlayback();
    renderAt(currentTime);
  }
  function replay() {
    stopPlayback();
    showingPoster = false;
    currentTime = 0;
    renderAt(0);
    play();
  }
  async function configure(next, requestId) {
    var _a, _b;
    try {
      stopPlayback();
      config = {
        ...next,
        width: Math.max(16, Math.round(next.width)),
        height: Math.max(16, Math.round(next.height)),
        duration: Math.max(0.1, next.duration)
      };
      await loadCustomFont(config.values);
      await waitForFonts();
      sizeCanvas();
      const entrance = Math.max(0, Number((_a = config.values.entrance) != null ? _a : 0.55));
      const exit = Math.max(0, Number((_b = config.values.exit) != null ? _b : 0.5));
      const lastReadableMoment = Math.max(0, config.duration - exit - 0.08);
      currentTime = config.renderMode === "preview" ? Math.min(lastReadableMoment, Math.max(entrance + 0.18, config.duration * 0.34)) : 0;
      renderAt(currentTime);
      showingPoster = config.renderMode === "preview";
      postHost({ type: "configured", presetId: config.presetId, requestId });
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      postHost({ type: "configure-error", message, requestId });
      throw error;
    }
  }
  function acknowledge(jobId, frame) {
    var _a;
    const key = "".concat(jobId, ":").concat(frame);
    (_a = acknowledgements.get(key)) == null ? void 0 : _a();
    acknowledgements.delete(key);
  }
  async function waitForAck(jobId, frame) {
    const key = "".concat(jobId, ":").concat(frame);
    return new Promise((resolve, reject) => {
      const timeout = window.setTimeout(() => {
        acknowledgements.delete(key);
        reject(new Error("Host did not acknowledge frame ".concat(frame, ".")));
      }, 3e4);
      acknowledgements.set(key, () => {
        window.clearTimeout(timeout);
        resolve();
      });
    });
  }
  async function exportFrames(jobId, fps) {
    activeRenderJob = jobId;
    stopPlayback();
    showingPoster = false;
    const original = config;
    config = { ...config, renderMode: "export", background: "transparent" };
    sizeCanvas();
    const total = Math.max(1, Math.ceil(config.duration * fps));
    try {
      for (let frame = 0; frame < total; frame += 1) {
        if (activeRenderJob !== jobId) throw new Error("Render cancelled.");
        const time = frame / fps;
        const diagnostics = renderAt(time);
        const dataUrl = canvas.toDataURL("image/png");
        postHost({
          type: "render-frame",
          jobId,
          frame,
          total,
          time,
          dataUrl,
          warnings: diagnostics.warnings
        });
        await waitForAck(jobId, frame);
      }
      postHost({ type: "render-complete", jobId, total });
    } catch (error) {
      postHost({
        type: "render-error",
        jobId,
        message: error instanceof Error ? error.message : String(error)
      });
    } finally {
      activeRenderJob = void 0;
      config = original;
      renderAt(0);
    }
  }
  function handleMessage(raw) {
    var _a, _b;
    const message = parseMessage(raw);
    if (!message) return;
    switch (message.type) {
      case "configure":
        if (message.config) void configure(message.config, message.requestId).catch(() => void 0);
        break;
      case "ping":
        if (rendererStartupError) postHost({ type: "renderer-error", message: rendererStartupError });
        else if (rendererReady) postHost({ type: "renderer-ready" });
        break;
      case "play":
        play();
        break;
      case "pause":
        pause();
        break;
      case "replay":
        replay();
        break;
      case "seek":
        stopPlayback();
        showingPoster = false;
        renderAt(Number((_a = message.time) != null ? _a : 0));
        break;
      case "render-start":
        if (message.jobId) void exportFrames(message.jobId, Math.max(1, Number((_b = message.fps) != null ? _b : 30)));
        break;
      case "render-cancel":
        activeRenderJob = void 0;
        break;
      case "render-ack":
        if (message.jobId && message.frame !== void 0) acknowledge(message.jobId, message.frame);
        break;
    }
  }
  window.addEventListener("message", (event) => handleMessage(event.data));
  document.addEventListener("message", ((event) => {
    var _a;
    handleMessage((_a = event.detail) != null ? _a : event.data);
  }));
  window.motionPlugRenderer = {
    configure,
    renderAt,
    play,
    pause,
    replay,
    dataUrl: () => canvas.toDataURL("image/png"),
    getConfig: () => ({ ...config, values: { ...config.values } })
  };
  void (async () => {
    try {
      await loadCustomFont(config.values);
      await waitForFonts();
      sizeCanvas();
      renderAt(0);
      rendererReady = true;
      postHost({ type: "renderer-ready" });
    } catch (error) {
      rendererStartupError = error instanceof Error ? error.message : String(error);
      postHost({ type: "renderer-error", message: rendererStartupError });
    }
  })();
})();
