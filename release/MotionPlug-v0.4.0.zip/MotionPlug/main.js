"use strict";
(() => {
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined") return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });

  // src/panel/color-picker.ts
  function hexToHsv(hex) {
    const [r, g, b] = [1, 3, 5].map((offset) => parseInt(hex.slice(offset, offset + 2), 16) / 255);
    const max = Math.max(r, g, b), min = Math.min(r, g, b), delta = max - min;
    let h = 0;
    if (delta) h = max === r ? (g - b) / delta % 6 : max === g ? (b - r) / delta + 2 : (r - g) / delta + 4;
    return { h: (h * 60 + 360) % 360, s: max ? delta / max : 0, v: max };
  }
  function hsvToHex({ h, s, v }) {
    const f = (n) => {
      const k = (n + h / 60) % 6;
      return Math.round((v - v * s * Math.max(0, Math.min(k, 4 - k, 1))) * 255).toString(16).padStart(2, "0");
    };
    return "#".concat(f(5)).concat(f(3)).concat(f(1));
  }
  var close;
  function closeColorPicker() {
    close == null ? void 0 : close();
    close = void 0;
  }
  function bindColorPickers() {
    closeColorPicker();
    document.querySelectorAll("[data-color-picker]").forEach((swatch) => {
      swatch.addEventListener("click", (event) => {
        var _a, _b, _c;
        event.preventDefault();
        const wasOpen = swatch.getAttribute("aria-expanded") === "true";
        close == null ? void 0 : close();
        if (wasOpen) return;
        const control = swatch.dataset.colorPicker;
        const input = document.querySelector('[data-control="'.concat(control, '"]'));
        let color = hexToHsv(input.value);
        const editor = document.createElement("div");
        editor.className = "color-editor field--wide";
        editor.innerHTML = '<div class="color-editor__heading"><strong></strong><button type="button" class="quiet-button">Done</button></div><canvas width="280" height="128" tabindex="0" role="slider" aria-label="Saturation and brightness. Left and right adjust saturation; up and down adjust brightness." aria-valuemin="0" aria-valuemax="100"></canvas><label class="field field--range"><span>Hue</span><input type="range" min="0" max="359" step="1" aria-label="Color hue" /></label>';
        editor.querySelector("strong").textContent = (_c = (_b = (_a = input.closest("label")) == null ? void 0 : _a.querySelector("span")) == null ? void 0 : _b.textContent) != null ? _c : "Color";
        const canvas = editor.querySelector("canvas");
        const context = canvas.getContext("2d");
        const hue = editor.querySelector("input");
        let dragging = false;
        function paint() {
          context.fillStyle = hsvToHex({ h: color.h, s: 1, v: 1 });
          context.fillRect(0, 0, canvas.width, canvas.height);
          const saturation = context.createLinearGradient(0, 0, canvas.width, 0);
          saturation.addColorStop(0, "rgba(255,255,255,1)");
          saturation.addColorStop(1, "rgba(255,255,255,0)");
          context.fillStyle = saturation;
          context.fillRect(0, 0, canvas.width, canvas.height);
          const brightness = context.createLinearGradient(0, 0, 0, canvas.height);
          brightness.addColorStop(0, "rgba(0,0,0,0)");
          brightness.addColorStop(1, "rgba(0,0,0,1)");
          context.fillStyle = brightness;
          context.fillRect(0, 0, canvas.width, canvas.height);
          context.beginPath();
          context.arc(color.s * canvas.width, (1 - color.v) * canvas.height, 5, 0, Math.PI * 2);
          context.strokeStyle = "#18191d";
          context.lineWidth = 3;
          context.stroke();
          context.strokeStyle = "#f3f3ef";
          context.lineWidth = 1.5;
          context.stroke();
          hue.value = String(Math.round(color.h));
          canvas.setAttribute("aria-valuenow", String(Math.round(color.s * 100)));
          canvas.setAttribute("aria-valuetext", "".concat(Math.round(color.s * 100), "% saturation, ").concat(Math.round(color.v * 100), "% brightness"));
        }
        function change() {
          input.value = hsvToHex(color);
          swatch.value = input.value;
          input.dispatchEvent(new Event("input", { bubbles: true }));
          paint();
        }
        function move(event2) {
          if (!dragging) return;
          if (!editor.isConnected) {
            close == null ? void 0 : close();
            return;
          }
          const rect = canvas.getBoundingClientRect();
          color.s = Math.max(0, Math.min(1, (event2.clientX - rect.left) / rect.width));
          color.v = 1 - Math.max(0, Math.min(1, (event2.clientY - rect.top) / rect.height));
          change();
        }
        const up = () => {
          dragging = false;
        };
        canvas.addEventListener("mousedown", (event2) => {
          event2.preventDefault();
          dragging = true;
          canvas.focus();
          move(event2);
        });
        window.addEventListener("mousemove", move);
        window.addEventListener("mouseup", up);
        const sync = () => {
          if (/^#[0-9a-f]{6}$/i.test(input.value)) {
            color = hexToHsv(input.value);
            paint();
          }
        };
        input.addEventListener("change", sync);
        canvas.addEventListener("keydown", (event2) => {
          const step = event2.shiftKey ? 0.1 : 0.01;
          if (event2.key === "ArrowLeft") color.s -= step;
          else if (event2.key === "ArrowRight") color.s += step;
          else if (event2.key === "ArrowUp") color.v += step;
          else if (event2.key === "ArrowDown") color.v -= step;
          else return;
          event2.preventDefault();
          color.s = Math.max(0, Math.min(1, color.s));
          color.v = Math.max(0, Math.min(1, color.v));
          change();
        });
        hue.addEventListener("input", () => {
          color.h = Number(hue.value);
          change();
        });
        close = () => {
          editor.remove();
          swatch.setAttribute("aria-expanded", "false");
          window.removeEventListener("mousemove", move);
          window.removeEventListener("mouseup", up);
          input.removeEventListener("change", sync);
        };
        editor.querySelector("button").addEventListener("click", () => {
          close == null ? void 0 : close();
          swatch.focus();
        });
        editor.addEventListener("keydown", (event2) => {
          if (event2.key === "Escape") {
            event2.stopPropagation();
            close == null ? void 0 : close();
            swatch.focus();
          }
        });
        swatch.setAttribute("aria-expanded", "true");
        swatch.closest(".field").insertAdjacentElement("afterend", editor);
        paint();
        editor.scrollIntoView({ block: "nearest" });
        canvas.focus({ preventScroll: true });
      });
    });
  }

  // src/renderer/highlights.ts
  function highlightedRuns(text) {
    const runs = [];
    const pattern = /\[([^\[\]]+)\]/g;
    let cursor = 0;
    let match;
    while (match = pattern.exec(text)) {
      if (match.index > cursor) runs.push({ text: text.slice(cursor, match.index), highlighted: false });
      runs.push({ text: match[1], highlighted: true });
      cursor = match.index + match[0].length;
    }
    if (cursor < text.length) runs.push({ text: text.slice(cursor), highlighted: false });
    return runs;
  }
  function plainText(text) {
    return highlightedRuns(text).map((run) => run.text).join("");
  }
  function migrateKeyword(values2) {
    if (typeof values2.title === "string" && typeof values2.keyword === "string" && values2.keyword && !values2.title.includes("[")) {
      const keyword = values2.keyword.toLocaleLowerCase();
      values2.title = values2.title.split(/(\s+)/).map((word) => {
        const clean = word.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "");
        return clean.toLocaleLowerCase() === keyword ? word.replace(clean, "[".concat(clean, "]")) : word;
      }).join("");
    }
    delete values2.keyword;
  }

  // src/audio/sample-catalog.ts
  var soundSamples = {
    airy: { label: "Airy whoosh", file: "airy.wav" },
    deep: { label: "Dry low impact", file: "deep.wav" },
    wind: { label: "Soft wind", file: "wind.wav" },
    tap: { label: "Phone tap", file: "tap.wav" },
    select: { label: "Soft selection", file: "select.wav" },
    complete: { label: "Subtle completion", file: "complete.wav" },
    menu: { label: "Interface movement", file: "menu.wav" },
    pop: { label: "Interface pop", file: "pop.wav" }
  };
  function soundForPreset(family, variant) {
    switch (family) {
      case "hero-headline":
        return variant === "centered" ? "deep" : "airy";
      case "specification-reveal":
        return variant === "count" ? "select" : "deep";
      case "word-by-word":
        return variant === "track" ? "tap" : "select";
      case "rapid-replacement":
        return variant === "swaps" ? "menu" : "tap";
      case "masked-line-reveal":
        return "airy";
      case "keyword-emphasis":
        return variant === "scale" ? "pop" : "complete";
      case "headline-layout-transition":
        return "airy";
      case "feature-stack":
        return variant === "active" ? "select" : "tap";
      case "bento-summary":
        return "pop";
      case "product-callout":
        return "select";
      case "performance-comparison":
        return "menu";
      case "presenter-title":
        return "airy";
      case "price-availability":
        return "complete";
      case "light-sweep":
        return "wind";
      case "soft-focus":
        return variant === "words" ? "menu" : "wind";
    }
  }

  // src/audio/wav.ts
  var clamp = (value) => Math.max(-1, Math.min(1, value));
  function writeAscii(view2, offset, text) {
    for (let index = 0; index < text.length; index += 1) {
      view2.setUint8(offset + index, text.charCodeAt(index));
    }
  }
  function encodeWav(channels, sampleRate2 = 48e3) {
    var _a;
    const first = channels[0];
    if (!first || channels.some((channel) => channel.length !== first.length)) {
      throw new Error("WAV channels must be non-empty and have matching lengths.");
    }
    const channelCount = channels.length;
    const bytesPerSample = 2;
    const dataLength = first.length * channelCount * bytesPerSample;
    const buffer = new ArrayBuffer(44 + dataLength);
    const view2 = new DataView(buffer);
    writeAscii(view2, 0, "RIFF");
    view2.setUint32(4, 36 + dataLength, true);
    writeAscii(view2, 8, "WAVE");
    writeAscii(view2, 12, "fmt ");
    view2.setUint32(16, 16, true);
    view2.setUint16(20, 1, true);
    view2.setUint16(22, channelCount, true);
    view2.setUint32(24, sampleRate2, true);
    view2.setUint32(28, sampleRate2 * channelCount * bytesPerSample, true);
    view2.setUint16(32, channelCount * bytesPerSample, true);
    view2.setUint16(34, bytesPerSample * 8, true);
    writeAscii(view2, 36, "data");
    view2.setUint32(40, dataLength, true);
    let offset = 44;
    for (let index = 0; index < first.length; index += 1) {
      for (const channel of channels) {
        view2.setInt16(offset, Math.round(clamp((_a = channel[index]) != null ? _a : 0) * 32767), true);
        offset += bytesPerSample;
      }
    }
    return new Uint8Array(buffer);
  }

  // src/audio/matched-sfx.ts
  var sampleRate = 48e3;
  function planSoundCues(preset2, values2, duration) {
    var _a, _b, _c, _d, _e, _f;
    const entrance = Number((_a = values2.entrance) != null ? _a : 0.55);
    const exit = Number((_b = values2.exit) != null ? _b : 0.5);
    const stagger = Number((_c = values2.stagger) != null ? _c : 0.14);
    const cues = [];
    const add = (at, gain = 0.55, sample = preset2.sfx.sample, length) => cues.push({ sample, at, gain, length });
    const words = (limit) => {
      var _a2;
      return plainText(String((_a2 = values2.title) != null ? _a2 : "")).trim().split(/\s+/).filter(Boolean).slice(0, limit).length;
    };
    switch (preset2.family) {
      case "word-by-word":
        for (let i = 0; i < words(14); i++) add(0.08 + i * stagger, 0.38);
        break;
      case "rapid-replacement": {
        const count = Math.min(8, String((_d = values2.sequenceText) != null ? _d : "").split("\n").filter(Boolean).length);
        const intro = Math.min(0.14, entrance * 0.22);
        const slot = Math.max(0.4, duration - exit - intro) / Math.max(1, count);
        for (let i = 0; i < count; i++) add(i === 0 ? intro : intro + (i - 1 + (preset2.variant === "swaps" ? 0.7 : 0.76)) * slot, 0.55);
        break;
      }
      case "soft-focus":
        if (preset2.variant === "words") for (let i = 0; i < words(10); i++) add(0.04 + i * stagger, 0.3);
        else add(0, 0.5, "wind", 0.94);
        break;
      case "feature-stack": {
        const count = Math.min(7, String((_e = values2.itemsText) != null ? _e : "").split("\n").filter(Boolean).length);
        for (let i = 0; i < count; i++) add(preset2.variant === "active" ? i === 0 ? 0.28 : 0.48 + (i - 1 + 0.58) * Math.max(stagger, 0.15) : 0.16 + i * stagger, 0.36);
        break;
      }
      case "bento-summary":
        for (let i = 0; i < 4; i++) add(0.05 + i * stagger * 1.22, 0.42);
        break;
      case "keyword-emphasis":
        if (String((_f = values2.title) != null ? _f : "").includes("[")) add(entrance * 0.62, 0.55);
        break;
      case "headline-layout-transition":
        add(0, 0.4, "airy", entrance);
        add(entrance * 0.68, 0.5, "airy", 1.05);
        break;
      case "product-callout":
        add(0.02, 0.4);
        add(0.48, 0.42, "pop");
        break;
      case "performance-comparison":
        add(0.2, 0.45);
        add(preset2.variant === "bars" ? 0.36 : 0.3, 0.45);
        break;
      case "price-availability":
        add(0.05 + stagger, 0.55);
        add(0.05 + stagger * 2, 0.35, "select");
        break;
      case "light-sweep": {
        const start = entrance * 0.5;
        const length = Math.max(0.7, duration - exit - start);
        const loops = preset2.variant === "loop" || values2.loop ? 2 : 1;
        for (let i = 0; i < loops; i++) add(start + (i + 0.25) * length / loops, 0.5, "wind", length / loops * 0.5);
        break;
      }
      case "specification-reveal":
        if (preset2.variant === "count" && values2.countEnabled) {
          for (let i = 0; i < 5; i++) add(0.05 + i * 0.18, 0.25);
          add(0.95, 0.45, "complete");
        } else add(0, 0.65, "deep");
        break;
      case "presenter-title":
        add(0.04, 0.38, "airy", entrance + 0.08);
        break;
      case "masked-line-reveal":
        add(0, 0.5, "airy", entrance + 0.5);
        break;
      default:
        add(0, 0.6, preset2.sfx.sample, preset2.sfx.sample === "airy" ? entrance : void 0);
    }
    return cues.filter((cue) => cue.at >= 0 && cue.at < duration - exit);
  }
  function decodeWav(bytes) {
    const view2 = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const text = (offset, length2) => String.fromCharCode(...bytes.slice(offset, offset + length2));
    if (text(0, 4) !== "RIFF" || text(8, 4) !== "WAVE") throw new Error("Invalid bundled sound file.");
    let channels = 0, rate = 0, bits = 0, format = 0, dataOffset = 0, dataLength = 0;
    for (let offset = 12; offset + 8 <= bytes.length; ) {
      const size = view2.getUint32(offset + 4, true);
      if (offset + 8 + size > bytes.length) throw new Error("Truncated bundled sound file.");
      if (text(offset, 4) === "fmt ") {
        format = view2.getUint16(offset + 8, true);
        channels = view2.getUint16(offset + 10, true);
        rate = view2.getUint32(offset + 12, true);
        bits = view2.getUint16(offset + 22, true);
      } else if (text(offset, 4) === "data") {
        dataOffset = offset + 8;
        dataLength = size;
      }
      offset += 8 + size + size % 2;
    }
    if (format !== 1 || bits !== 16 || channels < 1 || channels > 2 || !rate || !dataOffset) throw new Error("Bundled sounds must be mono/stereo 16-bit PCM.");
    const length = Math.floor(dataLength / (channels * 2));
    const result = Array.from({ length: channels }, () => new Float32Array(length));
    for (let i = 0; i < length; i++) for (let channel = 0; channel < channels; channel++) {
      result[channel][i] = view2.getInt16(dataOffset + (i * channels + channel) * 2, true) / 32768;
    }
    return { channels: result, sampleRate: rate };
  }
  function mixSoundtrack(cues, bank, duration, volume) {
    var _a, _b, _c, _d;
    const frames = Math.max(1, Math.ceil(duration * sampleRate));
    const output = [new Float32Array(frames), new Float32Array(frames)];
    const level = Math.max(0, Math.min(1, volume / 100));
    for (const cue of cues) {
      const sample = bank[cue.sample];
      if (!sample) throw new Error("Missing sound: ".concat(soundSamples[cue.sample].label, ". Reinstall Motion Plug's sound assets."));
      const naturalLength = sample.channels[0].length / sample.sampleRate;
      const rate = cue.length ? Math.min(2, Math.max(0.65, naturalLength / cue.length)) : 1;
      const length = naturalLength / rate;
      const start = Math.round(cue.at * sampleRate);
      const count = Math.min(frames - start, Math.ceil(length * sampleRate));
      for (let i = 0; i < count; i++) {
        const position = i * sample.sampleRate / sampleRate * rate;
        const index = Math.floor(position);
        const fraction = position - index;
        const fade = Math.min(1, i / 144, (count - i - 1) / 720);
        for (let channel = 0; channel < 2; channel++) {
          const input = sample.channels[channel % sample.channels.length];
          const value = ((_a = input[index]) != null ? _a : 0) * (1 - fraction) + ((_b = input[index + 1]) != null ? _b : 0) * fraction;
          output[channel][start + i] = ((_c = output[channel][start + i]) != null ? _c : 0) + value * cue.gain * fade;
        }
      }
    }
    let peak = 0;
    for (const channel of output) for (const value of channel) peak = Math.max(peak, Math.abs(value));
    const gain = (peak > 0.94 ? 0.94 / peak : 1) * level;
    for (const channel of output) for (let i = 0; i < channel.length; i++) channel[i] = ((_d = channel[i]) != null ? _d : 0) * gain;
    return output;
  }
  var cache = /* @__PURE__ */ new Map();
  function loadSample(id2) {
    if (!cache.has(id2)) cache.set(id2, new Promise((resolve, reject) => {
      const request = new XMLHttpRequest();
      request.open("GET", "sfx/samples/".concat(soundSamples[id2].file));
      request.responseType = "arraybuffer";
      request.onload = () => {
        try {
          if (!request.response || request.status !== 0 && request.status !== 200) throw new Error("Missing sound asset");
          resolve(decodeWav(new Uint8Array(request.response)));
        } catch (error) {
          cache.delete(id2);
          reject(error);
        }
      };
      request.onerror = request.ontimeout = () => {
        cache.delete(id2);
        reject(new Error("Could not load ".concat(soundSamples[id2].label, ". Reinstall Motion Plug's sound assets.")));
      };
      request.timeout = 15e3;
      request.send();
    }));
    return cache.get(id2);
  }
  async function createSoundtrack(preset2, values2, duration, volume) {
    const cues = planSoundCues(preset2, values2, duration);
    const bank = {};
    await Promise.all([...new Set(cues.map((cue) => cue.sample))].map(async (id2) => {
      bank[id2] = await loadSample(id2);
    }));
    return encodeWav(mixSoundtrack(cues, bank, duration, volume), sampleRate);
  }

  // src/catalog/presets.ts
  var baseDefaults = {
    fontFamily: "Inter Variable",
    fontWeight: 720,
    fontSize: 112,
    lineHeight: 0.92,
    tracking: -2,
    alignment: "center",
    positionX: 50,
    positionY: 50,
    safeMargin: 8,
    cornerRadius: 26,
    textColor: "#F7F7F2",
    accentColor: "#8CA8FF",
    accentColor2: "#C59CFF",
    transparentBackground: true,
    entrance: 0.55,
    hold: 2.3,
    exit: 0.5,
    intensity: 54,
    stagger: 0.14,
    direction: "up",
    sfxEnabled: true,
    sfxVolume: 68
  };
  var typographyControls = ["fontFamily", "fontWeight", "fontSize", "lineHeight", "tracking", "textColor"];
  var placementControls = ["positionX", "positionY", "safeMargin"];
  var motionControls = ["entrance", "hold", "exit", "intensity"];
  var outputControls = ["sfxEnabled", "sfxVolume"];
  function preset(input) {
    const defaults = { ...baseDefaults, ...input.defaults };
    if (input.defaults.hold === void 0) {
      defaults.hold = Math.max(
        0.4,
        input.duration - Number(defaults.entrance) - Number(defaults.exit)
      );
    }
    migrateKeyword(defaults);
    return {
      ...input,
      version: 2,
      sfx: { sample: soundForPreset(input.family, input.variant), label: soundSamples[soundForPreset(input.family, input.variant)].label },
      defaults
    };
  }
  var presets = [
    preset({
      id: "motionplug.hero.centered.v1",
      family: "hero-headline",
      familyName: "Hero Headline",
      name: "Quiet Monument",
      variant: "centered",
      category: "Typography",
      description: "A centered announcement that arrives with scale, air, and a measured hold.",
      tags: ["hero", "headline", "centered", "announcement", "minimal"],
      duration: 4,
      controls: ["title", "subtitle", ...typographyControls, "accentColor", ...placementControls, ...motionControls, ...outputControls],
      defaults: { title: "DESIGNED\nTO MOVE", subtitle: "A considered introduction", fontSize: 148, positionY: 48, intensity: 42 }
    }),
    preset({
      id: "motionplug.hero.editorial.v1",
      family: "hero-headline",
      familyName: "Hero Headline",
      name: "Editorial Horizon",
      variant: "editorial",
      category: "Typography",
      description: "A left-set editorial headline with a fine rule and offset supporting copy.",
      tags: ["hero", "editorial", "left", "rule", "magazine"],
      duration: 4.4,
      controls: ["title", "subtitle", ...typographyControls, "accentColor", "positionX", "positionY", "safeMargin", ...motionControls, ...outputControls],
      defaults: { title: "A NEW\nPOINT OF VIEW", subtitle: "Edition 01  /  Motion Study", alignment: "left", fontSize: 132, positionX: 10, positionY: 56, intensity: 62 }
    }),
    preset({
      id: "motionplug.spec.lockup.v1",
      family: "specification-reveal",
      familyName: "Big Number / Specification Reveal",
      name: "Metric Lockup",
      variant: "lockup",
      category: "Data",
      description: "An oversized metric locks into place before its unit and caption arrive.",
      tags: ["number", "spec", "metric", "stat", "product"],
      duration: 3.8,
      controls: ["value", "unit", "subtitle", "countEnabled", ...typographyControls, "accentColor", ...placementControls, ...motionControls, ...outputControls],
      defaults: { value: 48, unit: "MP", subtitle: "Main camera system", countEnabled: false, fontSize: 204, tracking: -5, positionY: 51, intensity: 48 }
    }),
    preset({
      id: "motionplug.spec.count.v1",
      family: "specification-reveal",
      familyName: "Big Number / Specification Reveal",
      name: "Precision Count",
      variant: "count",
      category: "Data",
      description: "A compact counter rises into a precise two-column specification layout.",
      tags: ["number", "count", "specification", "technical", "split"],
      duration: 4.2,
      controls: ["value", "unit", "subtitle", "countEnabled", ...typographyControls, "accentColor", "positionX", "positionY", "safeMargin", ...motionControls, ...outputControls],
      defaults: { value: 120, unit: "Hz", subtitle: "Adaptive refresh rate", countEnabled: true, alignment: "left", fontSize: 188, positionX: 12, positionY: 53, intensity: 64 }
    }),
    preset({
      id: "motionplug.words.rise.v1",
      family: "word-by-word",
      familyName: "Word-by-Word Build",
      name: "Measured Rise",
      variant: "rise",
      category: "Typography",
      description: "Words rise one at a time with speech-friendly timing and a stable final lockup.",
      tags: ["words", "speech", "sequential", "rise", "caption"],
      duration: 4.6,
      controls: ["title", ...typographyControls, "accentColor", ...placementControls, "entrance", "hold", "exit", "intensity", "stagger", ...outputControls],
      defaults: { title: "Every detail [earns] its place", fontSize: 108, positionY: 51, stagger: 0.18, intensity: 55 }
    }),
    preset({
      id: "motionplug.words.track.v1",
      family: "word-by-word",
      familyName: "Word-by-Word Build",
      name: "Kinetic Track",
      variant: "track",
      category: "Typography",
      description: "A sentence assembles along a horizontal track with a moving emphasis marker.",
      tags: ["words", "track", "kinetic", "speech", "horizontal"],
      duration: 4.8,
      controls: ["title", ...typographyControls, "accentColor", "positionY", "safeMargin", "entrance", "hold", "exit", "intensity", "stagger", ...outputControls],
      defaults: { title: "Small moves [change] everything", alignment: "left", fontSize: 92, positionX: 9, positionY: 53, stagger: 0.2, intensity: 72 }
    }),
    preset({
      id: "motionplug.replace.cuts.v1",
      family: "rapid-replacement",
      familyName: "Rapid Word Replacement",
      name: "Rhythmic Cuts",
      variant: "cuts",
      category: "Typography",
      description: "Short phrases cut cleanly at one anchor with individually readable holds.",
      tags: ["replace", "rhythmic", "cut", "words", "fast"],
      duration: 4.2,
      controls: ["sequenceText", ...typographyControls, "accentColor", ...placementControls, "hold", "exit", "intensity", ...outputControls],
      defaults: { sequenceText: "FOCUSED\nFLUID\nFAMILIAR\nYOURS", fontSize: 156, hold: 0.72, intensity: 20 }
    }),
    preset({
      id: "motionplug.replace.swaps.v1",
      family: "rapid-replacement",
      familyName: "Rapid Word Replacement",
      name: "Soft Swaps",
      variant: "swaps",
      category: "Typography",
      description: "Phrases trade places through a clipped vertical swap with subtle depth.",
      tags: ["replace", "swap", "mask", "phrases", "vertical"],
      duration: 4.5,
      controls: ["sequenceText", ...typographyControls, "accentColor", ...placementControls, "hold", "exit", "intensity", ...outputControls],
      defaults: { sequenceText: "LESS NOISE\nMORE SIGNAL\nPURE FOCUS", fontSize: 132, hold: 0.95, intensity: 66 }
    }),
    preset({
      id: "motionplug.masked.lift.v1",
      family: "masked-line-reveal",
      familyName: "Masked Line Reveal",
      name: "Line Lift",
      variant: "up",
      category: "Typography",
      description: "Lines emerge upward from crisp invisible boundaries with exact staggering.",
      tags: ["mask", "lines", "up", "stagger", "reveal"],
      duration: 4.4,
      controls: ["title", ...typographyControls, "accentColor", ...placementControls, "entrance", "hold", "exit", "intensity", "stagger", ...outputControls],
      defaults: { title: "BUILT AROUND\nWHAT MATTERS\nMOST", alignment: "left", fontSize: 124, positionX: 10, positionY: 52, stagger: 0.16, intensity: 64 }
    }),
    preset({
      id: "motionplug.masked.side.v1",
      family: "masked-line-reveal",
      familyName: "Masked Line Reveal",
      name: "Side Passage",
      variant: "side",
      category: "Typography",
      description: "A sideways line reveal creates pace without disturbing the final layout.",
      tags: ["mask", "lines", "side", "editorial", "reveal"],
      duration: 4.2,
      controls: ["title", "subtitle", ...typographyControls, "accentColor", ...placementControls, "entrance", "hold", "exit", "intensity", "stagger", ...outputControls],
      defaults: { title: "FORM\nFOLLOWS\nFEELING", subtitle: "A study in considered motion", alignment: "right", fontSize: 122, positionX: 89, positionY: 50, stagger: 0.14, intensity: 76 }
    }),
    preset({
      id: "motionplug.keyword.color.v1",
      family: "keyword-emphasis",
      familyName: "Keyword Emphasis",
      name: "Chromatic Word",
      variant: "color",
      category: "Typography",
      description: "One chosen word takes color while the surrounding sentence remains perfectly still.",
      tags: ["color", "emphasis", "sentence", "stable"],
      duration: 4.2,
      controls: ["title", ...typographyControls, "accentColor", ...placementControls, ...motionControls, ...outputControls],
      defaults: { title: "Clarity makes ideas [memorable]", fontSize: 104, positionY: 51, intensity: 28 }
    }),
    preset({
      id: "motionplug.keyword.scale.v1",
      family: "keyword-emphasis",
      familyName: "Keyword Emphasis",
      name: "Weight of One",
      variant: "scale",
      category: "Typography",
      description: "The selected word grows with controlled scale while the sentence holds its baseline.",
      tags: ["scale", "emphasis", "baseline", "bold"],
      duration: 4.4,
      controls: ["title", ...typographyControls, "accentColor", ...placementControls, ...motionControls, ...outputControls],
      defaults: { title: "Make the [essential] unmistakable", alignment: "left", fontSize: 96, positionX: 9, positionY: 54, intensity: 56 }
    }),
    preset({
      id: "motionplug.transition.corner.v1",
      family: "headline-layout-transition",
      familyName: "Headline-to-Layout Transition",
      name: "Corner Settle",
      variant: "corner",
      category: "Layout",
      description: "A monumental title resolves into a corner heading as supporting content appears.",
      tags: ["transition", "layout", "corner", "headline", "support"],
      duration: 5.2,
      controls: ["title", "subtitle", ...typographyControls, "accentColor", "safeMargin", ...motionControls, ...outputControls],
      defaults: { title: "THE NEXT\nCHAPTER", subtitle: "Designed from the inside out.\nMade to feel immediate.", fontSize: 154, intensity: 62 }
    }),
    preset({
      id: "motionplug.transition.rail.v1",
      family: "headline-layout-transition",
      familyName: "Headline-to-Layout Transition",
      name: "Rail Shift",
      variant: "rail",
      category: "Layout",
      description: "The title travels onto a vertical rail and opens space for a concise statement.",
      tags: ["transition", "layout", "rail", "shift", "editorial"],
      duration: 5,
      controls: ["title", "subtitle", ...typographyControls, "accentColor", "safeMargin", ...motionControls, ...outputControls],
      defaults: { title: "SPACE\nTO THINK", subtitle: "An interface should leave room for the work.", alignment: "left", fontSize: 146, intensity: 75 }
    }),
    preset({
      id: "motionplug.stack.accumulate.v1",
      family: "feature-stack",
      familyName: "Feature Stack",
      name: "Progressive Stack",
      variant: "accumulate",
      category: "Layout",
      description: "Benefits accumulate vertically and remain visible as the list completes.",
      tags: ["features", "stack", "benefits", "list", "progressive"],
      duration: 5,
      controls: ["title", "itemsText", ...typographyControls, "accentColor", "positionX", "positionY", "safeMargin", "entrance", "hold", "exit", "stagger", ...outputControls],
      defaults: { title: "WHAT CHANGES", itemsText: "Faster decisions\nCleaner handoffs\nMore room to create\nNothing in the way", alignment: "left", fontSize: 72, positionX: 11, positionY: 52, stagger: 0.28 }
    }),
    preset({
      id: "motionplug.stack.active.v1",
      family: "feature-stack",
      familyName: "Feature Stack",
      name: "Active Line",
      variant: "active",
      category: "Layout",
      description: "A quiet list holds while one active benefit advances down a luminous rail.",
      tags: ["features", "active", "rail", "list", "highlight"],
      duration: 5.4,
      controls: ["title", "itemsText", ...typographyControls, "accentColor", "positionX", "positionY", "safeMargin", "entrance", "hold", "exit", "stagger", ...outputControls],
      defaults: { title: "BUILT IN", itemsText: "Instant preview\nPrecise timing\nEditable sound\nReliable delivery", alignment: "left", fontSize: 70, positionX: 13, positionY: 51, stagger: 0.72 }
    }),
    preset({
      id: "motionplug.bento.mosaic.v1",
      family: "bento-summary",
      familyName: "Bento Feature Summary",
      name: "Balanced Mosaic",
      variant: "mosaic",
      category: "Layout",
      description: "Four rounded tiles assemble into an asymmetric product summary.",
      tags: ["bento", "tiles", "grid", "features", "cards"],
      duration: 5,
      controls: ["title", "tile1", "tile2", "tile3", "tile4", ...typographyControls, "accentColor", "accentColor2", "cornerRadius", "safeMargin", ...motionControls, "stagger", ...outputControls],
      defaults: { title: "EVERYTHING\nIN ITS PLACE", tile1: "48 MP\nDetail", tile2: "All day\nBattery", tile3: "Spatial\nAudio", tile4: "A18\nPerformance", fontSize: 92, cornerRadius: 30, stagger: 0.12, intensity: 58 }
    }),
    preset({
      id: "motionplug.bento.editorial.v1",
      family: "bento-summary",
      familyName: "Bento Feature Summary",
      name: "Editorial Grid",
      variant: "editorial",
      category: "Layout",
      description: "A restrained two-column grid builds around a typographic lead panel.",
      tags: ["bento", "editorial", "grid", "summary", "modular"],
      duration: 5.2,
      controls: ["title", "tile1", "tile2", "tile3", "tile4", ...typographyControls, "accentColor", "accentColor2", "cornerRadius", "safeMargin", ...motionControls, "stagger", ...outputControls],
      defaults: { title: "LESS,\nBETTER", tile1: "2\xD7\nFaster", tile2: "24 hr\nPlayback", tile3: "4 colors", tile4: "100%\nRecycled", alignment: "left", fontSize: 104, cornerRadius: 18, stagger: 0.16, intensity: 68 }
    }),
    preset({
      id: "motionplug.callout.pin.v1",
      family: "product-callout",
      familyName: "Product Callout",
      name: "Precision Pin",
      variant: "pin",
      category: "Layout",
      description: "A fixed anchor draws a precise connector to an editable product label.",
      tags: ["callout", "pin", "connector", "label", "product"],
      duration: 4.2,
      controls: ["label", "subtitle", ...typographyControls, "accentColor", "anchorX", "anchorY", "labelX", "labelY", "safeMargin", ...motionControls, ...outputControls],
      defaults: { label: "TITANIUM FRAME", subtitle: "Grade 5. Brushed finish.", alignment: "left", fontSize: 64, anchorX: 62, anchorY: 43, labelX: 73, labelY: 29, intensity: 54 }
    }),
    preset({
      id: "motionplug.callout.orbit.v1",
      family: "product-callout",
      familyName: "Product Callout",
      name: "Offset Orbit",
      variant: "orbit",
      category: "Layout",
      description: "A ringed anchor and bent connector create a softer technical annotation.",
      tags: ["callout", "orbit", "connector", "annotation", "fixed"],
      duration: 4.4,
      controls: ["label", "subtitle", ...typographyControls, "accentColor", "anchorX", "anchorY", "labelX", "labelY", "safeMargin", ...motionControls, ...outputControls],
      defaults: { label: "ACTION BUTTON", subtitle: "Your shortcut to anything.", alignment: "left", fontSize: 62, anchorX: 32, anchorY: 56, labelX: 47, labelY: 32, intensity: 67 }
    }),
    preset({
      id: "motionplug.compare.bars.v1",
      family: "performance-comparison",
      familyName: "Performance Comparison",
      name: "Measured Bars",
      variant: "bars",
      category: "Data",
      description: "Two values resolve into proportional bars with labels and a quiet source line.",
      tags: ["comparison", "bars", "performance", "data", "values"],
      duration: 4.8,
      controls: ["title", "labelA", "labelB", "valueA", "valueB", "footnote", ...typographyControls, "accentColor", "accentColor2", "safeMargin", ...motionControls, ...outputControls],
      defaults: { title: "A GENERATIONAL LEAP", labelA: "Previous", labelB: "New", valueA: 64, valueB: 100, footnote: "Relative graphics performance", alignment: "left", fontSize: 82, intensity: 58 }
    }),
    preset({
      id: "motionplug.compare.split.v1",
      family: "performance-comparison",
      familyName: "Performance Comparison",
      name: "Split Measure",
      variant: "split",
      category: "Data",
      description: "A central measure divides two typographic values for an editorial comparison.",
      tags: ["comparison", "split", "measure", "data", "editorial"],
      duration: 4.6,
      controls: ["title", "labelA", "labelB", "valueA", "valueB", "footnote", ...typographyControls, "accentColor", "accentColor2", "safeMargin", ...motionControls, ...outputControls],
      defaults: { title: "MORE FROM EVERY CORE", labelA: "Efficiency", labelB: "Performance", valueA: 35, valueB: 70, footnote: "Improvement over previous generation", fontSize: 76, intensity: 48 }
    }),
    preset({
      id: "motionplug.presenter.left.v1",
      family: "presenter-title",
      familyName: "Minimal Presenter Title",
      name: "Quiet Introduction",
      variant: "left",
      category: "Identity",
      description: "An understated left-aligned name and role with a restrained leading mark.",
      tags: ["presenter", "lower third", "name", "role", "left"],
      duration: 4.6,
      controls: ["name", "role", ...typographyControls, "accentColor", "positionX", "positionY", "safeMargin", ...motionControls, ...outputControls],
      defaults: { name: "MAYA CHEN", role: "Industrial Designer", alignment: "left", fontSize: 58, positionX: 8, positionY: 82, intensity: 38 }
    }),
    preset({
      id: "motionplug.presenter.right.v1",
      family: "presenter-title",
      familyName: "Minimal Presenter Title",
      name: "Quiet Introduction Right",
      variant: "right",
      category: "Identity",
      description: "A right-aligned presenter title that unfolds from a compact endpoint.",
      tags: ["presenter", "lower third", "name", "role", "right"],
      duration: 4.6,
      controls: ["name", "role", ...typographyControls, "accentColor", "positionX", "positionY", "safeMargin", ...motionControls, ...outputControls],
      defaults: { name: "ALEX RIVERA", role: "Director of Photography", alignment: "right", fontSize: 58, positionX: 92, positionY: 82, intensity: 46 }
    }),
    preset({
      id: "motionplug.price.center.v1",
      family: "price-availability",
      familyName: "Price and Availability Reveal",
      name: "Launch Price",
      variant: "center",
      category: "Commerce",
      description: "Product, price, and availability arrive in a deliberate centered sequence.",
      tags: ["price", "availability", "launch", "currency", "center"],
      duration: 4.6,
      controls: ["product", "price", "availability", "subtitle", ...typographyControls, "accentColor", ...placementControls, ...motionControls, "stagger", ...outputControls],
      defaults: { product: "AURA ONE", price: "From $799", availability: "Available 09.20", subtitle: "Pre-order Friday", fontSize: 92, positionY: 49, stagger: 0.22, intensity: 42 }
    }),
    preset({
      id: "motionplug.price.side.v1",
      family: "price-availability",
      familyName: "Price and Availability Reveal",
      name: "Price Ledger",
      variant: "side",
      category: "Commerce",
      description: "A side-set product lockup balances a large price against compact availability.",
      tags: ["price", "availability", "ledger", "split", "currency"],
      duration: 4.8,
      controls: ["product", "price", "availability", "subtitle", ...typographyControls, "accentColor", "positionX", "positionY", "safeMargin", ...motionControls, "stagger", ...outputControls],
      defaults: { product: "STUDIO DISPLAY", price: "\u20AC1,749", availability: "Ships today", subtitle: "27-inch 5K Retina display", alignment: "left", fontSize: 88, positionX: 9, positionY: 52, stagger: 0.2, intensity: 55 }
    }),
    preset({
      id: "motionplug.sweep.single.v1",
      family: "light-sweep",
      familyName: "Gradient / Light Sweep Text",
      name: "Single Light",
      variant: "single",
      category: "Effects",
      description: "One narrow light sweep travels through stable typography, then disappears.",
      tags: ["light", "sweep", "gradient", "text", "single"],
      duration: 4.4,
      controls: ["title", ...typographyControls, "accentColor", "accentColor2", ...placementControls, ...motionControls, ...outputControls],
      defaults: { title: "LIGHT, PRECISELY", fontSize: 126, intensity: 48, loop: false }
    }),
    preset({
      id: "motionplug.sweep.loop.v1",
      family: "light-sweep",
      familyName: "Gradient / Light Sweep Text",
      name: "Quiet Current",
      variant: "loop",
      category: "Effects",
      description: "A restrained tonal current crosses the title twice without moving the type.",
      tags: ["light", "sweep", "loop", "gradient", "ambient"],
      duration: 5.2,
      controls: ["title", ...typographyControls, "accentColor", "accentColor2", ...placementControls, ...motionControls, "loop", ...outputControls],
      defaults: { title: "ALWAYS IN MOTION", fontSize: 118, intensity: 38, loop: true }
    }),
    preset({
      id: "motionplug.focus.whole.v1",
      family: "soft-focus",
      familyName: "Soft Focus Reveal",
      name: "Whole Resolve",
      variant: "whole",
      category: "Effects",
      description: "The complete title resolves from soft focus with barely perceptible movement.",
      tags: ["focus", "blur", "resolve", "soft", "whole"],
      duration: 4.6,
      controls: ["title", "subtitle", ...typographyControls, "accentColor", ...placementControls, ...motionControls, ...outputControls],
      defaults: { title: "COME INTO FOCUS", subtitle: "Nothing more than what matters", fontSize: 120, intensity: 46 }
    }),
    preset({
      id: "motionplug.focus.words.v1",
      family: "soft-focus",
      familyName: "Soft Focus Reveal",
      name: "Word Resolve",
      variant: "words",
      category: "Effects",
      description: "Words sharpen in sequence and settle into a clean final sentence.",
      tags: ["focus", "blur", "words", "stagger", "resolve"],
      duration: 5,
      controls: ["title", ...typographyControls, "accentColor", ...placementControls, "entrance", "hold", "exit", "intensity", "stagger", ...outputControls],
      defaults: { title: "SEE THE [WHOLE] IDEA", fontSize: 114, stagger: 0.2, intensity: 62 }
    })
  ];
  var presetById = new Map(presets.map((item) => [item.id, item]));
  var familyNames = [...new Set(presets.map((item) => item.familyName))];
  var categories = [...new Set(presets.map((item) => item.category))];
  function valuesForPreset(id2, overrides = {}) {
    const item = presetById.get(id2);
    if (!item) throw new Error("Unknown preset: ".concat(id2));
    const values2 = { ...item.defaults, ...overrides };
    migrateKeyword(values2);
    values2.transparentBackground = true;
    delete values2.backgroundColor;
    delete values2.aspectRatio;
    return values2;
  }
  function computeDuration(values2, fallback) {
    var _a, _b, _c;
    const entrance = Number((_a = values2.entrance) != null ? _a : 0.5);
    const hold = Number((_b = values2.hold) != null ? _b : Math.max(0.6, fallback - 1));
    const exit = Number((_c = values2.exit) != null ? _c : 0.5);
    if (typeof values2.sequenceText === "string") {
      const itemCount = Math.max(1, values2.sequenceText.split("\n").filter(Boolean).length);
      return Math.max(1, entrance + hold * itemCount + exit);
    }
    return Math.max(1, entrance + hold + exit);
  }

  // src/catalog/controls.ts
  var fontOptions = [
    { label: "Inter", value: "Inter Variable" },
    { label: "Arial", value: "Arial" },
    { label: "Helvetica", value: "Helvetica Neue" },
    { label: "Georgia", value: "Georgia" }
  ];
  var controlRegistry = {
    title: { id: "title", label: "Headline", type: "textarea", group: "content" },
    subtitle: { id: "subtitle", label: "Supporting text", type: "textarea", group: "content" },
    label: { id: "label", label: "Label", type: "text", group: "content" },
    unit: { id: "unit", label: "Unit", type: "text", group: "content" },
    value: { id: "value", label: "Value", type: "number", group: "content", min: 0, max: 9999, step: 1 },
    sequenceText: {
      id: "sequenceText",
      label: "Words or phrases",
      type: "textarea",
      group: "content",
      description: "One item per line"
    },
    itemsText: {
      id: "itemsText",
      label: "Feature lines",
      type: "textarea",
      group: "content",
      description: "One item per line"
    },
    tile1: { id: "tile1", label: "Tile 1", type: "text", group: "content" },
    tile2: { id: "tile2", label: "Tile 2", type: "text", group: "content" },
    tile3: { id: "tile3", label: "Tile 3", type: "text", group: "content" },
    tile4: { id: "tile4", label: "Tile 4", type: "text", group: "content" },
    valueA: { id: "valueA", label: "First value", type: "number", group: "content", min: 0, max: 1e3, step: 1 },
    valueB: { id: "valueB", label: "Second value", type: "number", group: "content", min: 0, max: 1e3, step: 1 },
    labelA: { id: "labelA", label: "First label", type: "text", group: "content" },
    labelB: { id: "labelB", label: "Second label", type: "text", group: "content" },
    footnote: { id: "footnote", label: "Footnote", type: "text", group: "content" },
    name: { id: "name", label: "Name", type: "text", group: "content" },
    role: { id: "role", label: "Role", type: "text", group: "content" },
    product: { id: "product", label: "Product", type: "text", group: "content" },
    price: { id: "price", label: "Price", type: "text", group: "content" },
    availability: { id: "availability", label: "Availability", type: "text", group: "content" },
    fontFamily: { id: "fontFamily", label: "Font", type: "select", group: "type", options: fontOptions },
    fontWeight: {
      id: "fontWeight",
      label: "Weight",
      type: "select",
      group: "type",
      options: [
        { label: "Regular", value: 400 },
        { label: "Medium", value: 500 },
        { label: "Semibold", value: 650 },
        { label: "Bold", value: 720 },
        { label: "Heavy", value: 760 },
        { label: "Black", value: 880 }
      ]
    },
    fontSize: { id: "fontSize", label: "Type size", type: "range", group: "type", min: 36, max: 220, step: 1 },
    lineHeight: { id: "lineHeight", label: "Line spacing", type: "range", group: "type", min: 0.75, max: 1.5, step: 0.01 },
    tracking: { id: "tracking", label: "Tracking", type: "range", group: "type", min: -5, max: 24, step: 0.5 },
    alignment: {
      id: "alignment",
      label: "Alignment",
      type: "segmented",
      group: "type",
      options: [
        { label: "Left", value: "left" },
        { label: "Center", value: "center" },
        { label: "Right", value: "right" }
      ]
    },
    positionX: { id: "positionX", label: "Horizontal position", type: "range", group: "layout", min: 5, max: 95, step: 1, suffix: "%" },
    positionY: { id: "positionY", label: "Vertical position", type: "range", group: "layout", min: 5, max: 95, step: 1, suffix: "%" },
    anchorX: { id: "anchorX", label: "Anchor X", type: "range", group: "layout", min: 5, max: 95, step: 1, suffix: "%" },
    anchorY: { id: "anchorY", label: "Anchor Y", type: "range", group: "layout", min: 5, max: 95, step: 1, suffix: "%" },
    labelX: { id: "labelX", label: "Label X", type: "range", group: "layout", min: 5, max: 95, step: 1, suffix: "%" },
    labelY: { id: "labelY", label: "Label Y", type: "range", group: "layout", min: 5, max: 95, step: 1, suffix: "%" },
    safeMargin: { id: "safeMargin", label: "Safe margin", type: "range", group: "layout", min: 4, max: 18, step: 1, suffix: "%" },
    cornerRadius: { id: "cornerRadius", label: "Corner radius", type: "range", group: "layout", min: 0, max: 48, step: 1 },
    textColor: { id: "textColor", label: "Text", type: "color", group: "type" },
    accentColor: { id: "accentColor", label: "Accent", type: "color", group: "type" },
    accentColor2: { id: "accentColor2", label: "Accent end", type: "color", group: "type" },
    entrance: { id: "entrance", label: "Entrance speed", type: "range", group: "motion", min: 0.15, max: 1.4, step: 0.05, suffix: "s" },
    hold: { id: "hold", label: "Hold", type: "range", group: "motion", min: 0.4, max: 5, step: 0.1, suffix: "s" },
    exit: { id: "exit", label: "Exit speed", type: "range", group: "motion", min: 0.15, max: 1.4, step: 0.05, suffix: "s" },
    intensity: { id: "intensity", label: "Motion intensity", type: "range", group: "motion", min: 0, max: 100, step: 1, suffix: "%" },
    stagger: { id: "stagger", label: "Stagger delay", type: "range", group: "motion", min: 0.03, max: 0.8, step: 0.01, suffix: "s" },
    direction: {
      id: "direction",
      label: "Direction",
      type: "select",
      group: "motion",
      options: [
        { label: "Up", value: "up" },
        { label: "Down", value: "down" },
        { label: "Left", value: "left" },
        { label: "Right", value: "right" }
      ]
    },
    countEnabled: { id: "countEnabled", label: "Animate number", type: "toggle", group: "motion" },
    loop: { id: "loop", label: "Loop sweep", type: "toggle", group: "motion" },
    sfxEnabled: { id: "sfxEnabled", label: "Add sound effect", type: "toggle", group: "output" },
    sfxVolume: { id: "sfxVolume", label: "Sound level", type: "range", group: "output", min: 0, max: 100, step: 1, suffix: "%" }
  };
  function controlsFor(ids) {
    return ids.map((id2) => {
      const control = controlRegistry[id2];
      if (!control) throw new Error("Unknown control: ".concat(id2));
      return control;
    });
  }

  // src/premiere/host.ts
  function bridge() {
    const value = window.CSBridge;
    if (!(value == null ? void 0 : value.available)) {
      throw new Error("Open Motion Plug from Window > Extensions inside Adobe Premiere Pro.");
    }
    return value;
  }
  function hostIsAvailable() {
    var _a;
    return Boolean((_a = window.CSBridge) == null ? void 0 : _a.available);
  }
  function decode(value) {
    if (!value) return "";
    try {
      return decodeURIComponent(value);
    } catch (e) {
      return value;
    }
  }
  function hostError(message) {
    const detail = message.startsWith("ERR|") ? message.slice(4) : message;
    if (detail === "SEQUENCE_CHANGED") {
      return new Error("The active sequence changed while Motion Plug was working. No timeline edit was made.");
    }
    return new Error(detail || "Premiere did not complete the requested edit.");
  }
  async function evalHost(script) {
    const result = String(await bridge().evalScript(script));
    if (result === "EvalScript error." || result.startsWith("ERR|")) throw hostError(result);
    return result;
  }
  async function callHost(functionName, payload) {
    const encoded = encodeURIComponent(JSON.stringify(payload));
    const result = await evalHost("".concat(functionName, "(").concat(JSON.stringify(encoded), ")"));
    if (!result.startsWith("OK|")) throw hostError(result);
    const serialized = decode(result.slice(3));
    try {
      return JSON.parse(serialized);
    } catch (e) {
      throw new Error("Premiere returned an unreadable response. No further timeline action was attempted.");
    }
  }
  function modules() {
    const cep = bridge();
    return { fs: cep.require("fs"), path: cep.require("path") };
  }
  function readInstance(videoPath) {
    const { fs, path } = modules();
    const metadataPath = path.join(path.dirname(path.dirname(videoPath)), "motion-plug.json");
    if (!fs.existsSync(metadataPath)) {
      throw new Error("The selected clip's Motion Plug edit data is missing. Its rendered media is still usable in Premiere.");
    }
    try {
      const document2 = JSON.parse(fs.readFileSync(metadataPath, "utf8"));
      if (!document2.instance || document2.instance.schemaVersion !== 1 || !document2.instance.presetId) {
        throw new Error("invalid metadata");
      }
      return document2.instance;
    } catch (e) {
      throw new Error("The selected clip's Motion Plug edit data is damaged. Its rendered media was not changed.");
    }
  }
  async function getTimelineContext() {
    const result = await evalHost("MP_timelineContext()");
    const parts = result.split("|");
    if (parts[0] !== "OK" || parts.length < 9) throw hostError(result);
    const fps = Number(parts[1]);
    const playheadFrame = Number(parts[4]);
    const context = {
      fps,
      width: Number(parts[2]),
      height: Number(parts[3]),
      playheadFrame,
      playheadSeconds: playheadFrame / fps,
      sequenceId: decode(parts[5]),
      projectPath: decode(parts[6]),
      projectName: decode(parts[7]) || "Untitled Project",
      sequenceName: decode(parts.slice(8).join("|")) || "Untitled Sequence"
    };
    if (!Number.isFinite(context.fps) || context.fps <= 0 || !Number.isFinite(context.width) || !Number.isFinite(context.height) || context.width < 16 || context.height < 16) {
      throw new Error("The active sequence has invalid dimensions or frame-rate settings.");
    }
    return context;
  }
  function placementPayload(request, title) {
    const { context, instance, preferences } = request;
    return {
      expectedSequenceId: context.sequenceId,
      startFrame: context.playheadFrame,
      fps: context.fps,
      frames: Math.max(1, Math.ceil(instance.duration * context.fps)),
      firstFramePath: request.firstFramePath,
      audioPath: request.audioPath || "",
      title,
      instanceId: instance.instanceId,
      videoTrackPolicy: preferences.videoTrackPolicy,
      videoTrackIndex: preferences.videoTrackIndex,
      audioTrackPolicy: preferences.audioTrackPolicy,
      audioTrackIndex: preferences.audioTrackIndex
    };
  }
  async function insertRenderedMedia(request, title) {
    const result = await callHost(
      "MP_insertGraphic",
      placementPayload(request, title)
    );
    return {
      instance: {
        ...request.instance,
        videoTrackIndex: result.videoTrackIndex,
        audioTrackIndex: result.audioTrackIndex
      },
      warning: result.warning
    };
  }
  async function getSelectedInstance() {
    const context = await getTimelineContext();
    const selected2 = await callHost("MP_selectedGraphic", {
      expectedSequenceId: context.sequenceId
    });
    const instance = readInstance(selected2.videoPath);
    return {
      context,
      instance,
      nodeId: selected2.nodeId,
      videoPath: selected2.videoPath,
      videoTrackIndex: selected2.videoTrackIndex,
      startFrame: selected2.startFrame,
      startSeconds: selected2.startSeconds
    };
  }
  async function replaceSelectedMedia(request) {
    const { selected: selected2, next, preferences } = request;
    const result = await callHost(
      "MP_replaceGraphic",
      {
        expectedSequenceId: selected2.context.sequenceId,
        selectedNodeId: selected2.nodeId,
        oldFirstFramePath: selected2.videoPath,
        oldAudioPath: selected2.instance.audioPath || "",
        oldVideoTrackIndex: selected2.videoTrackIndex,
        oldAudioTrackIndex: selected2.instance.audioTrackIndex,
        startFrame: selected2.startFrame,
        fps: selected2.context.fps,
        frames: Math.max(1, Math.ceil(next.duration * selected2.context.fps)),
        firstFramePath: request.firstFramePath,
        audioPath: request.audioPath || "",
        title: request.title,
        instanceId: next.instanceId,
        audioTrackPolicy: preferences.audioTrackPolicy,
        audioTrackIndex: preferences.audioTrackIndex
      }
    );
    return {
      instance: {
        ...next,
        videoTrackIndex: result.videoTrackIndex,
        audioTrackIndex: result.audioTrackIndex
      },
      warning: result.warning
    };
  }

  // src/premiere/filesystem.ts
  function modules2() {
    var _a;
    const load = typeof window !== "undefined" && ((_a = window.CSBridge) == null ? void 0 : _a.require) ? window.CSBridge.require : __require;
    return {
      fs: load("fs"),
      path: load("path"),
      os: load("os")
    };
  }
  function safeSegment(value) {
    return value.replace(/[<>:"/\\|?*\x00-\x1f]+/g, "-").replace(/\s+/g, "-").replace(/^-+|-+$/g, "").slice(0, 72) || "untitled";
  }
  async function resolveMediaDestination(projectPath, projectName, instanceId, renderVersion) {
    const { path, os } = modules2();
    let root2;
    let durable = Boolean(projectPath);
    let warning;
    if (projectPath) {
      const projectFolder = path.dirname(projectPath);
      const projectStem = safeSegment(path.basename(projectPath, path.extname(projectPath)) || projectName);
      root2 = path.join(projectFolder, "Motion Plug Media", projectStem);
    } else {
      root2 = path.join(os.homedir(), "Documents", "Motion Plug Media", safeSegment(projectName));
      durable = false;
      warning = "This project has not been saved. Media was placed in Documents/Motion Plug Media; save the project before building a final edit.";
    }
    const versionFolder = path.join(root2, safeSegment(instanceId), "v".concat(Math.max(1, Math.floor(renderVersion))));
    const framesFolder = path.join(versionFolder, "frames");
    return {
      root: root2,
      versionFolder,
      framesFolder,
      firstFramePath: path.join(framesFolder, "frame_000000.png"),
      audioPath: path.join(versionFolder, "motion-plug-sfx.wav"),
      metadataPath: path.join(versionFolder, "motion-plug.json"),
      durable,
      warning
    };
  }
  async function prepareDestination(destination) {
    var _a;
    const { fs } = modules2();
    if ((_a = fs.promises) == null ? void 0 : _a.mkdir) await fs.promises.mkdir(destination.framesFolder, { recursive: true });
    else fs.mkdirSync(destination.framesFolder, { recursive: true });
  }
  async function writeBinary(path, bytes) {
    var _a;
    const { fs } = modules2();
    const payload = typeof Buffer !== "undefined" ? Buffer.from(bytes) : bytes;
    if ((_a = fs.promises) == null ? void 0 : _a.writeFile) await fs.promises.writeFile(path, payload);
    else fs.writeFileSync(path, payload);
  }
  async function writeText(path, content) {
    var _a;
    const { fs } = modules2();
    if ((_a = fs.promises) == null ? void 0 : _a.writeFile) await fs.promises.writeFile(path, content, { encoding: "utf-8" });
    else fs.writeFileSync(path, content, { encoding: "utf-8" });
  }
  async function removeCreatedVersion(destination) {
    var _a;
    const { fs } = modules2();
    try {
      if ((_a = fs.promises) == null ? void 0 : _a.rm) await fs.promises.rm(destination.versionFolder, { recursive: true, force: true });
      else if (fs.rmSync) fs.rmSync(destination.versionFolder, { recursive: true, force: true });
      else if (fs.existsSync(destination.versionFolder)) fs.rmdirSync(destination.versionFolder, { recursive: true });
    } catch (e) {
    }
  }
  function framePath(folder, index) {
    const { path } = modules2();
    return path.join(folder, "frame_".concat(Math.max(0, index).toString().padStart(6, "0"), ".png"));
  }
  function decodeDataUrl(dataUrl) {
    const separator = dataUrl.indexOf(",");
    if (separator < 0 || !dataUrl.slice(0, separator).includes(";base64")) {
      throw new Error("Renderer returned an invalid PNG data URL.");
    }
    const binary = atob(dataUrl.slice(separator + 1));
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
    return bytes;
  }

  // src/premiere/workflow.ts
  function id() {
    try {
      return crypto.randomUUID();
    } catch (e) {
      return "".concat(Date.now().toString(36), "-").concat(Math.random().toString(36).slice(2, 11));
    }
  }
  function renderConfig(presetId, values2, dimensions, duration) {
    return {
      presetId,
      values: values2,
      width: dimensions.width,
      height: dimensions.height,
      duration,
      background: "transparent",
      renderMode: "export"
    };
  }
  var MotionPlugWorkflow = class {
    constructor(renderer) {
      this.renderer = renderer;
      this.busy = false;
    }
    isBusy() {
      return this.busy;
    }
    async renderAssets(input, context, instanceId, renderVersion) {
      var _a, _b;
      const preset2 = presetById.get(input.presetId);
      if (!preset2) throw new Error("The selected preset is no longer installed.");
      const values2 = valuesForPreset(input.presetId, input.values);
      const duration = Math.ceil(computeDuration(values2, preset2.duration) * context.fps) / context.fps;
      const dimensions = { width: context.width, height: context.height };
      const destination = await resolveMediaDestination(
        context.projectPath,
        context.projectName,
        instanceId,
        renderVersion
      );
      await prepareDestination(destination);
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const instance = {
        schemaVersion: 1,
        instanceId,
        presetId: preset2.id,
        presetVersion: preset2.version,
        values: values2,
        duration,
        fps: context.fps,
        width: dimensions.width,
        height: dimensions.height,
        videoTrackIndex: 0,
        renderVersion,
        videoPath: destination.firstFramePath,
        audioPath: void 0,
        createdAt: now,
        updatedAt: now
      };
      const warnings = [destination.warning].filter((value) => Boolean(value));
      try {
        const rendered = await this.renderer.render(
          renderConfig(preset2.id, values2, dimensions, duration),
          context.fps,
          destination.framesFolder,
          (progress) => {
            var _a2;
            return (_a2 = input.onProgress) == null ? void 0 : _a2.call(input, { ...progress, stage: "rendering" });
          }
        );
        warnings.push(...rendered.warnings);
        if (Boolean((_a = values2.sfxEnabled) != null ? _a : input.preferences.sfxEnabled)) {
          const wav = await createSoundtrack(preset2, values2, duration, Number((_b = values2.sfxVolume) != null ? _b : input.preferences.sfxVolume));
          await writeBinary(destination.audioPath, wav);
          instance.audioPath = destination.audioPath;
        }
        await writeText(destination.metadataPath, JSON.stringify({
          format: "Motion Plug Render Source",
          generatedAt: now,
          status: "rendered",
          instance,
          preset: preset2,
          sfxCues: planSoundCues(preset2, values2, duration)
        }, null, 2));
        return { instance, destination, warnings };
      } catch (error) {
        await removeCreatedVersion(destination);
        throw error;
      }
    }
    async add(input) {
      var _a;
      if (this.busy) throw new Error("Motion Plug is already rendering another graphic.");
      this.busy = true;
      try {
        const context = await getTimelineContext();
        const preset2 = presetById.get(input.presetId);
        if (!preset2) throw new Error("The selected preset is missing.");
        const rendered = await this.renderAssets(input, context, id(), 1);
        (_a = input.onProgress) == null ? void 0 : _a.call(input, { frame: 1, total: 1, ratio: 1, stage: "importing" });
        try {
          const inserted = await insertRenderedMedia({
            context,
            instance: rendered.instance,
            firstFramePath: rendered.destination.firstFramePath,
            audioPath: rendered.instance.audioPath,
            preferences: input.preferences
          }, preset2.name);
          await writeText(rendered.destination.metadataPath, JSON.stringify({
            format: "Motion Plug Render Source",
            generatedAt: rendered.instance.createdAt,
            status: "inserted",
            instance: inserted.instance,
            preset: preset2,
            sfxCues: planSoundCues(preset2, rendered.instance.values, rendered.instance.duration)
          }, null, 2));
          return {
            ...inserted,
            warnings: [...rendered.warnings, inserted.warning].filter((value) => Boolean(value)),
            mediaFolder: rendered.destination.versionFolder
          };
        } catch (error) {
          await writeText(rendered.destination.metadataPath, JSON.stringify({
            format: "Motion Plug Render Source",
            status: "rendered-not-inserted",
            reason: error instanceof Error ? error.message : String(error),
            instance: rendered.instance,
            preset: preset2
          }, null, 2));
          throw error;
        }
      } finally {
        this.busy = false;
      }
    }
    async selected() {
      return getSelectedInstance();
    }
    async update(input, selected2) {
      var _a;
      if (this.busy) throw new Error("Motion Plug is already rendering another graphic.");
      this.busy = true;
      try {
        const source = selected2 != null ? selected2 : await getSelectedInstance();
        const preset2 = presetById.get(input.presetId);
        if (!preset2) throw new Error("The selected preset is missing.");
        const rendered = await this.renderAssets(
          input,
          source.context,
          source.instance.instanceId,
          source.instance.renderVersion + 1
        );
        rendered.instance.createdAt = source.instance.createdAt;
        rendered.instance.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
        (_a = input.onProgress) == null ? void 0 : _a.call(input, { frame: 1, total: 1, ratio: 1, stage: "importing" });
        try {
          const replaced = await replaceSelectedMedia({
            selected: source,
            next: rendered.instance,
            firstFramePath: rendered.destination.firstFramePath,
            audioPath: rendered.instance.audioPath,
            preferences: input.preferences,
            title: preset2.name
          });
          await writeText(rendered.destination.metadataPath, JSON.stringify({
            format: "Motion Plug Render Source",
            status: "inserted-update",
            instance: replaced.instance,
            preset: preset2,
            sfxCues: planSoundCues(preset2, rendered.instance.values, rendered.instance.duration)
          }, null, 2));
          return {
            ...replaced,
            warnings: [...rendered.warnings, replaced.warning].filter((value) => Boolean(value)),
            mediaFolder: rendered.destination.versionFolder
          };
        } catch (error) {
          await writeText(rendered.destination.metadataPath, JSON.stringify({
            format: "Motion Plug Render Source",
            status: "rendered-update-not-inserted",
            reason: error instanceof Error ? error.message : String(error),
            instance: rendered.instance,
            preset: preset2
          }, null, 2));
          throw error;
        }
      } finally {
        this.busy = false;
      }
    }
  };

  // src/render/render-client.ts
  var RenderClient = class {
    constructor(frame) {
      this.frame = frame;
      this.ready = false;
      this.readyWaiters = /* @__PURE__ */ new Set();
      this.configurationWaiters = /* @__PURE__ */ new Map();
      this.destroyed = false;
      this.elementListener = (event) => {
        var _a;
        void this.receive((_a = event.data) != null ? _a : event.detail);
      };
      this.windowListener = (event) => {
        if (event.data) void this.receive(event.data);
      };
      this.loadErrorListener = (event) => {
        const detail = event;
        this.failReady(new Error(detail.message || "The preview renderer could not be loaded."));
      };
      this.frame.addEventListener("message", this.elementListener);
      window.addEventListener("message", this.windowListener);
      this.frame.addEventListener("loaderror", this.loadErrorListener);
      this.frame.addEventListener("loadstop", () => this.send({ type: "ping" }));
      this.frame.addEventListener("load", () => this.send({ type: "ping" }));
      window.setTimeout(() => {
        if (!this.ready && !this.destroyed) this.send({ type: "ping" });
      }, 200);
    }
    parse(raw) {
      try {
        if (typeof raw === "string") return JSON.parse(raw);
        return raw && typeof raw === "object" ? raw : void 0;
      } catch (e) {
        return void 0;
      }
    }
    send(message) {
      var _a;
      if (this.destroyed) return;
      const serialized = JSON.stringify(message);
      if (typeof this.frame.postMessage === "function") this.frame.postMessage(serialized);
      else (_a = this.frame.contentWindow) == null ? void 0 : _a.postMessage(serialized, "*");
    }
    failReady(error) {
      this.readyError = error;
      for (const waiter of this.readyWaiters) {
        window.clearTimeout(waiter.timeout);
        waiter.reject(error);
      }
      this.readyWaiters.clear();
    }
    async receive(raw) {
      var _a, _b, _c, _d;
      const message = this.parse(raw);
      if (!message) return;
      if (message.type === "renderer-ready") {
        this.ready = true;
        this.readyError = void 0;
        for (const waiter of this.readyWaiters) {
          window.clearTimeout(waiter.timeout);
          waiter.resolve();
        }
        this.readyWaiters.clear();
        return;
      }
      if (message.type === "renderer-error") {
        this.failReady(new Error(message.message || "The preview renderer failed to start."));
        return;
      }
      if (message.type === "configured" && message.requestId) {
        const waiter = this.configurationWaiters.get(message.requestId);
        if (waiter) {
          window.clearTimeout(waiter.timeout);
          this.configurationWaiters.delete(message.requestId);
          waiter.resolve();
        }
        return;
      }
      if (message.type === "configure-error" && message.requestId) {
        const waiter = this.configurationWaiters.get(message.requestId);
        if (waiter) {
          window.clearTimeout(waiter.timeout);
          this.configurationWaiters.delete(message.requestId);
          waiter.reject(new Error(message.message || "The renderer rejected this preset."));
        }
        return;
      }
      const job = this.active;
      if (!job || message.jobId !== job.id) return;
      if (message.type === "render-frame") {
        try {
          if (message.frame === void 0 || !message.dataUrl) throw new Error("Renderer returned an incomplete frame.");
          for (const warning of (_a = message.warnings) != null ? _a : []) job.warnings.add(warning);
          await writeBinary(framePath(job.folder, message.frame), decodeDataUrl(message.dataUrl));
          this.send({ type: "render-ack", jobId: job.id, frame: message.frame });
          const total = Math.max(1, Number((_b = message.total) != null ? _b : 1));
          (_c = job.progress) == null ? void 0 : _c.call(job, { frame: message.frame + 1, total, ratio: (message.frame + 1) / total });
        } catch (error) {
          this.send({ type: "render-cancel", jobId: job.id });
          this.active = void 0;
          job.reject(error instanceof Error ? error : new Error(String(error)));
        }
        return;
      }
      if (message.type === "render-complete") {
        this.active = void 0;
        job.resolve({ frameCount: Number((_d = message.total) != null ? _d : 0), warnings: [...job.warnings] });
      } else if (message.type === "render-error") {
        this.active = void 0;
        job.reject(new Error(message.message || "The animation renderer failed."));
      }
    }
    async waitUntilReady(timeoutMs = 8e3) {
      if (this.ready) return;
      if (this.readyError) throw this.readyError;
      await new Promise((resolve, reject) => {
        const waiter = { resolve, reject, timeout: 0 };
        waiter.timeout = window.setTimeout(() => {
          this.readyWaiters.delete(waiter);
          reject(new Error("The preview renderer did not become ready."));
        }, timeoutMs);
        this.readyWaiters.add(waiter);
      });
    }
    async configure(config) {
      await this.waitUntilReady();
      const requestId = "config-".concat(Date.now().toString(36), "-").concat(Math.random().toString(36).slice(2, 7));
      const acknowledgement = new Promise((resolve, reject) => {
        const timeout = window.setTimeout(() => {
          this.configurationWaiters.delete(requestId);
          reject(new Error("The renderer did not accept the configuration."));
        }, 8e3);
        this.configurationWaiters.set(requestId, { resolve, reject, timeout });
      });
      this.send({ type: "configure", config, requestId });
      await acknowledgement;
    }
    play() {
      this.send({ type: "play" });
    }
    pause() {
      this.send({ type: "pause" });
    }
    replay() {
      this.send({ type: "replay" });
    }
    seek(time) {
      this.send({ type: "seek", time });
    }
    async render(config, fps, folder, progress) {
      if (this.active) throw new Error("Another animation is already rendering.");
      await this.configure({ ...config, renderMode: "export", background: "transparent" });
      const id2 = "render-".concat(Date.now().toString(36), "-").concat(Math.random().toString(36).slice(2, 8));
      return new Promise((resolve, reject) => {
        this.active = { id: id2, folder, resolve, reject, warnings: /* @__PURE__ */ new Set(), progress };
        this.send({ type: "render-start", jobId: id2, fps });
      });
    }
    cancel() {
      if (!this.active) return;
      const job = this.active;
      this.send({ type: "render-cancel", jobId: job.id });
      this.active = void 0;
      job.reject(new Error("Render cancelled."));
    }
    destroy() {
      if (this.destroyed) return;
      this.destroyed = true;
      this.cancel();
      this.frame.removeEventListener("message", this.elementListener);
      this.frame.removeEventListener("loaderror", this.loadErrorListener);
      window.removeEventListener("message", this.windowListener);
      for (const waiter of this.configurationWaiters.values()) {
        window.clearTimeout(waiter.timeout);
        waiter.reject(new Error("Renderer closed."));
      }
      this.configurationWaiters.clear();
      for (const waiter of this.readyWaiters) {
        window.clearTimeout(waiter.timeout);
        waiter.reject(new Error("Renderer closed."));
      }
      this.readyWaiters.clear();
    }
  };

  // src/fonts/custom-fonts.ts
  var loaded = /* @__PURE__ */ new Map();
  function validFontSignature(bytes) {
    return bytes.length >= 12 && (bytes[0] === 0 && bytes[1] === 1 && bytes[2] === 0 && bytes[3] === 0 || String.fromCharCode(...bytes.slice(0, 4)) === "OTTO" || String.fromCharCode(...bytes.slice(0, 4)) === "true");
  }
  async function loadCustomFont(values2) {
    var _a, _b;
    const family = String((_a = values2.fontFamily) != null ? _a : "");
    if (!family.startsWith("MotionPlugCustom-")) return;
    const data = String((_b = values2.fontData) != null ? _b : "");
    if (!/^data:font\/(ttf|otf);base64,[A-Za-z0-9+/=]+$/.test(data)) {
      throw new Error("This custom font is missing. Import its OTF or TTF file again in Typography & color.");
    }
    if (!loaded.has(family)) {
      loaded.set(family, (async () => {
        try {
          const face = new FontFace(family, "url(".concat(data, ")"));
          await face.load();
          document.fonts.add(face);
        } catch (e) {
          loaded.delete(family);
          throw new Error("This font could not be loaded. Choose a valid OTF or TTF file.");
        }
      })());
    }
    await loaded.get(family);
  }
  function database() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open("motionplug-fonts", 1);
      request.onupgradeneeded = () => request.result.createObjectStore("fonts", { keyPath: "family" });
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(new Error("Local font storage is unavailable."));
    });
  }
  async function listCustomFonts() {
    const db = await database();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction("fonts", "readonly");
      const request = transaction.objectStore("fonts").getAll();
      transaction.oncomplete = () => {
        db.close();
        resolve(request.result);
      };
      transaction.onerror = () => {
        db.close();
        reject(new Error("Could not read saved fonts."));
      };
    });
  }
  async function importCustomFont(file) {
    if (!/\.(otf|ttf)$/i.test(file.name) || file.size > 10 * 1024 * 1024) {
      throw new Error("Choose an OTF or TTF font smaller than 10 MB.");
    }
    const data = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error("Could not read this font file."));
      reader.readAsArrayBuffer(file);
    });
    const bytes = new Uint8Array(data);
    if (!validFontSignature(bytes)) throw new Error("This file is not a valid OTF or TTF font.");
    let hash = 2166136261;
    let binary = "";
    for (const byte of bytes) {
      hash = Math.imul(hash ^ byte, 16777619);
      binary += String.fromCharCode(byte);
    }
    const font = {
      family: "MotionPlugCustom-".concat((hash >>> 0).toString(16), "-").concat(bytes.length),
      name: file.name.replace(/\.(otf|ttf)$/i, ""),
      data: "data:font/".concat(/\.otf$/i.test(file.name) ? "otf" : "ttf", ";base64,").concat(btoa(binary))
    };
    await loadCustomFont({ fontFamily: font.family, fontData: font.data });
    const db = await database();
    await new Promise((resolve, reject) => {
      const transaction = db.transaction("fonts", "readwrite");
      transaction.objectStore("fonts").put(font);
      transaction.oncomplete = () => {
        db.close();
        resolve();
      };
      transaction.onabort = transaction.onerror = () => {
        db.close();
        reject(new Error("Could not save this font. Free local storage and import it again."));
      };
    });
    return font;
  }

  // src/storage/settings.ts
  var SETTINGS_KEY = "motionplug.settings.v1";
  var defaultPreferences = {
    previewBackground: "checker",
    aspectRatio: "16:9",
    sfxEnabled: true,
    sfxVolume: 68,
    videoTrackPolicy: "auto",
    videoTrackIndex: 0,
    audioTrackPolicy: "auto",
    audioTrackIndex: 0
  };
  var defaultState = {
    schemaVersion: 1,
    favorites: [],
    recent: [],
    variations: [],
    preferences: defaultPreferences
  };
  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }
  function strings(value) {
    return Array.isArray(value) ? [...new Set(value.filter((item) => typeof item === "string"))] : [];
  }
  function recentItems(value) {
    if (!Array.isArray(value)) return [];
    return value.filter((item) => Boolean(item && typeof item.presetId === "string" && typeof item.usedAt === "string")).slice(0, 24);
  }
  function variations(value) {
    if (!Array.isArray(value)) return [];
    return value.filter(
      (item) => Boolean(
        item && typeof item.id === "string" && typeof item.name === "string" && typeof item.presetId === "string" && item.values && typeof item.values === "object" && typeof item.createdAt === "string" && typeof item.updatedAt === "string"
      )
    );
  }
  function normalizeState(value) {
    var _a, _b, _c, _d;
    if (!value || typeof value !== "object") return clone(defaultState);
    const input = value;
    const preferences = (_a = input.preferences) != null ? _a : {};
    return {
      schemaVersion: 1,
      favorites: strings(input.favorites),
      recent: recentItems(input.recent),
      variations: variations(input.variations),
      preferences: {
        ...defaultPreferences,
        ...preferences,
        previewBackground: ["dark", "light", "checker"].includes(String(preferences.previewBackground)) ? preferences.previewBackground : defaultPreferences.previewBackground,
        aspectRatio: ["16:9", "9:16", "1:1"].includes(String(preferences.aspectRatio)) ? preferences.aspectRatio : defaultPreferences.aspectRatio,
        sfxVolume: Math.min(100, Math.max(0, Number((_b = preferences.sfxVolume) != null ? _b : defaultPreferences.sfxVolume))),
        videoTrackIndex: Math.max(0, Math.floor(Number((_c = preferences.videoTrackIndex) != null ? _c : 0))),
        audioTrackIndex: Math.max(0, Math.floor(Number((_d = preferences.audioTrackIndex) != null ? _d : 0)))
      }
    };
  }
  var SettingsStore = class {
    constructor(storage = localStorage) {
      this.storage = storage;
      this.state = this.read();
    }
    read() {
      try {
        const serialized = this.storage.getItem(SETTINGS_KEY);
        return serialized ? normalizeState(JSON.parse(serialized)) : clone(defaultState);
      } catch (e) {
        return clone(defaultState);
      }
    }
    write() {
      try {
        this.storage.setItem(SETTINGS_KEY, JSON.stringify(this.state));
      } catch (e) {
      }
    }
    snapshot() {
      return clone(this.state);
    }
    updatePreferences(change) {
      this.state = normalizeState({
        ...this.state,
        preferences: { ...this.state.preferences, ...change }
      });
      this.write();
      return this.snapshot();
    }
    toggleFavorite(presetId) {
      const favorite = this.state.favorites.includes(presetId);
      this.state.favorites = favorite ? this.state.favorites.filter((id2) => id2 !== presetId) : [presetId, ...this.state.favorites];
      this.write();
      return this.snapshot();
    }
    markRecent(presetId) {
      const item = { presetId, usedAt: (/* @__PURE__ */ new Date()).toISOString() };
      this.state.recent = [item, ...this.state.recent.filter((recent) => recent.presetId !== presetId)].slice(0, 24);
      this.write();
      return this.snapshot();
    }
    saveVariation(presetId, name, values2, id2) {
      var _a, _b;
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const existing = id2 ? this.state.variations.find((item) => item.id === id2) : void 0;
      const variation = {
        id: (_a = existing == null ? void 0 : existing.id) != null ? _a : "variation-".concat(Date.now().toString(36), "-").concat(Math.random().toString(36).slice(2, 7)),
        name: name.trim() || "Untitled variation",
        presetId,
        values: clone(values2),
        createdAt: (_b = existing == null ? void 0 : existing.createdAt) != null ? _b : now,
        updatedAt: now
      };
      this.state.variations = [variation, ...this.state.variations.filter((item) => item.id !== variation.id)];
      this.write();
      return variation;
    }
    removeVariation(id2) {
      this.state.variations = this.state.variations.filter((item) => item.id !== id2);
      this.write();
      return this.snapshot();
    }
  };

  // src/panel/main.ts
  var rootElement = document.querySelector("#app");
  if (!rootElement) throw new Error("Motion Plug could not find its application root.");
  var root = rootElement;
  var groups = [
    { id: "content", label: "Content" },
    { id: "type", label: "Typography & color" },
    { id: "layout", label: "Layout" },
    { id: "motion", label: "Timing & motion" },
    { id: "output", label: "Output" }
  ];
  var store = new SettingsStore();
  var persisted = store.snapshot();
  var view = "library";
  var scope = "all";
  var search = "";
  var categoryFilter = "all";
  var customFonts = [];
  var timelineContext;
  var timelineError = "";
  var refreshingTimeline = false;
  var openSections = /* @__PURE__ */ new Set(["content"]);
  var selected = presets[0];
  var values = valuesForPreset(selected.id);
  var renderClient;
  var workflow;
  var previewElement;
  var previewResizeListener;
  var previewGeneration = 0;
  var previewReady = false;
  var previewFailed = false;
  var previewTime = 0;
  var previewPlaying = false;
  var previewPoster = true;
  var previewTimer;
  var activeAudio;
  var activeAudioUrl;
  var audioGeneration = 0;
  var hostAvailable = false;
  var busy = false;
  var variationEditorOpen = false;
  var signedIn = false;
  var signInBusy = false;
  var availableUpdate;
  var updateOperationBusy = false;
  var announcedUpdateVersion = "";
  function escapeHtml(value) {
    return String(value != null ? value : "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }
  function icon(name) {
    const paths = {
      search: '<circle cx="10.8" cy="10.8" r="6.3"/><path d="m16 16 4 4"/>',
      heart: '<path d="M20.8 8.8c0 5.7-8.8 10.5-8.8 10.5S3.2 14.5 3.2 8.8A4.6 4.6 0 0 1 12 7a4.6 4.6 0 0 1 8.8 1.8Z"/>',
      back: '<path d="m15 18-6-6 6-6"/>',
      play: '<path d="m8 5 11 7-11 7Z"/>',
      pause: '<path d="M8 5v14M16 5v14"/>',
      replay: '<path d="M4.5 9A8 8 0 1 1 5 16"/><path d="M4.5 4v5h5"/>',
      sound: '<path d="M5 14H2v-4h3l5-4v12l-5-4Z"/><path d="M14 9a4 4 0 0 1 0 6M17 6a8 8 0 0 1 0 12"/>',
      sliders: '<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>',
      plus: '<path d="M12 5v14M5 12h14"/>',
      update: '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M18.4 9A7 7 0 0 0 6.8 6.4L4 9M5.6 15A7 7 0 0 0 17.2 17.6L20 15"/>',
      close: '<path d="m6 6 12 12M18 6 6 18"/>'
    };
    return '<svg viewBox="0 0 24 24" aria-hidden="true">'.concat(paths[name], "</svg>");
  }
  function announce(message, tone = "neutral", timeout = 5e3) {
    var _a, _b;
    let region = document.querySelector("#toast-region");
    if (!region) {
      region = document.createElement("div");
      region.id = "toast-region";
      region.className = "toast-region";
      region.setAttribute("aria-live", "assertive");
      document.body.append(region);
    }
    const duplicate = [...region.querySelectorAll(".toast span")].find((item) => item.textContent === message);
    if (duplicate) return;
    while (region.children.length >= 2) (_a = region.firstElementChild) == null ? void 0 : _a.remove();
    const toast = document.createElement("div");
    toast.className = "toast toast--".concat(tone);
    toast.innerHTML = "<span>".concat(escapeHtml(message), '</span><button class="icon-button toast__close" aria-label="Dismiss">').concat(icon("close"), "</button>");
    (_b = toast.querySelector("button")) == null ? void 0 : _b.addEventListener("click", () => toast.remove());
    region.append(toast);
    window.setTimeout(() => toast.remove(), timeout);
  }
  function queryPresets() {
    let items = presets;
    if (scope === "favorites") items = items.filter((item) => persisted.favorites.includes(item.id));
    else if (scope === "recent") {
      const rank = new Map(persisted.recent.map((item, index) => [item.presetId, index]));
      items = items.filter((item) => rank.has(item.id)).sort((a, b) => {
        var _a, _b;
        return ((_a = rank.get(a.id)) != null ? _a : 99) - ((_b = rank.get(b.id)) != null ? _b : 99);
      });
    } else if (scope !== "all" && scope !== "variations") {
      items = items.filter((item) => item.category === scope);
    }
    if (categoryFilter !== "all") items = items.filter((item) => item.category === categoryFilter);
    const query = search.trim().toLocaleLowerCase();
    if (query) {
      items = items.filter(
        (item) => [item.name, item.familyName, item.category, item.description, ...item.tags].join(" ").toLocaleLowerCase().includes(query)
      );
    }
    return items;
  }
  function cardMarkup(preset2) {
    const favorite = persisted.favorites.includes(preset2.id);
    return '\n    <article class="preset-card" data-preset-id="'.concat(escapeHtml(preset2.id), '">\n      <button class="preset-card__select" aria-label="Open ').concat(escapeHtml(preset2.name), '">\n        <span class="preset-card__visual">\n          <img loading="lazy" src="previews/').concat(escapeHtml(preset2.id), '.jpg" alt="" />\n          <span class="preset-card__fallback" aria-hidden="true">').concat(escapeHtml(preset2.name.split(" ").slice(0, 2).map((word) => word[0]).join("")), '</span>\n          <span class="preset-card__play">').concat(icon("play"), '</span>\n        </span>\n        <span class="preset-card__copy">\n          <strong>').concat(escapeHtml(preset2.name), "</strong>\n          <small>").concat(computeDuration(preset2.defaults, preset2.duration).toFixed(1), 's</small>\n        </span>\n      </button>\n      <button class="favorite-button ').concat(favorite ? "is-active" : "", '" data-favorite="').concat(escapeHtml(preset2.id), '" aria-label="').concat(favorite ? "Remove from" : "Add to", ' favorites" aria-pressed="').concat(favorite, '">').concat(icon("heart"), "</button>\n    </article>");
  }
  function variationMarkup() {
    const query = search.trim().toLocaleLowerCase();
    const items = persisted.variations.filter((item) => {
      var _a;
      const preset2 = presetById.get(item.presetId);
      return !query || "".concat(item.name, " ").concat((_a = preset2 == null ? void 0 : preset2.name) != null ? _a : "").toLocaleLowerCase().includes(query);
    });
    if (!items.length) return emptyMarkup(search ? "No variations match this search." : "Save a customized preset and it will appear here.", "No saved variations");
    return '<div class="variation-list">'.concat(items.map((item) => {
      var _a;
      const preset2 = presetById.get(item.presetId);
      return '<article class="variation-row">\n      <button data-variation="'.concat(escapeHtml(item.id), '">\n        <span class="variation-row__thumb"><img src="previews/').concat(escapeHtml(item.presetId), '.jpg" alt="" /></span>\n        <span><strong>').concat(escapeHtml(item.name), "</strong><small>").concat(escapeHtml((_a = preset2 == null ? void 0 : preset2.name) != null ? _a : "Missing preset"), '</small></span>\n      </button>\n      <button class="icon-button" data-remove-variation="').concat(escapeHtml(item.id), '" aria-label="Delete ').concat(escapeHtml(item.name), '">').concat(icon("close"), "</button>\n    </article>");
    }).join(""), "</div>");
  }
  function emptyMarkup(message, title = "Nothing here yet") {
    return '<div class="empty-state"><span class="empty-state__mark">MP</span><h2>'.concat(escapeHtml(title), "</h2><p>").concat(escapeHtml(message), "</p>").concat(scope !== "all" ? '<button class="quiet-button" data-clear-filter>Show all presets</button>' : "", "</div>");
  }
  function familyGroupsMarkup(items) {
    if (scope === "recent" || scope === "favorites") return '<div class="preset-grid">'.concat(items.map(cardMarkup).join(""), "</div>");
    const families = [...new Set(items.map((item) => item.family))];
    return families.map((family) => {
      const variants = items.filter((item) => item.family === family);
      return '<section class="preset-family" aria-label="'.concat(escapeHtml(variants[0].familyName), '"><div class="family-heading"><h2>').concat(escapeHtml(variants[0].familyName), "</h2><span>").concat(variants.length, ' variants</span></div><div class="preset-grid">').concat(variants.map(cardMarkup).join(""), "</div></section>");
    }).join("");
  }
  function accountStripMarkup() {
    if (!licenseApi()) return "";
    return '<div class="account-strip" data-account-strip>\n    <span class="account-strip__dot"></span>\n    <span class="account-strip__text" data-account-text>Checking your account\u2026</span>\n    <button class="quiet-button" data-account-action>Sign in</button>\n  </div>';
  }
  function appUpdateButtonMarkup() {
    return '<button type="button" class="app-update-button" data-install-app-update hidden>'.concat(icon("update"), " <span>Update</span></button>");
  }
  function libraryMarkup() {
    var _a;
    const items = queryPresets();
    const filterLabel = scope === "all" ? "All presets" : scope === "favorites" ? "Favorites" : scope === "recent" ? "Recently used" : scope === "variations" ? "Saved variations" : scope;
    const count = scope === "variations" ? persisted.variations.length : items.length;
    const navigation = [
      { id: "all", label: "All" },
      { id: "favorites", label: "Favorites".concat(persisted.favorites.length ? " \xB7 ".concat(persisted.favorites.length) : "") },
      { id: "recent", label: "Recent" },
      { id: "variations", label: "Variations" }
    ];
    return '\n    <main class="library">\n      <header class="app-header">\n        <div class="brand"><span class="brand__mark"><img src="icons/motionplug-logo.png" alt="" /></span><span><strong>Motion Plug</strong><small>Motion, ready when you are.</small></span></div>\n        <div class="app-header__actions">'.concat(appUpdateButtonMarkup(), '<span class="host-pill ').concat(hostAvailable ? "is-live" : "", '" title="').concat(hostAvailable ? "Connected to Premiere" : "Preview mode", '"><i></i>').concat(hostAvailable ? "Premiere" : "Preview", '</span></div>\n      </header>\n      <section class="library-tools" aria-label="Browse presets">\n        <label class="search-field">').concat(icon("search"), '<input id="preset-search" type="search" placeholder="Search 30 presets" value="').concat(escapeHtml(search), '" autocomplete="off" aria-label="Search presets" /><kbd>\u2318K</kbd></label>\n        <nav class="filter-strip" aria-label="Preset filters">').concat(navigation.map((item) => '<button class="filter-chip '.concat(scope === item.id ? "is-active" : "", '" data-scope="').concat(escapeHtml(item.id), '" aria-pressed="').concat(scope === item.id, '">').concat(escapeHtml(item.label), "</button>")).join(""), "</nav>\n        ").concat(scope !== "variations" ? '<label class="category-filter"><span>Category</span><select data-category aria-label="Preset category"><option value="all">All categories</option>'.concat(categories.map((category) => '<option value="'.concat(escapeHtml(category), '" ').concat(categoryFilter === category ? "selected" : "", ">").concat(escapeHtml(category), "</option>")).join(""), "</select></label>") : "", '\n      </section>\n      <section class="library-content" aria-labelledby="library-heading">\n        <div class="section-heading"><div><p>Library</p><h1 id="library-heading">').concat(escapeHtml(filterLabel), "</h1></div><span>").concat(count, " ").concat(count === 1 ? "item" : "items", "</span></div>\n        ").concat(scope === "variations" ? variationMarkup() : items.length ? familyGroupsMarkup(items) : emptyMarkup(search ? "Try a broader name, family, category, or tag." : "Use the heart on a preset to keep it close.", search ? "No matching presets" : void 0), '\n      </section>\n      <footer class="library-footer">\n        ').concat(accountStripMarkup(), '\n        <div class="library-footer__meta"><span>v').concat(escapeHtml((_a = window.MP_VERSION) != null ? _a : "0.3.0"), ' \xB7 30 presets \xB7 Offline</span><div><button class="quiet-button" data-check-updates ').concat(hostAvailable ? "" : "disabled", '>Check for updates</button><button class="quiet-button" data-load-selected>').concat(icon("update"), " Edit timeline selection</button></div></div>\n      </footer>\n    </main>");
  }
  function inputMarkup(control) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i;
    const current = (_a = values[control.id]) != null ? _a : "";
    const id2 = "control-".concat(control.id);
    if (control.type === "textarea") {
      return '<label class="field field--wide" for="'.concat(id2, '"><span>').concat(escapeHtml(control.label), '</span><textarea id="').concat(id2, '" data-control="').concat(control.id, '" rows="').concat(control.id === "itemsText" || control.id === "sequenceText" ? 4 : 2, '" placeholder="').concat(escapeHtml((_b = control.placeholder) != null ? _b : ""), '">').concat(escapeHtml(current), "</textarea>").concat(control.description ? "<small>".concat(escapeHtml(control.description), "</small>") : "", "</label>");
    }
    if (control.type === "text" || control.type === "number") {
      return '<label class="field '.concat(control.type === "text" ? "field--wide" : "", '" for="').concat(id2, '"><span>').concat(escapeHtml(control.label), '</span><input id="').concat(id2, '" data-control="').concat(control.id, '" type="').concat(control.type, '" value="').concat(escapeHtml(current), '" ').concat(control.min !== void 0 ? 'min="'.concat(control.min, '"') : "", " ").concat(control.max !== void 0 ? 'max="'.concat(control.max, '"') : "", " ").concat(control.step !== void 0 ? 'step="'.concat(control.step, '"') : "", " /></label>");
    }
    if (control.type === "range") {
      return '<label class="field field--range" for="'.concat(id2, '"><span>').concat(escapeHtml(control.label), '<span data-output="').concat(control.id, '">').concat(escapeHtml(current)).concat(escapeHtml((_c = control.suffix) != null ? _c : ""), '</span></span><input id="').concat(id2, '" data-control="').concat(control.id, '" type="range" value="').concat(escapeHtml(current), '" min="').concat((_d = control.min) != null ? _d : 0, '" max="').concat((_e = control.max) != null ? _e : 100, '" step="').concat((_f = control.step) != null ? _f : 1, '" /></label>');
    }
    if (control.type === "color") {
      return '<label class="field field--color" for="'.concat(id2, '"><span>').concat(escapeHtml(control.label), '</span><span class="color-input"><input class="color-picker" type="color" data-color-picker="').concat(control.id, '" value="').concat(escapeHtml(current), '" aria-label="Pick ').concat(escapeHtml(control.label.toLowerCase()), ' color" title="Choose a color" /><input id="').concat(id2, '" data-control="').concat(control.id, '" type="text" maxlength="7" value="').concat(escapeHtml(current), '" aria-label="').concat(escapeHtml(control.label), ' hex color" /></span></label>');
    }
    if (control.type === "toggle") {
      return '<label class="toggle-field" for="'.concat(id2, '"><span><strong>').concat(escapeHtml(control.label), "</strong>").concat(control.description ? "<small>".concat(escapeHtml(control.description), "</small>") : "", '</span><input id="').concat(id2, '" data-control="').concat(control.id, '" type="checkbox" ').concat(current ? "checked" : "", ' /><i aria-hidden="true"></i></label>');
    }
    if (control.type === "select") {
      const options = [...(_g = control.options) != null ? _g : []];
      if (control.id === "fontFamily") {
        options.push(...customFonts.map((font) => ({ label: font.name, value: font.family })));
        if (!options.some((option) => option.value === current)) options.push({ label: String((_h = values.fontName) != null ? _h : current), value: String(current) });
      }
      return '<label class="field '.concat(control.id === "fontFamily" ? "field--wide" : "", '" for="').concat(id2, '"><span>').concat(escapeHtml(control.label), '</span><select id="').concat(id2, '" data-control="').concat(control.id, '">').concat(options.map((option) => '<option value="'.concat(escapeHtml(option.value), '" ').concat(String(current) === String(option.value) ? "selected" : "", ">").concat(escapeHtml(option.label), "</option>")).join(""), "</select></label>").concat(control.id === "fontFamily" ? '<div class="font-import field--wide"><button class="quiet-button" data-import-font type="button">Import font\u2026</button><span>OTF or TTF \xB7 saved locally</span><input data-font-file type="file" accept=".otf,.ttf" hidden /></div>' : "");
    }
    return '<fieldset class="segmented-field field--wide"><legend>'.concat(escapeHtml(control.label), "</legend><div>").concat(((_i = control.options) != null ? _i : []).map((option) => '<button type="button" class="'.concat(String(current) === String(option.value) ? "is-active" : "", '" data-segment-control="').concat(control.id, '" data-value="').concat(escapeHtml(option.value), '" aria-pressed="').concat(String(current) === String(option.value), '">').concat(escapeHtml(option.label), "</button>")).join(""), "</div></fieldset>");
  }
  function controlsMarkup() {
    const controls = controlsFor(selected.controls);
    return groups.map((group) => {
      const matching = controls.filter((control) => control.group === group.id);
      if (!matching.length) return "";
      return '<section data-section="'.concat(group.id, '" class="control-section ').concat(openSections.has(group.id) ? "is-open" : "", '">\n      <button class="control-section__heading" aria-expanded="').concat(openSections.has(group.id), '" type="button"><span>').concat(escapeHtml(group.label), '</span><i></i></button>\n      <div class="control-section__body">').concat(group.id === "content" ? '<p class="content-help">Put <strong>[square brackets]</strong> around words to highlight them. Brackets won\u2019t appear in your graphic.</p>' : "", '<div class="control-grid">').concat(matching.map(inputMarkup).join(""), "</div>").concat(group.id === "output" ? '<p class="sound-match">'.concat(escapeHtml(selected.sfx.label), " \xB7 follows the animation timing</p>").concat(timelineOptionsMarkup()) : "", "</div>\n    </section>");
    }).join("");
  }
  function timelineOptionsMarkup() {
    const p = persisted.preferences;
    return '<div class="timeline-options"><p>Timeline destination</p><div class="control-grid">\n    <label class="field"><span>Video track</span><select data-preference="videoTrackPolicy"><option value="auto" '.concat(p.videoTrackPolicy === "auto" ? "selected" : "", '>Next free track</option><option value="specific" ').concat(p.videoTrackPolicy === "specific" ? "selected" : "", '>Specific track</option></select></label>\n    <label class="field"><span>V track number</span><input data-preference="videoTrackIndex" type="number" min="1" max="99" value="').concat(p.videoTrackIndex + 1, '" ').concat(p.videoTrackPolicy === "auto" ? "disabled" : "", ' /></label>\n    <label class="field"><span>Audio track</span><select data-preference="audioTrackPolicy"><option value="auto" ').concat(p.audioTrackPolicy === "auto" ? "selected" : "", '>Next free track</option><option value="specific" ').concat(p.audioTrackPolicy === "specific" ? "selected" : "", '>Specific track</option></select></label>\n    <label class="field"><span>A track number</span><input data-preference="audioTrackIndex" type="number" min="1" max="99" value="').concat(p.audioTrackIndex + 1, '" ').concat(p.audioTrackPolicy === "auto" ? "disabled" : "", " /></label>\n  </div><small>Auto uses a free track and retries a new one if Premiere rejects a locked destination.</small></div>");
  }
  function detailMarkup() {
    const favorite = persisted.favorites.includes(selected.id);
    const duration = computeDuration(values, selected.duration);
    return '\n    <main class="detail-view">\n      <header class="detail-header">\n        <button class="icon-button" data-back aria-label="Back to presets">'.concat(icon("back"), "</button>\n        <div><small>").concat(escapeHtml(selected.familyName), "</small><strong>").concat(escapeHtml(selected.name), '</strong></div>\n        <div class="detail-header__actions">').concat(appUpdateButtonMarkup(), '<button class="icon-button favorite-button ').concat(favorite ? "is-active" : "", '" data-favorite="').concat(escapeHtml(selected.id), '" aria-label="').concat(favorite ? "Remove from" : "Add to", ' favorites" aria-pressed="').concat(favorite, '">').concat(icon("heart"), '</button></div>\n      </header>\n      <nav class="variant-switcher" aria-label="Animation variants">').concat(presets.filter((preset2) => preset2.family === selected.family).map((preset2) => '<button data-variant="'.concat(preset2.id, '" class="').concat(preset2.id === selected.id ? "is-active" : "", '" aria-pressed="').concat(preset2.id === selected.id, '">').concat(escapeHtml(preset2.name), "</button>")).join(""), '</nav>\n      <div class="detail-workspace">\n        <div class="preview-column">\n          <section class="preview-shell">\n            <div class="preview-frame" id="preview-frame">\n              <div id="preview-host" class="preview-host is-connecting">\n                <img class="preview-poster" src="previews/').concat(escapeHtml(selected.id), '.jpg" alt="" />\n                <div class="preview-status" data-preview-status><i></i><strong>Connecting live preview</strong><small>Loading the exact animation renderer</small></div>\n                <div class="preview-fallback is-hidden" data-preview-fallback><span>Reference frame</span><strong>Live preview unavailable</strong><small data-preview-error></small><button class="quiet-button" data-preview-retry>Retry renderer</button></div>\n              </div>\n            </div>\n            <div class="preview-controls" aria-label="Preview controls">\n              <button class="icon-button" data-preview-play aria-label="Play preview">').concat(icon("play"), '</button>\n              <button class="icon-button" data-preview-replay aria-label="Replay preview">').concat(icon("replay"), '</button>\n              <input data-preview-scrub type="range" min="0" max="').concat(duration, '" step="0.01" value="0" aria-label="Preview position" />\n              <time data-preview-time>0:00 / ').concat(formatTime(duration), '</time>\n              <button class="icon-button" data-audition aria-label="Preview animation with matched sound" title="Preview animation with matched sound">').concat(icon("sound"), '</button>\n            </div>\n            <div class="preview-options">\n              <span>Transparent</span><span class="preview-options__spacer"></span><span data-timeline-size>').concat(escapeHtml(timelineLabel()), '</span>\n            </div>\n            <p id="preview-warning" class="inline-warning is-hidden"></p>\n          </section>\n          <section class="preset-intro"><p>').concat(escapeHtml(selected.description), "</p><div>").concat(selected.tags.slice(0, 5).map((tag) => "<span>".concat(escapeHtml(tag), "</span>")).join(""), '</div></section>\n        </div>\n        <section class="customization" aria-label="Customize preset">\n          <div class="customization__heading"><div><p>Inspector</p><h1>Customize</h1></div><button class="quiet-button" data-reset>Reset</button></div>\n          ').concat(controlsMarkup(), '\n          <button class="save-variation-button" data-save-variation>').concat(icon("plus"), " Save as variation</button>\n          ").concat(variationEditorOpen ? '<div class="variation-editor"><label class="field"><span>Variation name</span><input id="variation-name" maxlength="60" value="'.concat(escapeHtml("".concat(selected.name, " variation")), '" /></label><button class="primary-small" data-confirm-variation>Save</button><button class="quiet-button" data-cancel-variation>Cancel</button></div>') : "", '\n        </section>\n      </div>\n      <div class="action-spacer"></div>\n      <footer class="action-bar">\n        <div class="action-bar__status"><i class="').concat(hostAvailable ? "is-live" : "", '"></i><span>').concat(hostAvailable ? "Starting renderer" : "Preview mode \xB7 Premiere required", '</span></div>\n        <div class="action-bar__buttons">\n          <button class="secondary-action" data-update disabled>').concat(icon("update"), ' Update selected</button>\n          <button class="primary-action" data-add disabled>').concat(icon("plus"), " ").concat(hostAvailable ? "Add to timeline" : "Premiere required", '</button>\n        </div>\n      </footer>\n      <div class="busy-overlay ').concat(busy ? "" : "is-hidden", '" id="busy-overlay" aria-live="assertive"><div><span class="render-orbit"><i></i></span><strong data-progress-label>Preparing animation\u2026</strong><small data-progress-detail>Creating editable project media</small><progress max="1" value="0"></progress><button class="quiet-button" data-cancel-render>Cancel</button></div></div>\n    </main>');
  }
  function formatTime(seconds) {
    const whole = Math.max(0, Math.floor(seconds));
    const tenths = Math.floor((seconds - whole) * 10);
    return "".concat(Math.floor(whole / 60), ":").concat(String(whole % 60).padStart(2, "0"), ".").concat(tenths);
  }
  function render() {
    closeColorPicker();
    previewGeneration += 1;
    previewReady = false;
    previewFailed = false;
    window.clearTimeout(previewTimer);
    stopAudio();
    window.removeEventListener("message", previewWindowListener);
    if (previewResizeListener) window.removeEventListener("resize", previewResizeListener);
    previewResizeListener = void 0;
    renderClient == null ? void 0 : renderClient.destroy();
    renderClient = void 0;
    workflow = void 0;
    previewElement = void 0;
    root.innerHTML = view === "library" ? libraryMarkup() : detailMarkup();
    view === "library" ? bindLibrary() : bindDetail();
    bindUpdaterActions();
    refreshUpdaterUi();
    bindAccountActions();
    refreshAccountUi();
  }
  function bindLibrary() {
    var _a, _b, _c;
    const searchInput = document.querySelector("#preset-search");
    searchInput == null ? void 0 : searchInput.addEventListener("input", () => {
      search = searchInput.value;
      render();
      const next = document.querySelector("#preset-search");
      next == null ? void 0 : next.focus();
      next == null ? void 0 : next.setSelectionRange(search.length, search.length);
    });
    document.querySelectorAll("[data-scope]").forEach((button) => button.addEventListener("click", () => {
      var _a2;
      scope = (_a2 = button.dataset.scope) != null ? _a2 : "all";
      search = "";
      render();
    }));
    (_a = document.querySelector("[data-category]")) == null ? void 0 : _a.addEventListener("change", (event) => {
      categoryFilter = event.currentTarget.value;
      render();
    });
    (_b = document.querySelector("[data-clear-filter]")) == null ? void 0 : _b.addEventListener("click", () => {
      scope = "all";
      categoryFilter = "all";
      search = "";
      render();
    });
    document.querySelectorAll(".preset-card").forEach((card) => {
      var _a2, _b2;
      const id2 = card.dataset.presetId;
      (_a2 = card.querySelector(".preset-card__select")) == null ? void 0 : _a2.addEventListener("click", () => id2 && openPreset(id2));
      (_b2 = card.querySelector("img")) == null ? void 0 : _b2.addEventListener("error", (event) => event.currentTarget.classList.add("is-missing"));
    });
    bindFavorites();
    document.querySelectorAll("[data-variation]").forEach((button) => button.addEventListener("click", () => {
      const variation = persisted.variations.find((item) => item.id === button.dataset.variation);
      if (!variation || !presetById.has(variation.presetId)) return announce("That variation's source preset is missing.", "error");
      openPreset(variation.presetId, variation.values);
    }));
    document.querySelectorAll("[data-remove-variation]").forEach((button) => button.addEventListener("click", () => {
      var _a2;
      persisted = store.removeVariation((_a2 = button.dataset.removeVariation) != null ? _a2 : "");
      render();
    }));
    (_c = document.querySelector("[data-load-selected]")) == null ? void 0 : _c.addEventListener("click", () => void loadTimelineSelection());
    bindCardKeyboard();
  }
  function licenseApi() {
    if (!hostAvailable) return void 0;
    const license2 = window.MotionPlugLicense;
    if (!license2) return void 0;
    try {
      return license2.available() ? license2 : void 0;
    } catch (e) {
      return void 0;
    }
  }
  function bindAccountActions() {
    var _a;
    (_a = document.querySelector("[data-account-action]")) == null ? void 0 : _a.addEventListener("click", () => signedIn ? signOutOfAccount() : openSignInGate());
  }
  function refreshAccountUi() {
    var _a, _b;
    const strip = document.querySelector("[data-account-strip]");
    if (!strip) return;
    const text = strip.querySelector("[data-account-text]");
    const action = strip.querySelector("[data-account-action]");
    strip.classList.toggle("is-signed-in", signedIn);
    const email = (_b = (_a = licenseApi()) == null ? void 0 : _a.email()) != null ? _b : "";
    if (text) text.textContent = signedIn ? "Signed in as ".concat(email || "your account") : "Not signed in on this machine";
    if (action) action.textContent = signedIn ? "Sign out" : "Sign in";
    updateActionAvailability();
  }
  function signOutOfAccount() {
    const license2 = licenseApi();
    if (!license2) return;
    const confirmed = window.confirm(
      "Sign out of Motion Plug on this machine?\n\nThis machine keeps its activation slot until you free it from your account page."
    );
    if (!confirmed) return;
    license2.reset();
    announce("Signed out on this machine.", "neutral");
  }
  function closeSignInGate() {
    var _a;
    (_a = document.querySelector("#account-gate")) == null ? void 0 : _a.remove();
  }
  function openSignInGate() {
    var _a, _b, _c, _d;
    const license2 = licenseApi();
    if (!license2 || license2.ok() || document.querySelector("#account-gate")) return;
    const overlay = document.createElement("div");
    overlay.id = "account-gate";
    overlay.className = "busy-overlay account-gate";
    overlay.innerHTML = '<div class="account-gate__card" role="dialog" aria-label="Sign in to Motion Plug" aria-modal="true">\n    <span class="account-gate__mark"><img src="icons/motionplug-logo.png" alt="" /></span>\n    <strong>Sign in to your account</strong>\n    <small>Use the email and password from your captionplug.com account \u2014 the one you bought Motion Plug with. One-time step on this machine; your license covers 3 machines.</small>\n    <label class="field field--wide" for="account-email"><span>Email</span><input id="account-email" type="email" autocomplete="username" spellcheck="false" placeholder="you@studio.com" /></label>\n    <label class="field field--wide" for="account-password"><span>Password</span><input id="account-password" type="password" autocomplete="current-password" placeholder="Your password" /></label>\n    <p class="account-gate__error is-hidden" data-gate-error role="alert"></p>\n    <div class="account-gate__links">\n      <button class="quiet-button" type="button" data-gate-reset>Forgot password?</button>\n      <button class="quiet-button" type="button" data-gate-pricing>Get Motion Plug</button>\n    </div>\n    <div class="account-gate__actions">\n      <button class="quiet-button" type="button" data-gate-dismiss>Not now</button>\n      <button class="primary-small" type="button" data-gate-submit>Sign in</button>\n    </div>\n    <p class="account-gate__foot">This machine: '.concat(escapeHtml(license2.machineLabel()), " \xB7 works offline once signed in \xB7 your password is never stored</p>\n  </div>");
    document.body.append(overlay);
    const emailField = overlay.querySelector("#account-email");
    const passwordField = overlay.querySelector("#account-password");
    const errorField = overlay.querySelector("[data-gate-error]");
    const submit = overlay.querySelector("[data-gate-submit]");
    function showError(message) {
      if (!errorField) return;
      errorField.textContent = message;
      errorField.classList.remove("is-hidden");
    }
    const attempt = () => {
      var _a2, _b2;
      if (signInBusy || !submit) return;
      errorField == null ? void 0 : errorField.classList.add("is-hidden");
      signInBusy = true;
      submit.disabled = true;
      submit.textContent = "Signing in\u2026";
      license2.signIn((_a2 = emailField == null ? void 0 : emailField.value) != null ? _a2 : "", (_b2 = passwordField == null ? void 0 : passwordField.value) != null ? _b2 : "", (error) => {
        signInBusy = false;
        submit.disabled = false;
        submit.textContent = "Sign in";
        if (error) {
          showError(error.code === "no-license" ? "".concat(error.message, " Buy it once at captionplug.com/motion-plug, then sign in again.") : error.message);
          return;
        }
        closeSignInGate();
        announce("Signed in as ".concat(license2.email(), " on ").concat(license2.machineLabel(), "."), "success", 7e3);
      });
    };
    (_a = overlay.querySelector("[data-gate-submit]")) == null ? void 0 : _a.addEventListener("click", attempt);
    (_b = overlay.querySelector("[data-gate-dismiss]")) == null ? void 0 : _b.addEventListener("click", closeSignInGate);
    (_c = overlay.querySelector("[data-gate-reset]")) == null ? void 0 : _c.addEventListener("click", () => {
      var _a2;
      return (_a2 = window.CSBridge) == null ? void 0 : _a2.openURL(license2.accountUrl("/reset"));
    });
    (_d = overlay.querySelector("[data-gate-pricing]")) == null ? void 0 : _d.addEventListener("click", () => {
      var _a2;
      return (_a2 = window.CSBridge) == null ? void 0 : _a2.openURL(license2.accountUrl("/motion-plug"));
    });
    [emailField, passwordField].forEach((field) => field == null ? void 0 : field.addEventListener("keydown", (event) => {
      if (event.key === "Enter") attempt();
    }));
    emailField == null ? void 0 : emailField.focus();
  }
  function requireAccount() {
    const license2 = licenseApi();
    if (!license2) return true;
    if (license2.ok()) return true;
    announce("Sign in with your captionplug.com account first \u2014 a one-time step on this machine.", "neutral", 7e3);
    openSignInGate();
    return false;
  }
  function bindUpdaterActions() {
    var _a;
    document.querySelectorAll("[data-install-app-update]").forEach((button) => {
      button.addEventListener("click", installAvailableUpdate);
    });
    (_a = document.querySelector("[data-check-updates]")) == null ? void 0 : _a.addEventListener("click", checkForUpdatesManually);
  }
  function refreshUpdaterUi() {
    var _a;
    const restartPending = Boolean((_a = window.MotionPlugUpdater) == null ? void 0 : _a.restartPending());
    document.querySelectorAll("[data-install-app-update]").forEach((button) => {
      button.hidden = !restartPending && !(availableUpdate == null ? void 0 : availableUpdate.isNewer);
      button.disabled = updateOperationBusy || restartPending;
      const label = button.querySelector("span");
      if (label) label.textContent = restartPending ? "Restart Premiere" : availableUpdate ? "Update to ".concat(availableUpdate.version) : "Update";
    });
    const checkButton = document.querySelector("[data-check-updates]");
    if (checkButton) {
      checkButton.disabled = updateOperationBusy || !hostAvailable || !window.MotionPlugUpdater;
      checkButton.textContent = updateOperationBusy ? "Checking\u2026" : "Check for updates";
    }
  }
  function acceptUpdateCheck(error, info, manual = false) {
    var _a;
    updateOperationBusy = false;
    if (error) {
      if (manual) announce(error.message || "Could not check for updates.", "error", 8e3);
      refreshUpdaterUi();
      return;
    }
    if (!info) {
      refreshUpdaterUi();
      return;
    }
    availableUpdate = info;
    refreshUpdaterUi();
    if (info.restartPending) {
      if (manual) announce("Motion Plug ".concat(info.version, " is installed. Restart Premiere Pro to load it."), "success", 9e3);
    } else if (info.isNewer) {
      if (manual || announcedUpdateVersion !== info.version) {
        announcedUpdateVersion = info.version;
        announce("Motion Plug ".concat(info.version, " is available."), "neutral", 8e3);
      }
    } else if (manual) {
      announce("Motion Plug ".concat((_a = window.MP_VERSION) != null ? _a : "", " is up to date."), "success");
    }
  }
  function checkForUpdatesManually() {
    if (updateOperationBusy) return;
    const updater = window.MotionPlugUpdater;
    if (!updater) return announce("The updater is unavailable in this build.", "error");
    updateOperationBusy = true;
    refreshUpdaterUi();
    try {
      updater.check(true, (error, info) => acceptUpdateCheck(error, info, true));
    } catch (error) {
      acceptUpdateCheck(error instanceof Error ? error : new Error(String(error)), void 0, true);
    }
  }
  function showUpdateProgress(percent) {
    let overlay = document.querySelector("#app-update-overlay");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "app-update-overlay";
      overlay.className = "busy-overlay app-update-overlay";
      overlay.innerHTML = '<div><span class="render-orbit"><i></i></span><strong>Installing Motion Plug update\u2026</strong><small>Downloading and validating a complete release</small><progress max="100" value="0"></progress></div>';
      document.body.append(overlay);
    }
    const progress = overlay.querySelector("progress");
    const detail = overlay.querySelector("small");
    if (progress) progress.value = percent;
    if (detail) detail.textContent = percent > 0 ? "".concat(percent, "% downloaded \xB7 your current installation stays recoverable") : "Preparing secure download";
  }
  function installAvailableUpdate() {
    if (updateOperationBusy) return;
    const updater = window.MotionPlugUpdater;
    if (updater == null ? void 0 : updater.restartPending()) return announce("Restart Premiere Pro to load the installed update.", "success", 9e3);
    if (!updater || !(availableUpdate == null ? void 0 : availableUpdate.isNewer)) return;
    updateOperationBusy = true;
    refreshUpdaterUi();
    showUpdateProgress(0);
    updater.install(availableUpdate, showUpdateProgress, (error, summary) => {
      var _a, _b, _c;
      updateOperationBusy = false;
      (_a = document.querySelector("#app-update-overlay")) == null ? void 0 : _a.remove();
      refreshUpdaterUi();
      if (error) return announce(error.message || "The update could not be installed.", "error", 1e4);
      announce("Motion Plug ".concat((_c = (_b = summary == null ? void 0 : summary.version) != null ? _b : availableUpdate == null ? void 0 : availableUpdate.version) != null ? _c : "", " is installed. Restart Premiere Pro to finish."), "success", 12e3);
      refreshUpdaterUi();
    });
  }
  function bindCardKeyboard() {
    const buttons = [...document.querySelectorAll(".preset-card__select")];
    buttons.forEach((button, index) => button.addEventListener("keydown", (event) => {
      var _a, _b, _c, _d, _e;
      const columns = Math.max(1, Math.round(((_b = (_a = button.closest(".preset-grid")) == null ? void 0 : _a.clientWidth) != null ? _b : 320) / ((_d = (_c = button.closest(".preset-card")) == null ? void 0 : _c.clientWidth) != null ? _d : 160)));
      let next = index;
      if (event.key === "ArrowRight") next += 1;
      else if (event.key === "ArrowLeft") next -= 1;
      else if (event.key === "ArrowDown") next += columns;
      else if (event.key === "ArrowUp") next -= columns;
      else return;
      event.preventDefault();
      (_e = buttons[Math.max(0, Math.min(buttons.length - 1, next))]) == null ? void 0 : _e.focus();
    }));
  }
  function bindFavorites() {
    document.querySelectorAll("[data-favorite]").forEach((button) => button.addEventListener("click", (event) => {
      var _a, _b;
      event.stopPropagation();
      persisted = store.toggleFavorite((_a = button.dataset.favorite) != null ? _a : "");
      if (view === "library" && scope === "favorites") render();
      else {
        const active = persisted.favorites.includes((_b = button.dataset.favorite) != null ? _b : "");
        button.classList.toggle("is-active", active);
        button.setAttribute("aria-pressed", String(active));
      }
    }));
  }
  function openPreset(id2, override) {
    const preset2 = presetById.get(id2);
    if (!preset2) return;
    selected = preset2;
    values = valuesForPreset(id2, override != null ? override : { sfxEnabled: persisted.preferences.sfxEnabled, sfxVolume: persisted.preferences.sfxVolume });
    const font = customFonts.find((item) => item.family === values.fontFamily);
    if (font && !values.fontData) values.fontData = font.data;
    view = "detail";
    variationEditorOpen = false;
    render();
    void refreshTimeline();
  }
  function timelineLabel() {
    return timelineContext ? "".concat(timelineContext.width, " \xD7 ").concat(timelineContext.height, " \xB7 Timeline") : hostAvailable ? timelineError || "Reading timeline\u2026" : "Matches timeline in Premiere";
  }
  async function refreshTimeline() {
    if (!hostAvailable || refreshingTimeline || busy) return;
    refreshingTimeline = true;
    try {
      const next = await getTimelineContext();
      const changed = !timelineContext || next.width !== timelineContext.width || next.height !== timelineContext.height || next.sequenceId !== timelineContext.sequenceId;
      timelineContext = next;
      timelineError = "";
      if (changed && view === "detail") {
        syncPreviewElementSize();
        await updatePreview(true);
      }
    } catch (e) {
      timelineContext = void 0;
      timelineError = "Open an active sequence";
    } finally {
      refreshingTimeline = false;
      const label = document.querySelector("[data-timeline-size]");
      if (label) label.textContent = timelineLabel();
      updateActionAvailability();
    }
  }
  function updateActionAvailability() {
    const available = hostAvailable && Boolean(timelineContext) && previewReady && Boolean(workflow) && !busy;
    document.querySelectorAll("[data-add], [data-update]").forEach((button) => {
      button.disabled = !available;
    });
    document.querySelectorAll("[data-preview-play], [data-preview-replay], [data-preview-scrub]").forEach((control) => {
      control.disabled = !previewReady;
    });
    const status = document.querySelector(".action-bar__status span");
    if (!status) return;
    if (!hostAvailable) status.textContent = "Preview mode \xB7 Premiere required";
    else if (licenseApi() && !signedIn) status.textContent = "Sign in to add graphics to the timeline";
    else if (!timelineContext) status.textContent = timelineError || "Reading active sequence";
    else if (busy) status.textContent = "Preparing timeline media";
    else if (previewReady) status.textContent = "Renderer ready \xB7 Premiere connected";
    else if (previewFailed) status.textContent = "Renderer unavailable \xB7 retry preview";
    else status.textContent = "Starting renderer";
  }
  function syncPreviewElementSize() {
    var _a;
    const host = document.querySelector("#preview-host");
    const element = previewElement;
    if (!host || !element) return;
    const frame = document.querySelector("#preview-frame");
    if (frame) {
      const ratio = timelineContext ? timelineContext.width / timelineContext.height : 16 / 9;
      const availableWidth = ((_a = frame.parentElement) == null ? void 0 : _a.clientWidth) ? frame.parentElement.clientWidth - 24 : 320;
      const width2 = Math.min(availableWidth, (window.innerWidth < 620 ? 360 : 420) * ratio);
      frame.style.width = "".concat(Math.max(16, width2), "px");
      frame.style.height = "".concat(Math.max(16, width2 / ratio), "px");
      frame.style.marginLeft = frame.style.marginRight = "auto";
    }
    const rect = host.getBoundingClientRect();
    const width = Math.max(1, Math.round(rect.width || host.clientWidth || 320));
    const height = Math.max(1, Math.round(rect.height || host.clientHeight || 180));
    element.setAttribute("width", "".concat(width, "px"));
    element.setAttribute("height", "".concat(height, "px"));
    element.style.width = "".concat(width, "px");
    element.style.height = "".concat(height, "px");
  }
  function showPreviewFallback(error, generation) {
    var _a;
    if (generation !== previewGeneration) return;
    previewReady = false;
    previewFailed = true;
    renderClient == null ? void 0 : renderClient.destroy();
    renderClient = void 0;
    workflow = void 0;
    previewElement == null ? void 0 : previewElement.remove();
    previewElement = void 0;
    const host = document.querySelector("#preview-host");
    const fallback = host == null ? void 0 : host.querySelector("[data-preview-fallback]");
    const detail = fallback == null ? void 0 : fallback.querySelector("[data-preview-error]");
    host == null ? void 0 : host.classList.remove("is-connecting", "is-ready");
    host == null ? void 0 : host.classList.add("is-fallback");
    (_a = host == null ? void 0 : host.querySelector("[data-preview-status]")) == null ? void 0 : _a.classList.add("is-hidden");
    fallback == null ? void 0 : fallback.classList.remove("is-hidden");
    if (detail) {
      const message = error instanceof Error ? error.message : String(error);
      detail.textContent = "".concat(message, " The shipped reference frame is shown instead.");
    }
    updateActionAvailability();
  }
  function createPreview() {
    var _a, _b;
    const host = document.querySelector("#preview-host");
    if (!host) return;
    previewGeneration += 1;
    const generation = previewGeneration;
    previewReady = false;
    previewFailed = false;
    renderClient == null ? void 0 : renderClient.destroy();
    renderClient = void 0;
    workflow = void 0;
    previewElement == null ? void 0 : previewElement.remove();
    previewElement = void 0;
    host.classList.remove("is-ready", "is-fallback");
    host.classList.add("is-connecting");
    (_a = host.querySelector("[data-preview-status]")) == null ? void 0 : _a.classList.remove("is-hidden");
    (_b = host.querySelector("[data-preview-fallback]")) == null ? void 0 : _b.classList.add("is-hidden");
    const element = document.createElement("iframe");
    element.className = "preview-renderer";
    element.setAttribute("src", "renderer.html");
    element.setAttribute("title", "".concat(selected.name, " customized preview"));
    const hostRect = host.getBoundingClientRect();
    const initialWidth = Math.max(1, Math.round(hostRect.width || host.clientWidth || 320));
    const initialHeight = Math.max(1, Math.round(hostRect.height || host.clientHeight || 180));
    element.setAttribute("width", "".concat(initialWidth, "px"));
    element.setAttribute("height", "".concat(initialHeight, "px"));
    element.style.width = "".concat(initialWidth, "px");
    element.style.height = "".concat(initialHeight, "px");
    element.setAttribute("sandbox", "allow-scripts allow-same-origin");
    host.appendChild(element);
    previewElement = element;
    syncPreviewElementSize();
    window.requestAnimationFrame(syncPreviewElementSize);
    if (previewResizeListener) window.removeEventListener("resize", previewResizeListener);
    previewResizeListener = () => window.requestAnimationFrame(syncPreviewElementSize);
    window.addEventListener("resize", previewResizeListener);
    renderClient = new RenderClient(element);
    workflow = new MotionPlugWorkflow(renderClient);
    element.addEventListener("message", (event) => {
      var _a2;
      return handlePreviewMessage((_a2 = event.data) != null ? _a2 : event.detail);
    });
    window.addEventListener("message", previewWindowListener);
    updateActionAvailability();
    void updatePreview(true, generation);
  }
  function previewWindowListener(event) {
    handlePreviewMessage(event.data);
  }
  function handlePreviewMessage(raw) {
    var _a, _b;
    try {
      const message = typeof raw === "string" ? JSON.parse(raw) : raw;
      if (!message || message.type !== "render-state") return;
      previewTime = Number((_a = message.time) != null ? _a : 0);
      previewPlaying = Boolean(message.playing);
      if (!previewPlaying && activeAudio && previewTime >= Number((_b = message.duration) != null ? _b : 0) - 0.02) stopAudio();
      const scrub = document.querySelector("[data-preview-scrub]");
      const time = document.querySelector("[data-preview-time]");
      const button = document.querySelector("[data-preview-play]");
      const duration = computeDuration(values, selected.duration);
      if (scrub && document.activeElement !== scrub) scrub.value = String(previewTime);
      if (time) time.textContent = "".concat(formatTime(previewTime), " / ").concat(formatTime(duration));
      if (button) {
        button.innerHTML = icon(previewPlaying ? "pause" : "play");
        button.setAttribute("aria-label", previewPlaying ? "Pause preview" : "Play preview");
      }
      const warning = document.querySelector("#preview-warning");
      const warnings = Array.isArray(message.warnings) ? message.warnings.filter((item) => typeof item === "string") : [];
      if (warning) {
        warning.textContent = warnings.join(" ");
        warning.classList.toggle("is-hidden", !warnings.length);
      }
    } catch (e) {
    }
  }
  function currentPreviewConfig() {
    const ratio = timelineContext ? timelineContext.width / timelineContext.height : 16 / 9;
    const dimensions = ratio >= 1 ? { width: 960, height: Math.round(960 / ratio) } : { width: Math.round(960 * ratio), height: 960 };
    return {
      presetId: selected.id,
      values,
      ...dimensions,
      duration: computeDuration(values, selected.duration),
      background: "checker",
      renderMode: "preview"
    };
  }
  async function updatePreview(immediate = false, generation = previewGeneration) {
    if (!renderClient && previewFailed && view === "detail") {
      createPreview();
      return;
    }
    stopAudio();
    window.clearTimeout(previewTimer);
    const run = async () => {
      const client = renderClient;
      if (!client) return;
      try {
        await client.configure(currentPreviewConfig());
        previewPoster = true;
        if (generation !== previewGeneration || client !== renderClient) return;
        previewReady = true;
        previewFailed = false;
        const host = document.querySelector("#preview-host");
        host == null ? void 0 : host.classList.remove("is-connecting", "is-fallback");
        host == null ? void 0 : host.classList.add("is-ready");
        previewElement == null ? void 0 : previewElement.style.setProperty("visibility", "visible");
        const scrub = document.querySelector("[data-preview-scrub]");
        if (scrub) scrub.max = String(computeDuration(values, selected.duration));
        updateActionAvailability();
      } catch (error) {
        showPreviewFallback(error, generation);
      }
    };
    if (immediate) await run();
    else previewTimer = window.setTimeout(() => void run(), 90);
  }
  function readControl(control, element) {
    if (control.type === "toggle") return element.checked;
    if (control.type === "number" || control.type === "range") return Number(element.value);
    if (control.id === "fontWeight") return Number(element.value);
    return element.value;
  }
  function bindDetail() {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p;
    (_a = document.querySelector("[data-back]")) == null ? void 0 : _a.addEventListener("click", () => {
      view = "library";
      render();
    });
    bindFavorites();
    document.querySelectorAll("[data-variant]").forEach((button) => button.addEventListener("click", () => {
      const shared = {};
      const content = controlsFor(selected.controls).filter((control) => control.group === "content").map((control) => control.id);
      for (const key of [...content, "fontFamily", "fontData", "fontName", "textColor", "accentColor", "accentColor2", "sfxEnabled", "sfxVolume"]) {
        if (values[key] !== void 0) shared[key] = values[key];
      }
      openPreset(button.dataset.variant, shared);
    }));
    (_b = document.querySelector("[data-import-font]")) == null ? void 0 : _b.addEventListener("click", () => {
      var _a2;
      return (_a2 = document.querySelector("[data-font-file]")) == null ? void 0 : _a2.click();
    });
    (_c = document.querySelector("[data-font-file]")) == null ? void 0 : _c.addEventListener("change", async (event) => {
      var _a2;
      const file = (_a2 = event.currentTarget.files) == null ? void 0 : _a2[0];
      if (!file) return;
      const presetId = selected.id;
      const button = document.querySelector("[data-import-font]");
      if (button) {
        button.disabled = true;
        button.textContent = "Importing\u2026";
      }
      try {
        const font = await importCustomFont(file);
        customFonts = [...customFonts.filter((item) => item.family !== font.family), font];
        if (selected.id === presetId && view === "detail") {
          values.fontFamily = font.family;
          values.fontData = font.data;
          values.fontName = font.name;
          openSections.add("type");
          render();
        }
        announce("Imported ".concat(font.name, "."), "success");
      } catch (error) {
        announce(error instanceof Error ? error.message : String(error), "error");
      } finally {
        if (button) {
          button.disabled = false;
          button.textContent = "Import font\u2026";
        }
      }
    });
    document.querySelectorAll("[data-color-picker]").forEach((picker) => picker.addEventListener("input", () => {
      const input = document.querySelector('[data-control="'.concat(picker.dataset.colorPicker, '"]'));
      if (input) {
        input.value = picker.value;
        input.dispatchEvent(new Event("input", { bubbles: true }));
      }
    }));
    bindColorPickers();
    createPreview();
    (_d = document.querySelector("[data-preview-retry]")) == null ? void 0 : _d.addEventListener("click", createPreview);
    const specs = new Map(controlsFor(selected.controls).map((control) => [control.id, control]));
    document.querySelectorAll("[data-control]").forEach((element) => {
      var _a2;
      const control = specs.get((_a2 = element.dataset.control) != null ? _a2 : "");
      const eventName = control && ["range", "color", "text", "textarea"].includes(control.type) ? "input" : "change";
      element.addEventListener(eventName, () => {
        var _a3, _b2;
        if (!control) return;
        if (control.type === "color") {
          const valid = /^#[0-9a-f]{6}$/i.test(element.value);
          element.setAttribute("aria-invalid", String(!valid));
          if (!valid) return;
        }
        values[control.id] = readControl(control, element);
        if (control.id === "sfxEnabled") persisted = store.updatePreferences({ sfxEnabled: Boolean(values.sfxEnabled) });
        if (control.id === "sfxVolume") persisted = store.updatePreferences({ sfxVolume: Number(values.sfxVolume) });
        const output = document.querySelector('[data-output="'.concat(control.id, '"]'));
        if (output) output.textContent = "".concat(element.value).concat((_a3 = control.suffix) != null ? _a3 : "");
        if (control.type === "color") {
          const picker = (_b2 = element.parentElement) == null ? void 0 : _b2.querySelector("[data-color-picker]");
          if (picker) picker.value = element.value;
        }
        if (control.id === "fontFamily") {
          const font = customFonts.find((item) => item.family === element.value);
          if (font) {
            values.fontData = font.data;
            values.fontName = font.name;
          } else if (!element.value.startsWith("MotionPlugCustom-")) {
            delete values.fontData;
            delete values.fontName;
          }
        }
        void updatePreview();
      });
    });
    document.querySelectorAll("[data-segment-control]").forEach((button) => button.addEventListener("click", () => {
      var _a2, _b2;
      const id2 = (_a2 = button.dataset.segmentControl) != null ? _a2 : "";
      values[id2] = (_b2 = button.dataset.value) != null ? _b2 : "";
      document.querySelectorAll('[data-segment-control="'.concat(id2, '"]')).forEach((peer) => {
        const active = peer === button;
        peer.classList.toggle("is-active", active);
        peer.setAttribute("aria-pressed", String(active));
      });
      void updatePreview();
    }));
    document.querySelectorAll(".control-section__heading").forEach((button) => button.addEventListener("click", () => {
      const section = button.parentElement;
      const open = !(section == null ? void 0 : section.classList.contains("is-open"));
      section == null ? void 0 : section.classList.toggle("is-open", open);
      const group = section == null ? void 0 : section.getAttribute("data-section");
      if (group) {
        if (open) openSections.add(group);
        else openSections.delete(group);
      }
      button.setAttribute("aria-expanded", String(open));
    }));
    document.querySelectorAll("[data-preference]").forEach((element) => element.addEventListener("change", () => {
      const key = element.dataset.preference;
      const raw = key.endsWith("Index") ? Math.max(0, Number(element.value) - 1) : element.value;
      persisted = store.updatePreferences({ [key]: raw });
      if (key.endsWith("Policy")) render();
    }));
    (_e = document.querySelector("[data-preview-play]")) == null ? void 0 : _e.addEventListener("click", () => {
      if (previewPlaying) {
        renderClient == null ? void 0 : renderClient.pause();
        stopAudio();
      } else void playPreview(false);
    });
    (_f = document.querySelector("[data-preview-replay]")) == null ? void 0 : _f.addEventListener("click", () => void playPreview(true));
    (_g = document.querySelector("[data-preview-scrub]")) == null ? void 0 : _g.addEventListener("input", (event) => {
      stopAudio();
      previewPoster = false;
      renderClient == null ? void 0 : renderClient.seek(Number(event.currentTarget.value));
    });
    (_h = document.querySelector("[data-audition]")) == null ? void 0 : _h.addEventListener("click", () => void playPreview(true, true));
    (_i = document.querySelector("[data-reset]")) == null ? void 0 : _i.addEventListener("click", () => {
      values = valuesForPreset(selected.id);
      render();
      announce("Preset reset to its original values.");
    });
    (_j = document.querySelector("[data-save-variation]")) == null ? void 0 : _j.addEventListener("click", () => {
      variationEditorOpen = true;
      render();
      window.setTimeout(() => {
        var _a2;
        return (_a2 = document.querySelector("#variation-name")) == null ? void 0 : _a2.select();
      }, 0);
    });
    (_k = document.querySelector("[data-cancel-variation]")) == null ? void 0 : _k.addEventListener("click", () => {
      variationEditorOpen = false;
      render();
    });
    (_l = document.querySelector("[data-confirm-variation]")) == null ? void 0 : _l.addEventListener("click", saveVariation);
    (_m = document.querySelector("#variation-name")) == null ? void 0 : _m.addEventListener("keydown", (event) => {
      if (event.key === "Enter") saveVariation();
    });
    (_n = document.querySelector("[data-add]")) == null ? void 0 : _n.addEventListener("click", () => void runWorkflow("add"));
    (_o = document.querySelector("[data-update]")) == null ? void 0 : _o.addEventListener("click", () => void runWorkflow("update"));
    (_p = document.querySelector("[data-cancel-render]")) == null ? void 0 : _p.addEventListener("click", () => renderClient == null ? void 0 : renderClient.cancel());
  }
  function saveVariation() {
    const input = document.querySelector("#variation-name");
    if (!(input == null ? void 0 : input.value.trim())) return input == null ? void 0 : input.focus();
    const savedValues = { ...values };
    if (customFonts.some((font) => font.family === values.fontFamily)) delete savedValues.fontData;
    store.saveVariation(selected.id, input.value, savedValues);
    persisted = store.snapshot();
    variationEditorOpen = false;
    render();
    announce("Saved \u201C".concat(input.value.trim(), "\u201D."), "success");
  }
  async function playPreview(restart, audition = false) {
    var _a;
    if (!previewReady || busy) return;
    stopAudio();
    const generation = audioGeneration;
    const duration = computeDuration(values, selected.duration);
    const start = restart || previewPoster || previewTime >= duration - 0.01 ? 0 : previewTime;
    try {
      if (Boolean(values.sfxEnabled) || audition) {
        const wav = await createSoundtrack(selected, values, duration, Number((_a = values.sfxVolume) != null ? _a : persisted.preferences.sfxVolume));
        if (generation !== audioGeneration) return;
        const copy = new Uint8Array(wav.byteLength);
        copy.set(wav);
        activeAudioUrl = URL.createObjectURL(new Blob([copy.buffer], { type: "audio/wav" }));
        activeAudio = new Audio(activeAudioUrl);
        activeAudio.addEventListener("ended", stopAudio, { once: true });
        activeAudio.currentTime = start;
        await activeAudio.play();
      }
      if (generation !== audioGeneration) return;
      previewPoster = false;
      renderClient == null ? void 0 : renderClient.seek(start);
      renderClient == null ? void 0 : renderClient.play();
    } catch (error) {
      stopAudio();
      announce(error instanceof Error ? error.message : "Could not play the matching sound.", "error");
    }
  }
  function stopAudio() {
    audioGeneration += 1;
    activeAudio == null ? void 0 : activeAudio.pause();
    activeAudio = void 0;
    if (activeAudioUrl) URL.revokeObjectURL(activeAudioUrl);
    activeAudioUrl = void 0;
  }
  function updateProgress(progress) {
    const overlay = document.querySelector("#busy-overlay");
    const label = overlay == null ? void 0 : overlay.querySelector("[data-progress-label]");
    const detail = overlay == null ? void 0 : overlay.querySelector("[data-progress-detail]");
    const bar = overlay == null ? void 0 : overlay.querySelector("progress");
    overlay == null ? void 0 : overlay.classList.remove("is-hidden");
    if (bar) bar.value = progress.ratio;
    if (label) label.textContent = progress.stage === "importing" ? "Adding to Premiere\u2026" : "Rendering frame ".concat(progress.frame, " of ").concat(progress.total);
    if (detail) detail.textContent = progress.stage === "importing" ? "Importing and creating one undoable timeline edit" : "".concat(Math.round(progress.ratio * 100), "% \xB7 transparent PNG sequence");
  }
  async function runWorkflow(mode) {
    var _a;
    if (busy) return;
    if (!hostAvailable) return announce("Open Motion Plug inside Premiere to add a graphic.", "neutral");
    if (!requireAccount()) return;
    if (!workflow || !previewReady) return announce("The animation renderer is not ready. Retry the live preview first.", "error");
    busy = true;
    stopAudio();
    updateActionAvailability();
    (_a = document.querySelector("#busy-overlay")) == null ? void 0 : _a.classList.remove("is-hidden");
    document.querySelectorAll("[data-add], [data-update]").forEach((button) => {
      button.disabled = true;
    });
    try {
      const result = mode === "add" ? await workflow.add({ presetId: selected.id, values, preferences: persisted.preferences, onProgress: updateProgress }) : await workflow.update({ presetId: selected.id, values, preferences: persisted.preferences, onProgress: updateProgress });
      persisted = store.markRecent(selected.id);
      announce(mode === "add" ? "Added \u201C".concat(selected.name, "\u201D at the playhead.") : "Updated \u201C".concat(selected.name, "\u201D in place."), "success", 7e3);
      if (result.warnings.length) announce(result.warnings.join(" "), "neutral", 9e3);
    } catch (error) {
      announce(error instanceof Error ? error.message : String(error), "error", 1e4);
    } finally {
      busy = false;
      const overlay = document.querySelector("#busy-overlay");
      overlay == null ? void 0 : overlay.classList.add("is-hidden");
      if (renderClient) await updatePreview(true);
      updateActionAvailability();
    }
  }
  async function loadTimelineSelection() {
    if (!hostAvailable) return announce("Open Motion Plug inside Premiere, then select a Motion Plug clip.", "neutral");
    try {
      const selectedGraphic = await getSelectedInstance();
      openPreset(selectedGraphic.instance.presetId, selectedGraphic.instance.values);
      announce("Loaded the selected Motion Plug graphic for editing.", "success");
    } catch (error) {
      announce(error instanceof Error ? error.message : String(error), "error");
    }
  }
  document.addEventListener("keydown", (event) => {
    var _a;
    if ((event.metaKey || event.ctrlKey) && event.key.toLocaleLowerCase() === "k") {
      event.preventDefault();
      if (view !== "library") {
        view = "library";
        render();
      }
      (_a = document.querySelector("#preset-search")) == null ? void 0 : _a.focus();
    }
    if (event.key === "Escape" && document.querySelector("#account-gate")) {
      event.preventDefault();
      closeSignInGate();
      return;
    }
    if (event.key === "Escape" && view === "detail" && !busy) {
      view = "library";
      render();
    }
  });
  window.addEventListener("unload", () => {
    renderClient == null ? void 0 : renderClient.destroy();
    stopAudio();
    window.removeEventListener("message", previewWindowListener);
    if (previewResizeListener) window.removeEventListener("resize", previewResizeListener);
  });
  try {
    hostAvailable = hostIsAvailable();
  } catch (e) {
    hostAvailable = false;
  }
  var license = licenseApi();
  if (license) {
    try {
      signedIn = license.init();
    } catch (e) {
      signedIn = false;
    }
    license.onChange(() => {
      signedIn = license.ok();
      refreshAccountUi();
      if (!signedIn) openSignInGate();
    });
  }
  render();
  if (license) {
    if (signedIn) {
      license.revalidate((message) => announce(message, "error", 14e3));
    } else {
      openSignInGate();
    }
  }
  if (hostAvailable && window.MotionPlugUpdater) {
    window.MotionPlugUpdater.startAutoChecks((error, info) => acceptUpdateCheck(error, info, false));
  }
  void listCustomFonts().then((fonts) => {
    customFonts = fonts;
    if (view === "detail" && !busy) {
      const font = fonts.find((item) => item.family === values.fontFamily);
      if (font && !values.fontData) values.fontData = font.data;
      render();
    }
  }).catch(() => void 0);
  void refreshTimeline();
  window.addEventListener("focus", () => void refreshTimeline());
  window.setInterval(() => {
    if (view === "detail" && !document.hidden) void refreshTimeline();
  }, 2e3);
})();
